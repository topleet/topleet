package org.unknown1337.topleet.libs

import java.awt.Desktop
import java.io.File
import java.net.{URI, URLEncoder}
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date

import com.google.common.base.Charsets
import com.google.common.io.Files
import org.apache.commons.lang.StringEscapeUtils
import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes.{AMap, AType, AbelianAMap}
import org.unknown1337.topleet.engines.Engine
import org.unknown1337.topleet.ura.Gitobject
import org.unknown1337.topleet.utils.{JSONLDPrinter, VSMs}

import scala.collection.mutable
import scala.reflect.{ClassTag => CT}

trait GitViewers extends Gits {

  val engine: Engine

  import engine._

  //  implicit class GitViewersProvideAMap[K: CT, V <: AType : CT](@transient l: engine.PairLeet[SHA, K, V]) extends Serializable {
  //    def runGraphs(folder: File, edgeLabel: Boolean = true, horizontal: Boolean = false): Unit = {
  //      implicit val abl: Group[V] = engine.abelian(l).asInstanceOf[AbelianAMap[K, V]].vAbelian
  //
  //      def inner(il: engine.PairLeet[SHA, K, V], index: Set[K], mapping: Map[SHA, SHA]): Unit =
  //        if (index.nonEmpty) {
  //          if (index.size <= 1) {
  //            // Plot things.
  //            val target = il.tmapIx(x => x.value.getOrElse(index.head, abl.zero))
  //            target.runGraph(mapping, new File(folder, URLEncoder.encode(index.head.toString.replace("*", "x"), "UTF-8") + ".html"), false, edgeLabel, horizontal)
  //          } else {
  //            // Bisection.
  //            for (slice <- index.grouped(Math.max(1, index.size / 2))) {
  //              // Filter on key set.
  //              val filtered = il.filter(slice) //tmapHom(il)(x => AMap.filter(x) { case (k, _) => slice(k) })
  //              // Contract empty delta in strict mode but remove bypassing edges.
  //              val (pruned, nextMapping) = engine.contractZero(filtered)
  //              // Group recursive call.
  //              inner(pruned, slice, mapping.map { case (k, v) => (k, nextMapping(v)) })
  //            }
  //          }
  //        }
  //
  //      inner(l, l.keys(), engine.nodes(l).map(x => (x, x)).toMap)
  //    }
  //  }


  implicit class DumpPairLeetProvides[K: CT, V <: AType : CT](@transient l: engine.PairLeet[SHA, K, V]) extends Serializable {

    val dateFormat: SimpleDateFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")

    val defaultAttributes: Map[String, SHA => String] = Map[String, SHA => String](
      "name" -> { case SHA(address, Some(sha)) => Gitobject(address).authorName(sha) },
      "email" -> { case SHA(address, Some(sha)) => Gitobject(address).authorMail(sha) },
      "sha" -> { case SHA(address, Some(sha)) => sha },
      "address" -> { case SHA(address, Some(sha)) => address },
      "date" -> { case SHA(address, Some(sha)) => dateFormat.format(new Date(Gitobject(address).time(sha) * 1000l)) },
      "fix" -> { case SHA(address, Some(sha)) =>
        VSMs.tokenize(VSMs.toLower(VSMs.keepLetters(Gitobject(address).comment(sha))))
          .exists { x => (x.contains("fix") && !x.contains("prefix") && !x.contains("postfix")) }
          .toString
      },
      "parents" -> { case SHA(address, Some(sha)) => Gitobject(address).parents(sha).length.toString }
    )

    def dumpJsonLD(file: File, append: Boolean = false, charset: Charset = Charsets.UTF_8, on: Option[Set[SHA]] = None, attributes: Map[String, SHA => String] = defaultAttributes)
                  (how: (K, V) => Map[String, String]): Unit = {
      val printer = JSONLDPrinter.create(file, charset, append)

      val buffer = mutable.Map[SHA, Map[String, String]]()

      for ((sha, k, v) <- (if (on.isDefined) l.values(on.get) else l.values()).filter(_._1.sha.isDefined)) {
        val record = how(k, v) ++ buffer.getOrElseUpdate(sha, {
          attributes.map { case (key, f) => (key, f(sha)) }
        })
        printer.printRecord(record)
      }

      printer.close()
    }
  }


  implicit class GitViewersProvide[V <: AType : CT](@transient l: engine.Leet[SHA, V]) extends Serializable {

    def runGraph(contract: Boolean = true, file: File = new File("temp/tempview.html"), edgeLabel: Boolean = false, horizontal: Boolean = false, open: Boolean = true): Unit = {

      val (lcontrated, mapping) = if (contract) engine.contractZero(l) else (l, engine.nodes(l).map(x => (x, x)).toMap)

      lcontrated.runGraph(mapping, file, open, edgeLabel, horizontal)
    }

    // TODO: Add all kinds of configurations like path, orientation, ...
    def runGraph(mapping: Map[SHA, SHA], file: File, open: Boolean, edgeLabel: Boolean, horizontal: Boolean): Unit = {
      def attributes(x: Map[String, String]) = "[" + x.map { case (k, v) => k + "=\"" + StringEscapeUtils.escapeJavaScript(v) + "\"" }.reduceOption(_ + ", " + _).getOrElse("") + "]"

      val imapping = mapping.toSeq.groupBy(_._2).mapValues(_.map(_._1))

      val fstline = l.topology().fstline().toSet
      val bypass = engine.bypassEdges(l).toSet

      val es = engine.edges(l).zipWithIndex
      val ns = engine.nodes(l).toSeq.zipWithIndex.toMap
      val absolute = engine.values(l).toMap
      val relative = engine.relativeValues(l).toMap

      def label(x: AType) = x.pretty()

      val edgesDot = es.map { case ((n1, n2), id) => "nd" + ns(n1) + " -> " + "nd" + ns(n2) + attributes(Map("id" -> ("e" + id)) ++ Map("label" -> (if (edgeLabel) label(relative(n1, n2)) else ""))) + ";" }.reduceOption(_ + " " + _).getOrElse("")
      val vertexDot = ns.map { case (n, id) => "nd" + id + attributes(Map("id" -> ("n" + id)) ++ Map("label" -> label(absolute(n)), "shape" -> (if (label(absolute(n)).contains("\n")) "box" else "ellipse"))) + ";" }.reduceOption(_ + " " + _).getOrElse("")

      def kv(key: String, value: String): String = "\"" + key + "\":\"" + value + "\""

      val json = (es.map { case ((sha1, sha2), eid) =>
        val annotations = "{" + kv("bypass", bypass((sha1, sha2)).toString) + "}"
        val hover = ""
        "\"" + "e" + eid + "\":{\"hover\":[" + hover + "],\"svg\":" + annotations + "}"
      } ++ ns.map { case (nodeSha, nid) =>
        val annotations = "{" + kv("fstLine", fstline(nodeSha).toString) + "}"

        val hover = imapping(nodeSha)
          .collect { case SHA(address, Some(sha)) => (address, sha) }
          .sortBy { case (address, sha) => Gitobject(address).time(sha) }
          .map { case (address, sha) =>
            val name = StringEscapeUtils.escapeJavaScript(Gitobject(address).authorName(sha))
            val mail = StringEscapeUtils.escapeJavaScript(Gitobject(address).authorMail(sha))
            val time = StringEscapeUtils.escapeJavaScript(Gitobject(address).time(sha).toString)
            val commit = s"<a href='https://github.com/$address/commit/$sha'>$sha</a>"
            val owner = nodeSha.sha.contains(sha).toString

            "{" + kv("owner", owner) + "," + kv("name", name) + "," + kv("mail", mail) + "," + kv("time", time) + "," + kv("commit", commit) + "}"
          }.reduceOption(_ + "," + _).getOrElse("")

        "\"" + "n" + nid + "\":{\"hover\":[" + hover + "],\"svg\":" + annotations + "}"
      }).reduceOption(_ + "," + _).getOrElse("")

      val options = if (horizontal) "rankdir=\"LR\";" else ""

      val templete = Files.asCharSource(new File("core/src/main/resources/viewer/viewer2.html"), Charsets.UTF_8).read()
      val instance = templete
        .replace("digraph R {}", "digraph R {" + StringEscapeUtils.escapeJavaScript(options + vertexDot + edgesDot).replace("\\\\r\\\\n", "\\\\l") + "}")
        .replace("jsondata = {}", "jsondata = {" + json + "}")

      Files.createParentDirs(file)
      Files.asCharSink(file, Charsets.UTF_8).write(instance)

      if (open)
        if (System.getProperty("os.name") == "Windows 10" || System.getProperty("os.name").indexOf("win") >= 0)
          Runtime.getRuntime.exec("rundll32 url.dll,FileProtocolHandler " + new File("temp/tempview.html").getAbsolutePath)
        else
          Desktop.getDesktop.browse(new URI("file://" + new File("temp/tempview.html").getAbsolutePath))

    }
  }

}

//
//  def viewHistory[N: CT, T: CT](t: Leet[N, T], dates: Map[N, Long])(implicit ordering: Ordering[T]): Unit = {
//
//    val group = abelian(t)
//    val min = dates.values.min
//    val absolute = values(t).filter { case (n, _) => dates.isDefinedAt(n) }
//    val ordered = absolute.values.toSet.toSeq.sorted(ordering).zipWithIndex.toMap
//    val data = absolute.map { case (n, value) => "  {\"x\":new Date(" + dates(n) * 1000 + "), \"y\": " + ordered(value) + ", \"c\": \"" + value.toString + "\"}" }.reduce(_ + "," + _)
//
//    Files.asCharSink(new File("temp/history.html"), Charsets.UTF_8).write(Files.asCharSource(new File("core/src/main/resources/viewer/history.html"), Charsets.UTF_8).read()
//      .replace("var data = [];", "var data = [" + data + "];"))
//
//    Runtime.getRuntime.exec("rundll32 url.dll,FileProtocolHandler " + new File("temp/history.html").getAbsolutePath)
//  }
//
//  def viewRealHistory[N: CT](t: Leet[N, Double], dates: Map[N, Long]): Unit = {
//    val min = dates.values.min
//    val absolute = values(t)(classTag[N], classTag[Double]).filter { case (n, _) => dates.isDefinedAt(n) }
//    val data = absolute.map { case (n, value) => "  {\"x\":new Date(" + dates(n) * 1000 + "), \"y\": " + value + "}" }.reduce(_ + "," + _)
//
//    Files.asCharSink(new File("temp/history.html"), Charsets.UTF_8).write(Files.asCharSource(new File("core/src/main/resources/viewer/history.html"), Charsets.UTF_8).read()
//      .replace("var data = [];", "var data = [" + data + "];"))
//
//    Runtime.getRuntime.exec("rundll32 url.dll,FileProtocolHandler " + new File("temp/history.html").getAbsolutePath)
//  }
//
//  def viewTopology[N: CT, T: CT](tt: Leet[N, T], contractZero: Boolean = false, edgeLabel: Boolean = true, horizontal: Boolean = false)(implicit group: Group[T]): Unit = {
//
//    def attributes(x: Map[String, String]) = "[" + x.map { case (k, v) => k + "=\"" + v + "\"" }.reduceOption(_ + ", " + _).getOrElse("") + "]"
//
//    val (t, contract) = if (contractZero) Engine.this.contractZero(tt, contractRoot = true) else (tt, edges(tt).map(x => (x, x)))
//    val es = edges(t).zipWithIndex
//    val ns = nodes(t).toSeq.zipWithIndex.toMap
//    val absolute = values(t)
//    lazy val relative = relativeValues(t)
//    val edgesDot = es.map { case ((n1, n2), id) => "nd" + ns(n1) + " -> " + "nd" + ns(n2) + attributes(Map("id" -> ("e" + id)) ++ Map("label" -> (if (edgeLabel) relative(n1, n2).toString else ""))) + ";" }.reduce(_ + " " + _)
//    val vertexDot = ns.map { case (n, id) => "nd" + id + attributes(Map("id" -> ("n" + id)) ++ Map("label" -> absolute(n).toString)) + ";" }.reduce(_ + " " + _)
//
//    val options = if (horizontal) "rankdir=\"LR\";" else ""
//
//    Files.asCharSink(new File("temp/tempview.html"), Charsets.UTF_8).write(Files.asCharSource(new File("core/src/main/resources/viewer/viewer2.html"), Charsets.UTF_8).read()
//      .replace("digraph R {}", StringEscapeUtils.escapeJavaScript("digraph R {" + options + vertexDot + edgesDot + "}")))
//
//    Runtime.getRuntime.exec("rundll32 url.dll,FileProtocolHandler " + new File("temp/tempview.html").getAbsolutePath)
//  }
