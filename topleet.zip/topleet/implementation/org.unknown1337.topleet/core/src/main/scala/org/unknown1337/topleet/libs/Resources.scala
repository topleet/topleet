package org.unknown1337.topleet.libs

import java.io.InputStream
import java.nio.charset.Charset

import org.eclipse.jgit.lib.ObjectStream
import org.unknown1337.topleet.engines.Engine
import org.unknown1337.topleet.atypes.AMap._
import scala.reflect.{ClassTag => CT}

trait Resource {

  def read(charset: String): String

  def inputStream(): InputStream

}

trait Resources extends IO {

  type Path = String

  val engine: Engine

//  implicit class ResourcesProvide[N: CT](@transient l: engine.Leet[N, ABag[(Path, Resource)]]) extends Serializable {
//
//    def read(charset: String): engine.Leet[N, ABag[(Path, String)]] =
//      l.map { case (path, resource) => (path, resource.read(charset)) }
//  }

}
