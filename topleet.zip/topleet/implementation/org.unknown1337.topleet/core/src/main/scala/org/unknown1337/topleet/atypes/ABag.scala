//package org.unknown1337.topleet.atypes
//
//import org.unknown1337.topleet.Group
//
//
//object ABag {
//
//  implicit def bagGroup[T]: Group[ABag[T]] = new Group[ABag[T]] {
//    override def merge(v1: ABag[T], v2: ABag[T]): ABag[T] = ABag.merge(v1, v2)
//
//    override def inverse(v: ABag[T]): ABag[T] = ABag.inverse(v)
//
//    override def zero: ABag[T] = ABag.zero()
//  }
//
//  def toMap[T](x: ABag[T]): Map[T, Int] = x.value
//
//  //  def flatten[T](x: ABag[ABag[T]]): ABag[T] = ABag(x.value.toSeq.flatMap { case (bag, count1) => bag.value.toSeq.map { case (t, count2) => (t, count1 * count2) } }
//  //      .groupBy(_._1).map { case (k, vs) => (k, vs.map(_._2).sum) }.filter(_._2 != 0))
//
//  // TODO: Check if this is decreasing performance.
//  def flatten[T <: AType](x: ABag[T])(implicit tAbl: Group[T]): T = x.value.toSeq.flatMap {
//    case (t, count) if count > 0 => List.fill(count)(t)
//    case (t, count) if count < 0 => List.fill(-count)(tAbl.inverse(t))
//  }.fold(tAbl.zero)(tAbl.merge)
//
//
//  def count[T](x: ABag[T]): Int = x.value.toSeq.map { case (_, count) => count }.sum
//
//  def length[T](x: ABag[T]): Int = x.value.toSeq.map { case (_, count) => Math.abs(count) }.sum
//
//  def mean(x: ABag[Double]): Double = sumDouble(x) / count(x)
//
//  def sumDouble(x: ABag[Double]): Double = x.value.toSeq.map { case (v, count) => v * count.toDouble }.sum
//
//  def sumInt(x: ABag[Int]): Int = x.value.toSeq.map { case (v, count) => v * count }.sum
//
//  //  def groupBy[K, V](x: ABag[V])(by: V => K): Map[K, ABag[V]] =
//  //    x.value.toSeq.groupBy { case (v, _) => by(v) }.mapValues(x => ABag(x.toMap))
//
//  def group[K, V1, V2](x: ABag[(V1, V2)]): Map[V1, ABag[V2]] =
//    x.value.toSeq.groupBy { case ((k, _), _) => k }.map { case (k, v) => (k, ABag.map(ABag(v.toMap))(_._2)) }
//
//  def filter[T](x: ABag[T])(f: T => Boolean): ABag[T] = ABag(x.value.filter { case (t, _) => f(t) })
//
//  def map[T1, T2](bag: ABag[T1])(f: T1 => T2): ABag[T2] = ABag(bag.value.toSeq.map { case (v, count) => (f(v), count) }.groupBy(_._1).map { case (k, vs) => k -> vs.map(_._2).sum }
//    .filter(_._2 != 0))
//
//  def merge[T](bag1: ABag[T], bag2: ABag[T]): ABag[T] =
//    ABag((bag1.value.keySet ++ bag2.value.keySet)
//      .map(k => k -> (bag1.value.getOrElse(k, 0) + bag2.value.getOrElse(k, 0)))
//      .filter(_._2 != 0).toMap)
//
//  def inverse[T](bag: ABag[T]): ABag[T] = ABag(bag.value.map({
//    case (value, count) => (value, -count)
//  }))
//
//  def removeSeq[T](x: ABag[T]): Seq[T] = x.value.filter { case (_, count) => count < 0 }.flatMap { case (v, count) => List.fill(-count)(v) }.toSeq
//
//  def addSeq[T](x: ABag[T]): Seq[T] = x.value.filter { case (_, count) => count > 0 }.flatMap { case (v, count) => List.fill(count)(v) }.toSeq
//
//  def zero[T](): ABag[T] = ABag(Map[T, Int]())
//
//  def create[T](values: T*): ABag[T] = fromSeq(values.toSeq)
//
//  def fromSeq[T](seq: Seq[T]): ABag[T] = ABag(seq.groupBy(identity).map(x => (x._1, x._2.size)))
//
//  def fromSet[T](set: Set[T]): ABag[T] = ABag(set.map(x => (x, 1)).toMap)
//
//  def fromMap[K, V](map: Map[K, V]): ABag[(K, V)] = fromSet(map.toSet)
//
//  def toSeq[T](bag: ABag[T]): Seq[T] = bag.value.toSeq.flatMap { case (t, count) => Seq.fill(count)(t) }
//
//  def toSet[T](bag: ABag[T]): Set[T] = toSeq(bag).toSet
//}
//
//case class ABag[T](value: Map[T, Int]) extends AType {
//
//  def count(): Int = ABag.count(this)
//
//  override def pretty(): String = {
//    // Check if elements are strings and contain newlines.
//    if (value.keySet.nonEmpty && value.keySet.forall(_.isInstanceOf[String]) && value.exists(_._1.asInstanceOf[String].contains(System.getProperty("line.separator")))) {
//      val strings = ABag.toSeq(this).map(_.asInstanceOf[String])
//      val line = List.fill(strings.flatMap(_.split(System.getProperty("line.separator"))).map(_.length).max)("-").reduceOption(_ + _).getOrElse("---")
//      strings.reduce(_ + System.getProperty("line.separator") + line + System.getProperty("line.separator") + _) + System.getProperty("line.separator")
//    }
//    else "Bag(" +
//      (value.flatMap { case (v, count) => List.fill(Math.min(count, 5))(v.toString) ++ (if (count > 5 || count < (-5)) Seq("...") else Seq()) } ++
//        value.flatMap { case (v, count) => List.fill(Math.min(-count, 5))("-" + v.toString) ++ (if (count > 5 || count < (-5)) Seq("...") else Seq()) }
//        ).reduceOption(_ + "," + _).getOrElse("") + ")"
//  }
//
//  override def toString: String =
//    "ABag(" +
//      (value.flatMap { case (v, count) => List.fill(Math.min(count, 5))(v.toString) ++ (if (count > 5 || count < (-5)) Seq("...") else Seq()) } ++
//        value.flatMap { case (v, count) => List.fill(Math.min(-count, 5))("-" + v.toString) ++ (if (count > 5 || count < (-5)) Seq("...") else Seq()) }
//        ).reduceOption(_ + "," + _).getOrElse("") + ")"
//
//  override def ~=(other: AType): Boolean = {
//    if (!other.isInstanceOf[ABag[T]]) return false
//    val o = other.asInstanceOf[ABag[T]]
//
//    // This can be delegated to a map comparison.
//    val l = AMap(this.value.map {
//      case (k: Double, v) => (ADouble.toADouble(k), AInteger(v))
//      case (k, v) => (k, AInteger(v))
//    })
//
//    val r = AMap(o.value.map {
//      case (k: Double, v) =>
//        (ADouble.toADouble(k), AInteger(v))
//      case (k, v) => (k, AInteger(v))
//    })
//
//    l ~= r
//  }
//
//  override def isZero: Boolean = this == ABag.zero()
//
//  override def isApproxZero: Boolean =
//    AMap(this.value.map { case (k, v) => (k, AInteger(v)) }).isApproxZero
//
//  /**
//    * Length of the delta in terms of effort needed to conduct it.
//    */
//  override def dlength(): Double = value.toSeq.map(_._2).map(Math.abs).sum.toDouble
//}
