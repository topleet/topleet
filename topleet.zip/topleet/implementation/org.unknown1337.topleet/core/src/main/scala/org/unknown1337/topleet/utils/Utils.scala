package org.unknown1337.topleet.utils

import java.security.MessageDigest

import com.google.common.base.Charsets
import org.apache.commons.codec.digest.DigestUtils
import org.apache.commons.lang3.StringEscapeUtils
import org.unknown1337.topleet.atypes.AType
import org.unknown1337.topleet.utils.CSVSink.SinkType

import collection.JavaConverters._
import scala.collection.mutable.ListBuffer
import scala.collection.{immutable, mutable}
import scala.util.Random
import Numeric.Implicits._

object Utils {

  // TODO: This is cogroup.
  //  def joinmap[K, V1, V2](a: Map[K, V1], b: Map[K, V2], defaulta: V1, defaultb: V2): Map[K, (V1, V2)] = (a.keySet ++ b.keySet).map(k => (k, (a.getOrElse(k, defaulta), b.getOrElse(k, defaultb)))).toMap

  def mean[T: Numeric](xs: Iterable[T]): Double = xs.sum.toDouble / xs.size

  def variance[T: Numeric](xs: Iterable[T]): Double = {
    val avg = mean(xs)

    xs.map(_.toDouble).map(a => math.pow(a - avg, 2)).sum / xs.size
  }

  def std[T: Numeric](xs: Iterable[T]): Double = math.sqrt(variance(xs))

  def merge(a: Map[String, String], b: Map[String, String]): Map[String, String] =
    a.toSet.intersect(b.toSet).toMap

  def toJson(x: Map[String, String]) = x
    .map { case (x, y) => "\"" + StringEscapeUtils.escapeJson(x) + "\"" + ":" + "\"" + StringEscapeUtils.escapeJson(y) + "\"" }
    .reduceOption(_ + " ," + _)
    .getOrElse("")


  def toCsv(location: String, record: Iterable[Map[String, String]]): Unit = {
    val keys = record.map(_.keySet).reduce(_ ++ _).toSeq
    val csv = new CSVSink(location, Charsets.UTF_8, SinkType.STATIC, keys: _*)
    for (qs <- record) csv.write(qs.asJava)
    csv.close()
  }

  def printtb(xs: String*)(offsets: Int*): Unit = println(tb(xs: _*)(offsets: _*))

  def printerrtb(xs: String*)(offsets: Int*): Unit = System.out.println(tb(xs: _*)(offsets: _*))

  def tb(xs: String*)(offsets: Int*): String = {
    xs.zip(offsets).collect {
      case (x, offset) if x.length > offset => x.substring(0, offset - 3) + "..."
      case (x, offset) if x.length <= offset => x + List.fill(offset - x.length)(" ").foldLeft("")(_ + _)
    }.reduce(_ + " | " + _)
  }

  def dijkstra[N](paths: Map[N, Set[N]], start: Set[N]): Map[N, Int] = {
    // Initialized borde and distances.
    val distances = mutable.Map[N, Int]()
    val border = mutable.Queue[N]()
    for (s <- start) {
      distances.put(s, 0)
      border.enqueue(s)
    }
    while (border.nonEmpty) {
      val current = border.dequeue()
      val distance = distances(current)
      for (other <- paths.getOrElse(current, Set()) if !distances.isDefinedAt(other)) {
        border.enqueue(other)
        distances.put(other, distance + 1)
      }
    }
    distances.toMap
  }

  def paths[N](host: Set[(N, N)], nodes: Set[N]): Map[N, Set[N]] = {
    val in = host.toSeq.groupBy(_._2).mapValues(_.map(_._1)).withDefaultValue(Seq[N]()).mapValues(_.toSet)
    val out = host.toSeq.groupBy(_._1).mapValues(_.map(_._2)).withDefaultValue(Seq[N]()).mapValues(_.toSet)

    nodes.map(n => (n, in.getOrElse(n, Set()) ++ out.getOrElse(n, Set()))).toMap
  }

  /**
    * Creates a topological sorting with connected components chained after each other.
    */
  def tsCCSeq[N](edges: Set[(N, N)], nodes: Set[N]): Seq[N] = {
    val ccmapping = Utils.ccs2(edges, nodes)
    val ccs = ccmapping.values.toSet
    val ccnodes = Utils.groupByValue(ccmapping.toSeq)
    val ccedges = edges.groupBy { case (n, _) => ccmapping(n) }

    ccs.toSeq.flatMap { cc => Utils.ts(ccedges(cc), ccnodes(cc).toSet)}
  }

  /**
    * Connected components.  val es = Seq(("a", "b"), ("b", "c"), ("1", "2"), ("4", "3"), ("d", "u"))
    * TODO: Rewrite this into ccs.
    */
  def ccs2[N](edges: Set[(N, N)], nodes: Set[N]): Map[N, N] = {
    val cc = mutable.Map[N, N]()
    val icc = mutable.Map[N, Set[N]]()

    for (n <- nodes) {
      cc.put(n, n)
      icc.put(n, Set(n))
    }

    def merge(n1: N, n2: N): Unit = {
      icc.put(n1, icc(n1) ++ icc(n2))
      for (n <- icc.remove(n2).get) cc.put(n, n1)
    }

    for ((n1, n2) <- edges if cc(n1) != cc(n2)) {
      val cc1 = cc(n1)
      val cc2 = cc(n2)
      if (icc(cc1).size > icc(cc2).size)
        merge(cc1, cc2)
      else
        merge(cc2, cc1)
    }
    cc.toMap
  }

  def ccs[N](edges: Set[Set[N]], nodes: Set[N]): Map[N, N] = {
    val cc = mutable.Map[N, N]()
    val icc = mutable.Map[N, Set[N]]()

    for (n <- nodes) {
      cc.put(n, n)
      icc.put(n, Set(n))
    }

    def merge(mn: Set[N]): Unit = {
      val m = mn.map(cc)
      if (m.size > 1) {
        val head = m.maxBy(icc(_).size)
        icc.put(head, m.flatMap(n => icc(n)))
        for (n2 <- m.filter(_ != head); n <- icc.remove(n2).get) cc.put(n, head)
      }
    }

    for (m <- edges)
      merge(m)

    cc.toMap
  }

  def ccsMin[N, B](edges: Set[(N, N)], nodes: Set[N])(f: N => B)(implicit ordering: Ordering[B]): Map[N, N] = {
    val components = groupByKey(ccs2(edges, nodes).toSeq.map(_.swap)).map(_._2.toSet)
    components.map(x => (x.minBy(f), x)).flatMap { case (c, cs) => cs.map(x => (x, c)) }.toMap
  }

  def groupByKey[K, V](x: Seq[(K, V)]): Map[K, Seq[V]] = x.groupBy(_._1).map { case (k, vs) => (k, vs.map(_._2)) }

  def groupByValue[K, V](x: Seq[(K, V)]): Map[V, Seq[K]] = groupByKey(x.map(_.swap))

  def reduceByKey[K, V](tuples: Seq[(K, V)])(f: (V, V) => V): Map[K, V] = groupByKey(tuples).map { case (k, seq) => (k, seq.reduce(f)) }

  def cogroup[K, V1, V2](a: Iterable[(K, V1)], b: Iterable[(K, V2)]): immutable.Iterable[(K, Iterable[V1], Iterable[V2])] =
    (a.map { case (k, v) => (k, Some(v), None) } ++ b.map { case (k, v) => (k, None, Some(v)) }).groupBy(_._1).map { case (k, iterable) =>
      val v1s = iterable.flatMap(_._2)
      val v2s = iterable.flatMap(_._3)

      (k, v1s, v2s)
    }

  def incoming[N](host: Set[(N, N)], nodes: Set[N]): Map[N, Set[N]] = {
    val in = host.toSeq.groupBy(_._2).mapValues(_.map(_._1)).withDefaultValue(Seq[N]())
    nodes.map(n => (n, in.getOrElse(n, Seq()).toSet)).toMap
  }

  def outgoing[N](host: Set[(N, N)], nodes: Set[N]): Map[N, Set[N]] = {
    val out = host.toSeq.groupBy(_._1).mapValues(_.map(_._2)).withDefaultValue(Seq[N]())
    nodes.map(n => (n, out.getOrElse(n, Seq()).toSet)).toMap
  }

  //  def nodes[N](host: Set[(N, N)]): Set[N] = host.flatMap(x => Seq(x._1, x._2))

  def roots[N](edges: Set[(N, N)], nodes: Set[N]): Set[N] =
    incoming(edges, nodes).collect { case (n, ns) if ns.isEmpty => n }.toSet

  def leafs[N](edges: Set[(N, N)], nodes: Set[N]): Set[N] =
    outgoing(edges, nodes).collect { case (n, ns) if ns.isEmpty => n }.toSet

  def tsOrdering[N](edges: Set[(N, N)], nodes: Set[N])(implicit ord: Ordering[N]): Iterator[N] = {
    val ins = incoming(edges, nodes)
    val outs = outgoing(edges, nodes)

    val border = mutable.PriorityQueue[N]()(ord)
    val visited = mutable.Set[N]()
    nodes.filter(x => ins(x).isEmpty).foreach(border.enqueue(_))

    Iterator.fill(nodes.size) {
      // Take a random node from the border
      val current = border.dequeue()
      visited.add(current)
      // Add now available elements to the border.
      for (o <- outs(current) if ins(o).forall(visited))
        border.enqueue(o)

      current
    }
  }

  def ts[N](edges: Set[(N, N)], nodes: Set[N]): Iterator[N] = {
    val ins = incoming(edges, nodes)
    val outs = outgoing(edges, nodes)

    val border = mutable.Queue[N]()
    val visited = mutable.Set[N]()
    nodes.filter(x => ins(x).isEmpty).foreach(border.enqueue(_))

    Iterator.fill(nodes.size) {
      // Take a random node from the border
      val current = border.dequeue()
      visited.add(current)
      // Add now available elements to the border.
      for (o <- outs(current) if ins(o).forall(visited))
        border.enqueue(o)

      current
    }
  }

  //
  //
  //  def ts[N](edges: Set[(N, N)], nodes: Set[N]): Seq[N] = {
  //    val result = mutable.Buffer[N]()
  //    val visited = mutable.Set[N]()
  //    val border = mutable.Queue[N]()
  //    val in = incoming(edges, nodes)
  //    val out = outgoing(edges, nodes)
  //
  //    nodes.filter(v => in(v).isEmpty).foreach(border.enqueue(_))
  //
  //    while (border.nonEmpty) {
  //      val current = border.dequeue()
  //      if (!visited(current)) {
  //        if (in(current).forall(visited)) {
  //          // New element appended.
  //          visited.add(current)
  //          result.append(current)
  //
  //          assert(out(current).forall(!visited(_)))
  //
  //          out(current).foreach(border.enqueue(_))
  //        } else {
  //          border.enqueue(current)
  //        }
  //      }
  //    }
  //    result
  //  }

}
