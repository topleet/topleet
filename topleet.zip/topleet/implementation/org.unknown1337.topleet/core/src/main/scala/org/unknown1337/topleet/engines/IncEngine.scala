package org.unknown1337.topleet.engines

import org.unknown1337.topleet.atypes._
import org.unknown1337.topleet.atypes.AMap._
import org.unknown1337.topleet.Group
import org.unknown1337.topleet.utils.Utils

import scala.collection.mutable
import scala.reflect.{ClassTag => CT, _}

object IncEngine {
  def apply(threshold: Int = 32, split: Int = 2, newix: Boolean = true): IncEngine = new IncEngine(threshold, split, newix)
}

class IncEngine(threshold: Int = 32, split: Int = 2, newix: Boolean = true) extends BaseEngine with Serializable {

  case class IncEngineLeet[N, V <: AType](delta: Map[(N, N), V], nodes: Set[N], checkpoints: Map[N, V], abelian: Group[V])

  override type Leet[N, V <: AType] = IncEngineLeet[N, V]

  override type PairLeet[N, K, V <: AType] = IncEngineLeet[N, AMap[K,V]]

  def congruent[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: IncEngineLeet[N, V1], l2: IncEngineLeet[N, V2]): Unit = {
    assert(l1.nodes == l2.nodes)
    assert(l1.delta.keySet == l2.delta.keySet)
    assert(l1.checkpoints.keySet == l2.checkpoints.keySet)
  }

  def createIncEngineLeet[N: CT, V <: AType : CT](delta: Map[(N, N), V], nodes: Set[N], checkpoints: Map[N, V], abelian: Group[V]): IncEngineLeet[N, V] =
    IncEngineLeet(delta, nodes, checkpoints, abelian)


  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): IncEngineLeet[N, V] = {
    // Connected components in graph.
    val locations = Utils.groupByKey(Utils.ccs2(edges, nodes.keySet).toSeq.map(_.swap)).map(_._2.head).toSet
    // Every connected component needs one checkpoint.
    val newCheckpoints = locations.map { x => (x, nodes(x)) }.toMap
    val newDelta = edges.map { case (n1, n2) => ((n1, n2), vAbelian.merge(vAbelian.inverse(nodes(n1)), nodes(n2))) }.toMap
    IncEngineLeet(newDelta, nodes.keySet, newCheckpoints, vAbelian)
  }

  override def zero[N: CT, V <: AType : CT](l: IncEngineLeet[N, V]): IncEngineLeet[N, V] = {
    val newCheckpoints = l.checkpoints.map { case (n, v) => (n, l.abelian.inverse(v)) }
    val newDelta = l.delta.mapValues(l.abelian.inverse)
    IncEngineLeet(newDelta, l.nodes, newCheckpoints, l.abelian)
  }

  def moveCheckpoints[N: CT, V <: AType : CT](l: IncEngineLeet[N, V], locations: Set[N]): IncEngineLeet[N, V] = {
    if (locations == l.checkpoints.keySet) l
    else {
      // Compute the distance to existing checkpoints for each new location.
      implicit val abl = abelian(l)
      val distances = distance(l.delta, l.nodes, l.checkpoints.keySet, locations)
      val newCheckpoints = distances.map { case ((from, to), v) => (to, abl.merge(l.checkpoints(from), v)) }.toMap
      // Replace the checkpoints.
      IncEngineLeet(l.delta, l.nodes, newCheckpoints, l.abelian)
    }
  }

  override def merge[N: CT, V <: AType : CT](l1: IncEngineLeet[N, V], ll2: IncEngineLeet[N, V]): IncEngineLeet[N, V] = {
    val l2 = moveCheckpoints(ll2, l1.checkpoints.keySet)
    congruent(l1, l2)

    val newCheckpoints = l1.checkpoints.keys.map(k => k -> l1.abelian.merge(l1.checkpoints(k), l2.checkpoints(k))).toMap
    val newDelta = l1.delta.keys.map(k => k -> l1.abelian.merge(l1.delta(k), l2.delta(k))).toMap
    IncEngineLeet(newDelta, l1.nodes, newCheckpoints, l1.abelian)
  }

  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: IncEngineLeet[N, V1], ll2: IncEngineLeet[N, V2]): IncEngineLeet[N, ATuple[V1, V2]] = {
    val l2 = moveCheckpoints(ll2, l1.checkpoints.keySet)
    congruent(l1, l2)

    val newCheckpoints = l1.checkpoints.keys.map(k => k -> ATuple(l1.checkpoints(k), l2.checkpoints(k))).toMap
    val newDelta = l1.delta.keys.map(k => k -> ATuple(l1.delta(k), l2.delta(k))).toMap
    IncEngineLeet(newDelta, l1.nodes, newCheckpoints, ATuple.aTupleGroup(l1.abelian, l2.abelian))
  }

  override def relativeValues[N: CT, V <: AType : CT](l: IncEngineLeet[N, V]): Iterator[((N, N), V)] =
    l.delta.toIterator

  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncEngineLeet[N, V2] = {
    val (contracted, mapping) = contractZero(l)
    // TODO: This can be optimized.
    val results = values(contracted).map { case (n, v) => (n, f(v)) }.toMap
    val newCheckpoints = contracted.checkpoints.map { case (n, v) => (n, f(v)) }
    val newDelta = contracted.delta.keys.map { case (n1, n2) => ((n1, n2), v2Abelian.diff(results(n1), results(n2))) }.toMap
    val newContracted = IncEngineLeet(newDelta, contracted.nodes, newCheckpoints, v2Abelian)
    uncontract(newContracted, l, mapping)
  }

  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncEngineLeet[N, V2] = {
    val newCheckpoints = l.checkpoints.map { case (n, v) => (n, f(v)) }
    val newDelta = l.delta.map { case ((n1, n2), v) => ((n1, n2), f(v)) }
    IncEngineLeet(newDelta, l.nodes, newCheckpoints, v2Abelian)
  }


//  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncEngineLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): IncEngineLeet[N, V2] =
//    if (newix)
//      tmapIxRegular(l)(f)
//    else
//      tmapIxContract(l)(f)

  def tmapIxRegular[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncEngineLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): IncEngineLeet[N, V2] = {
    implicit val a: Group[AMap[K, V1]] = l.abelian
    implicit val av: Group[V1] = l.abelian.asInstanceOf[AbelianAMap[K, V1]].vAbelian
    val in = incoming(l)

    val newDelta = distance(l.delta, l.nodes, l.checkpoints.keySet, l.nodes).flatMap { case ((from, to), offset) =>
      val checkpoint = l.checkpoints(from)
      in(to).map { i =>
        val delta = l.delta(i, to)
        val outDelta = delta.keys().map { k =>
          val valueTo = av.merge(checkpoint.getOrElse(k, av.zero), offset.getOrElse(k, av.zero))
          val valueFrom = av.merge(valueTo, av.inverse(delta(k)))

          // We assume that zero values (meaning that nothing is in the map) are again mapped to zero in v2.
          val fvTo = if (!valueTo.isZero) f(k, valueTo) else v2Abelian.zero
          val fvFrom = if (!valueFrom.isZero) f(k, valueFrom) else v2Abelian.zero
          v2Abelian.diff(fvFrom, fvTo)
        }.reduceOption(v2Abelian.merge).getOrElse(v2Abelian.zero)

        ((i, to), outDelta)
      }
    }.toMap

    val newCheckpoints = l.checkpoints.map { case (k, v) => (k, v.mapValues(f)) }
    IncEngineLeet(newDelta, l.nodes, newCheckpoints, v2Abelian)
  }

  def tmapIxContract[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncEngineLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): IncEngineLeet[N, V2] = {
    implicit val v1mapAbelian: Group[AMap[K, V1]] = l.abelian

    def inner(l: IncEngineLeet[N, AMap[K, V1]], index: Set[K]): IncEngineLeet[N, V2] =
      if (index.size <= threshold) {
        // Application of the function.
        val out = tmap(l)(x => x.mapValues(f))
        // Drop checkpoints before un-contracting as it is not needed anymore.
        IncEngineLeet(out.delta, out.nodes, Map(), out.abelian)
      } else {
        // Bisection.
        (for (slice <- index.grouped(Math.max(1, index.size / split))) yield {
          // Filter on key set.
          val filtered = tmapHom(l)(x => x.filter { k => slice(k) })
          // Contract empty delta.
          val (pruned, mapping) = contractZero(filtered)
          // Group recursive call and map back results on this topology.
          uncontract(inner(pruned, slice), l, mapping)
        }).reduce(merge(_, _))
      }

    val out = inner(l, keys(l))

    // Compute fresh checkpoints and add to the data structure.
    val newCheckpoints = l.checkpoints.map { case (k, v) => (k, v.mapValues(f)) }
    IncEngineLeet(out.delta, out.nodes, newCheckpoints, out.abelian)
  }

//  override def cartesian[N: CT, V1: CT, V2: CT](l1: IncEngineLeet[N, ABag[V1]], l2: IncEngineLeet[N, ABag[V2]]): IncEngineLeet[N, ABag[(V1, V2)]] = {
//
//    // TODO: Might also be slower that some index based version.
//    def inner(ll1: IncEngineLeet[N, ABag[V1]], ll2: IncEngineLeet[N, ABag[V2]], index1: Set[V1], index2: Set[V2]): IncEngineLeet[N, ABag[(V1, V2)]] = {
//      // Stop if bags on both sides are small.
//      val AInteger(max1) = reduce(tmapHom(ll1)(x => AInteger(x.count)))(AInteger.max)
//      val AInteger(max2) = reduce(tmapHom(ll2)(x => AInteger(x.count)))(AInteger.max)
//      // TODO: The last thing is a have as is does not notice same elements (this requires a distinct and is not wanted).
//      if (index1.size * index2.size <= threshold || max1 * max2 <= 1) {
//        // Application of the cartesian.
//        val out = super.cartesian(ll1, ll2)
//        // Drop checkpoints before un-contracting as it is not needed anymore.
//        IncEngineLeet(out.delta, out.nodes, Map(), out.abelian)
//      } else {
//        // 2-dimensional Bisection to make bags smaller.
//        (for (slice1 <- index1.grouped(Math.max(1, index1.size / split));
//              slice2 <- index2.grouped(Math.max(1, index2.size / split))) yield {
//          // Filter on key set.
//          val filtered1 = tmapHom(ll1)(x => x.filter(slice1))
//          val filtered2 = tmapHom(ll2)(x => x.filter(slice2))
//
//          // Fine the nodes with no elements in the bag.
//          val empty1 = values(tmapHom(filtered1)(x => AInteger(x.count))).collect { case (n, AInteger(0)) => n }.toSet
//          val empty2 = values(tmapHom(filtered2)(x => AInteger(x.count))).collect { case (n, AInteger(0)) => n }.toSet
//
//          // Contract edges that are zero in both topologies and those that
//          // connect two zero values in one off both topologies (Can be determined by bags count).
//          val edgesWithNoDelta = zeroEdges(filtered1).intersect(zeroEdges(filtered2))
//          val edgesBetweenEmptyNodes = edges(ll1).filter { case (n1, n2) => (empty1(n1) && empty1(n2)) || empty2(n1) && empty2(n2) }
//
//          val (pruned1, mapping) = contractEdges(filtered1, edgesWithNoDelta ++ edgesBetweenEmptyNodes)
//          val pruned2 = contract(filtered2, mapping)
//
//          // Group recursive call and map back results on this topology.
//          uncontract(inner(pruned1, pruned2, slice1, slice2), ll1, mapping)
//        }).reduce(merge(_, _))
//      }
//    }
//
//    // TODO: Distinct values needed here instead of keys.
//    val index1 = (l1.delta.values ++ l1.checkpoints.values).flatMap(v => v.value.keySet).toSet
//    val index2 = (l2.delta.values ++ l2.checkpoints.values).flatMap(v => v.value.keySet).toSet
//    val out = inner(l1, l2, index1, index2)
//
//    // Compute fresh checkpoints and add to the data structure.
//    val sg1 = subgraph(l1, l1.checkpoints.keySet)
//    val sg2 = subgraph(l2, l1.checkpoints.keySet)
//    val newCheckpoints = super.cartesian(sg1, sg2).checkpoints
//
//    IncEngineLeet(out.delta, out.nodes, newCheckpoints, out.abelian)
//  }

  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: IncEngineLeet[N, AMap[K, V]]): IncEngineLeet[N, AMap[K, V]] = {
    implicit val abl: Group[AMap[K, V]] = l.abelian

    // The acDelta is processed node-wise.
    def inner(il: IncEngineLeet[N, AMap[K, V]], index: Set[K]): Map[N, AMap[K, V]] =
      if (index.size <= threshold) {
        // Application of acDelta.
        values(acDelta(il)).toMap
      } else {
        // Bisection.
        (for (slice <- index.grouped(Math.max(1, index.size / split))) yield {
          // Filter on key set.
          val filtered = tmapHom(il)(x => x.filter { k => slice(k) })
          // Contract empty delta in strict mode but remove bypassing edges.
          val (pruned, _) = contractZero(filtered)
          // Group recursive call.
          inner(maskBypassEdges(pruned), slice)
        }).foldLeft(Map[N, AMap[K, V]]()) {
          case (ll, rr) => (ll.keySet ++ rr.keySet).map(k => (k, abl.merge(ll.getOrElse(k, abl.zero), rr.getOrElse(k, abl.zero)))).toMap
        }
      }

    // TODO: This is the key method.
    val index = (l.checkpoints.values ++ l.delta.values).flatMap(v => v.value.keySet).toSet
    val newValues = inner(l, index).withDefaultValue(abl.zero)
    val newCeckpoints = l.checkpoints.keySet.map(n => (n, newValues(n))).toMap
    val newDelta = edges(l).map { case (n1, n2) => ((n1, n2), abl.diff(newValues(n1), newValues(n2))) }.toMap
    IncEngineLeet(newDelta, l.nodes, newCeckpoints, abl)
  }

  override def zeroEdges[N: CT, V <: AType : CT](l: IncEngineLeet[N, V]): Set[(N, N)] =
    l.delta.filter(_._2 == l.abelian.zero).keySet

  override def reduce[N: CT, V <: AType : CT](l: IncEngineLeet[N, V])(f: (V, V) => V): V =
    values(l).map(_._2).reduce(f)

  override def edges[N: CT, V <: AType : CT](l: IncEngineLeet[N, V]): Set[(N, N)] =
    l.delta.keySet

  override def nodes[N: CT, T <: AType : CT](l: IncEngineLeet[N, T]): Set[N] =
    l.delta.keySet.flatMap { case (n1, n2) => Set(n1, n2) } ++ l.checkpoints.keySet

  override def abelian[N: CT, T <: AType : CT](l: IncEngineLeet[N, T]): Group[T] =
    l.abelian

  override def values[N: CT, V <: AType : CT](l: IncEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] = {
    implicit val abl: Group[V] = abelian(l)
    distance(l.delta, l.nodes, l.checkpoints.keySet, on).map { case ((from, to), dist) => (to, abl.merge(l.checkpoints(from), dist)) }
  }

  /**
    * Computes the distance between from and to. For each to nodes a distance is contained but not necessary all from
    * nodes are used. Returns ((from,to),diff).
    */
  def distance[N: CT, V <: AType : CT](delta: Map[(N, N), V], nodes: Set[N], froms: Set[N], tos: Set[N])(implicit abl: Group[V]): Iterator[((N, N), V)] = {
    // Temp graph data.
    val in = Utils.incoming(delta.keySet, nodes)
    val out = Utils.outgoing(delta.keySet, nodes)
    // In out with empty nodes.
    val inOut = Utils.groupByKey(
      in.toSeq.flatMap { case (n, ns) => ns.map(x => (n, (true, x))) } ++
        out.toSeq.flatMap { case (n, ns) => ns.map(x => (n, (false, x))) }) ++
      nodes.collect { case n if in(n).isEmpty && out(n).isEmpty => (n, Seq[(Boolean, N)]()) }.toMap

    // Compute the Dijkstra.
    val hops = Utils.dijkstra(inOut.map { case (k, v) => (k, v.map(_._2).toSet) }, froms)

    // Cache for already computed to nodes.
    // TODO: Indeed an easy way is to used the distance computed by dijkstra!
    val cache = mutable.Map[N, (N, V)]()

    // Recursive computation of the distance along the hops.
    def compute(x: N): (N, V) = x match {
      case to if froms.contains(to) => (to, abl.zero)
      // Check if already computed or computes the distance.
      case to => cache.getOrElseUpdate(to, {

        // Find neighbour with lowest hop count.
        val neighbours = inOut(to)
        val (isIncoming, neighbour) = neighbours.minBy { case (_, n) => hops(n) }

        //  Recursively compute the neighbour's distance.
        val (from, dist) = compute(neighbour)

        // Apply the delta to this node.
        val result =
          if (isIncoming) abl.merge(dist, delta(neighbour, to))
          else abl.merge(dist, abl.inverse(delta(to, neighbour)))

        (from, result)
      })
    }

    // Steam based mapping to distances between froms.
    tos.map(n => (n, hops(n))).toSeq.sortBy(_._2).toIterator.map { case (to, hop) =>
      val (f, d) = compute(to)
      val del = cache.keys.filter(n => hops(n) < hop - 1)
      del.foreach(cache.remove)
      ((f, to), d)
    }
  }

  override def contract[N: CT, V <: AType : CT](l: IncEngineLeet[N, V], mapping: Map[N, N]): IncEngineLeet[N, V] = {
    assert(mapping.values.forall(l.nodes))
    implicit val abl: Group[V] = abelian(l)
    // Compute the distances along contraction edges.
    val patches = distance(
      // Graph structure.
      l.delta.filter { case ((n1, n2), _) => mapping(n1) == mapping(n2) },
      l.nodes,
      // From
      mapping.values.toSet,
      // To
      mapping.keySet)
      // Make distance to patch.
      .map { case ((_, to), v) => (to, v) }
      .toMap

    // Map checkpoints
    val newCheckpoints = l.checkpoints.map { case (n, v) => (mapping(n), abl.merge(v, abl.inverse(patches(n)))) }

    // Traverse all edges, patch the delta, rename the nodes and delete duplicate edges (last done by map semantics).
    val newDelta = l.delta.collect { case ((n1, n2), v) if mapping(n1) != mapping(n2) =>
      val r = abl.diff(patches(n2), abl.merge(patches(n1), v))
      ((mapping(n1), mapping(n2)), r)
    }

    IncEngineLeet(newDelta, mapping.values.toSet, newCheckpoints, l.abelian)
  }

  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncEngineLeet[N, V1], to: IncEngineLeet[N, V2], mapping: Map[N, N]): IncEngineLeet[N, V1] = {
    // Reuse old checkpoint positions (if possible).
    val newCheckpoints = to.checkpoints.keys.collect {
      case n if l.checkpoints.isDefinedAt(mapping(n)) => (n, l.checkpoints(mapping(n)))
    }.toMap
    // Traverse the edges and restore delta if such is located between super-nodes.
    val newDelta = edges(to).map {
      case (n1, n2) if mapping(n1) == mapping(n2) => ((n1, n2), l.abelian.zero)
      case (n1, n2) if mapping(n1) != mapping(n2) => ((n1, n2), l.delta(mapping(n1), mapping(n2)))
    }.toMap

    IncEngineLeet(newDelta, nodes(to), newCheckpoints, l.abelian)
  }

  override def subgraph[N: CT, V <: AType : CT](l: IncEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): IncEngineLeet[N, V] = {
    val temp = moveCheckpoints(l, Utils.groupByKey(Utils.ccs2(edges, nodes).toSeq.map(_.swap)).map(_._2.head).toSet)
    IncEngineLeet(temp.delta.filterKeys(edges), temp.nodes.filter(nodes), temp.checkpoints, temp.abelian)
  }

  // TODO: Not sure if this method is correct.
  override def append[N: CT, V <: AType : CT](l1: IncEngineLeet[N, V], l2: IncEngineLeet[N, V]): IncEngineLeet[N, V] = {
    // TODO: Append might compute new edges.
    assert((l1.delta.keySet ++ l2.delta.keySet).forall(n => !l1.delta.isDefinedAt(n) || !l2.delta.isDefinedAt(n) || l1.delta.get(n) == l2.delta.get(n)))
    assert((l1.checkpoints.keySet ++ l2.checkpoints.keySet).forall(n => !l1.checkpoints.isDefinedAt(n) || !l2.checkpoints.isDefinedAt(n) || l1.checkpoints.get(n) == l2.checkpoints.get(n)))

    val newDelta = l1.delta ++ l2.delta
    // TODO: Thin out if possible.
    val newCheckpoints = l1.checkpoints ++ l2.checkpoints

    IncEngineLeet(newDelta, l1.nodes ++ l2.nodes, newCheckpoints, l1.abelian)
  }

  override def reverse[N: CT, V <: AType : CT](l: IncEngineLeet[N, V]): IncEngineLeet[N, V] =
    IncEngineLeet(l.delta.map { case ((n1, n2), delta) => ((n2, n1), l.abelian.inverse(delta)) }, l.nodes, l.checkpoints, l.abelian)

  override def force[N: CT, T <: AType : CT](l: IncEngineLeet[N, T]): IncEngineLeet[N, T] =
    IncEngineLeet(l.delta.view.force, l.nodes, l.checkpoints.view.force, l.abelian)

  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: IncEngineLeet[N1, V])(f: N1 => N2): IncEngineLeet[N2, V] = {
    val newCheckpoints = l.checkpoints.map { case (n, v) => (f(n), v) }
    val newDelta = l.delta.map { case ((n1, n2), v) => ((f(n1), f(n2)), v) }
    val newNodes = l.nodes.map(n => f(n))
    IncEngineLeet(newDelta, newNodes, newCheckpoints, l.abelian)
  }

  override def authorshipIx[N: CT, K: CT](l: IncEngineLeet[N, AMap[K, ADouble]]): IncEngineLeet[N, AMap[(N, K), ADouble]] = {
    implicit val abl: Group[AMap[(N, K), ADouble]] = AMap.aMapGroup[(N, K), ADouble](ADouble.aDoubleGroup)

    // TODO: Try to extract this contraction pattern.
    def inner(l: IncEngineLeet[N, AMap[K, ADouble]], index: Set[K]): IncEngineLeet[N, AMap[(N, K), ADouble]] =
      if (index.size <= threshold) {
        // Application of the function.
        super.authorshipIx(l)
      } else {
        // Bisection.
        (for (slice <- index.grouped(Math.max(1, index.size / split))) yield {
          // Filter on key set.
          val filtered = tmapHom(l)(x => x.filter { k => slice(k) })
          // Contract empty delta.
          val (pruned, mapping) = contractZero(filtered)
          // Group recursive call and map back results on this topology.
          uncontract(inner(pruned, slice), l, mapping)
        }).reduce(merge(_, _))
      }

    inner(l, keys(l))
  }

  override def keys[N: CT, K: CT, V <: AType : CT](l: IncEngineLeet[N, AMap[K, V]]): Set[K] = (l.checkpoints.values ++ l.delta.values).flatMap(v => v.value.keySet).toSet

  override implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: IncEngineLeet[N, AMap[K, V]]): IncEngineLeet[N, AMap[K, V]] = pairLeet

  override implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: IncEngineLeet[N, AMap[K, V]]): IncEngineLeet[N, AMap[K, V]] = leet
}