package org.unknown1337.topleet.engines

import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes._
import org.unknown1337.topleet.utils.Utils

import scala.collection.mutable.ArrayBuffer
import scala.reflect.{ClassTag => CT, _}
import AMap._

case class DelegateCheckEngine(e1: Engine, e2: Engine) extends Engine {

  case class DelegateCheckEngineLeet[N, V <: AType](l1: e1.Leet[N, V], l2: e2.Leet[N, V])

  case class DelegateCheckEnginePairLeet[N, K, V <: AType](l1: e1.PairLeet[N, K, V], l2: e2.PairLeet[N, K, V])

  override type Leet[N, V <: AType] = DelegateCheckEngineLeet[N, V]

  override type PairLeet[N, K, V <: AType] = DelegateCheckEnginePairLeet[N, K, V]

  override def close(): Unit = {
    e1.close()
    e2.close()
  }

  def check[N: CT, K: CT, V <: AType : CT](l1: e1.PairLeet[N, K, V], l2: e2.PairLeet[N, K, V]): Unit = {
    val n1 = e1.nodesIx(l1)
    val n2 = e2.nodesIx(l2)
    val ed1 = e1.edgesIx(l1)
    val ed2 = e2.edgesIx(l2)

    assert(n1 == n2)
    assert(ed1 == ed2)

    val v1 = e1.valuesIx(l1).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (_, v1, v2) => (v1, v2) }.toMap)) }
    val v2 = e2.valuesIx(l2).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (_, v1, v2) => (v1, v2) }.toMap)) }


    val rv1 = e1.relativeValuesIx(l1).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (_, (v1, v2)) => (v1, v2) }.toMap)) }
    val rv2 = e2.relativeValuesIx(l2).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (_, (v1, v2)) => (v1, v2) }.toMap)) }

    val errorsrel = (rv1.keySet ++ rv2.keySet)
      .map { k => (k, rv1.get(k), rv2.get(k)) }
      .filter {
        case (k, None, _) => true
        case (k, _, None) => true
        case (k, Some(l), Some(r)) => !(l ~= r)
      }

    val errors = (v1.keySet ++ v2.keySet)
      .map { k => (k, v1.get(k), v2.get(k)) }
      .filter {
        case (k, None, _) => true
        case (k, _, None) => true
        case (k, Some(l), Some(r)) => !(l ~= r)
      }

    if (errors.nonEmpty || errorsrel.nonEmpty) {
      println("#### Errors Abs ########################")
      for ((n, vv1, vv2) <- errors) {
        println("####" + n)

        println(vv1)
        println(vv2)
      }
      println("#### Errors Rel########################")
      for ((n, vv1, vv2) <- errorsrel) {
        println("####" + n)

        println(vv1)
        println(vv2)
      }
      assert(false)
    }
  }

  def check[N: CT, V <: AType : CT](l1: e1.Leet[N, V], l2: e2.Leet[N, V]): Unit = {
    val n1 = e1.nodes(l1)
    val n2 = e2.nodes(l2)
    val ed1 = e1.edges(l1)
    val ed2 = e2.edges(l2)

    assert(n1 == n2)
    assert(ed1 == ed2)

    val v1 = e1.values(l1).toMap
    val v2 = e2.values(l2).toMap

    //    if (fail) {
    //      println("engine 1: " + v1)
    //      println("engine 2: " + v2)
    //    }
    //

    val errors = (v1.keySet ++ v2.keySet)
      .map { k => (k, v1.get(k), v2.get(k)) }
      .filter { case (k, Some(l), Some(r)) => !(l ~= r) }

    if (errors.nonEmpty) {
      println("#### Errors ########################")
      for ((n, vv1, vv2) <- errors) {
        println("####" + n)

        println(vv1)
        println(vv2)
      }
      println("#### Errors ########################")
      assert(false)
    }
  }

  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): DelegateCheckEngineLeet[N, V] = {
    val l1 = e1.create(edges, nodes)
    val l2 = e2.create(edges, nodes)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }

  override def createIx[N: CT, K: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, AMap[K, V]])(implicit vAbelian: Group[V]): DelegateCheckEnginePairLeet[N, K, V] = {
    val l1 = e1.createIx(edges, nodes)
    val l2 = e2.createIx(edges, nodes)

    check(l1, l2)
    DelegateCheckEnginePairLeet(l1, l2)
  }

  //  override def cartesian[N: CT, V1: CT, V2: CT](l1: DelegateCheckEngineLeet[N, ABag[V1]], l2: DelegateCheckEngineLeet[N, ABag[V2]]): DelegateCheckEngineLeet[N, ABag[(V1, V2)]] = {
  //    check(l1.l1, l1.l2)
  //    check(l2.l1, l2.l2)
  //
  //    val ll1 = e1.cartesian(l1.l1, l2.l1)
  //    val ll2 = e2.cartesian(l1.l2, l2.l2)
  //
  //    check(ll1, ll2)
  //    DelegateCheckEngineLeet(ll1, ll2)
  //  }

  override def merge[N: CT, V <: AType : CT](l1: DelegateCheckEngineLeet[N, V], l2: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l1.l1, l1.l2)
    check(l2.l1, l2.l2)

    val ll1 = e1.merge(l1.l1, l2.l1)
    val ll2 = e2.merge(l1.l2, l2.l2)

    check(ll1, ll2)
    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def mergeIx[N: CT, K: CT, V <: AType : CT](l1: DelegateCheckEnginePairLeet[N, K, V], l2: DelegateCheckEnginePairLeet[N, K, V]): DelegateCheckEnginePairLeet[N, K, V] = {
    check(l1.l1, l1.l2)
    check(l2.l1, l2.l2)

    val ll1 = e1.mergeIx(l1.l1, l2.l1)
    val ll2 = e2.mergeIx(l1.l2, l2.l2)

    check(ll1, ll2)
    DelegateCheckEnginePairLeet(ll1, ll2)
  }


  override def zero[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val l1 = e1.zero(l.l1)
    val l2 = e2.zero(l.l2)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }


  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: DelegateCheckEngineLeet[N, V1], l2: DelegateCheckEngineLeet[N, V2]): DelegateCheckEngineLeet[N, ATuple[V1, V2]] = {
    check(l1.l1, l1.l2)
    check(l2.l1, l2.l2)

    val ll1 = e1.product(l1.l1, l2.l1)
    val ll2 = e2.product(l1.l2, l2.l2)

    check(ll1, ll2)
    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def productIx[N: CT, K1: CT, V1 <: AType : CT, K2: CT, V2 <: AType : CT](l1: DelegateCheckEnginePairLeet[N, K1, V1], l2: DelegateCheckEnginePairLeet[N, K2, V2]): DelegateCheckEnginePairLeet[N, (K1, K2), ATuple[V1, V2]] = {
    check(l1.l1, l1.l2)
    check(l2.l1, l2.l2)

    val ll1 = e1.productIx(l1.l1, l2.l1)
    val ll2 = e2.productIx(l1.l2, l2.l2)

    check(ll1, ll2)
    DelegateCheckEnginePairLeet(ll1, ll2)
  }


  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DelegateCheckEngineLeet[N, V2] = {
    check(l.l1, l.l2)

    val l1 = e1.tmap(l.l1)(f)
    val l2 = e2.tmap(l.l2)(f)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }


  override def tmapDynamic[N: CT, K1: CT, K2: CT, V1 <: AType : CT](l: DelegateCheckEnginePairLeet[N, K1, V1])(f: K1 => K2): DelegateCheckEnginePairLeet[N, K2, V1] = {
    check(l.l1, l.l2)

    val l1 = e1.tmapDynamic(l.l1)(f)
    val l2 = e2.tmapDynamic(l.l2)(f)

    check(l1, l2)
    DelegateCheckEnginePairLeet(l1, l2)
  }


  override def tmapIx[N: CT, K: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V1])(f: (K, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): DelegateCheckEnginePairLeet[N, K2, V2] = {
    check(l.l1, l.l2)

    val l1 = e1.tmapIx(l.l1)(f)
    val l2 = e2.tmapIx(l.l2)(f)

    check(l1, l2)
    DelegateCheckEnginePairLeet(l1, l2)
  }


  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DelegateCheckEngineLeet[N, V2] = {
    check(l.l1, l.l2)

    val l1 = e1.tmapHom(l.l1)(f)
    val l2 = e2.tmapHom(l.l2)(f)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }


  override def tmapHomIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEnginePairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): DelegateCheckEnginePairLeet[N, K2, V2] = {
    check(l.l1, l.l2)

    val l1 = e1.tmapHomIx(l.l1)(f)
    val l2 = e2.tmapHomIx(l.l2)(f)

    check(l1, l2)
    DelegateCheckEnginePairLeet(l1, l2)
  }


  override def tmapHomLinIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEnginePairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): DelegateCheckEnginePairLeet[N, K2, V2] = {
    check(l.l1, l.l2)

    val l1 = e1.tmapHomLinIx(l.l1)(f)
    val l2 = e2.tmapHomLinIx(l.l2)(f)

    check(l1, l2)
    DelegateCheckEnginePairLeet(l1, l2)

  }


  //
  //  override def tmapIxHomValues[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEngineLeet[N, AMap[K, V1]])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DelegateCheckEngineLeet[N, AMap[K, V2]] = {
  //    check(l.l1, l.l2)
  //
  //    val l1 = e1.tmapIxHomValues(l.l1)(f)
  //    val l2 = e2.tmapIxHomValues(l.l2)(f)
  //
  //    check(l1, l2)
  //    DelegateCheckEngineLeet(l1, l2)
  //  }


  override def relativeValues[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Iterator[((N, N), V)] = {
    check(l.l1, l.l2)

    val v1 = e1.relativeValues(l.l1).toMap
    val v2 = e2.relativeValues(l.l2).toMap

    (v1.keySet ++ v2.keySet).foreach(k => assert(v1(k) ~= v2(k)))
    e1.relativeValues(l.l1)
  }


  override def relativeValuesIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Iterator[((N, N), (K, V))] = {
    check(l.l1, l.l2)

    val v1 = e1.relativeValuesIx(l.l1).toSeq.groupBy(_._1).map { case (k, v) => k -> amap(v.map(_._2).toMap) }
    val v2 = e2.relativeValuesIx(l.l2).toSeq.groupBy(_._1).map { case (k, v) => k -> amap(v.map(_._2).toMap) }

    (v1.keySet ++ v2.keySet).foreach(k => assert(v1(k) ~= v2(k)))
    e1.relativeValuesIx(l.l1)
  }


  override def contract[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], mapping: Map[N, N]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val l1 = e1.contract(l.l1, mapping)
    val l2 = e2.contract(l.l2, mapping)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }

  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEngineLeet[N, V1], to: DelegateCheckEngineLeet[N, V2], mapping: Map[N, N]): DelegateCheckEngineLeet[N, V1] = {
    check(l.l1, l.l2)

    val l1 = e1.uncontract(l.l1, to.l1, mapping)
    val l2 = e2.uncontract(l.l2, to.l2, mapping)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }

  override def reduce[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V])(f: (V, V) => V): V = {
    check(l.l1, l.l2)

    val v1 = e1.reduce(l.l1)(f)
    val v2 = e2.reduce(l.l2)(f)

    assert(v1 ~= v2)
    v1
  }

  override def acDelta[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val l1 = e1.acDelta(l.l1)
    val l2 = e2.acDelta(l.l2)

    check(l1, l2)
    DelegateCheckEngineLeet(l1, l2)
  }

  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): DelegateCheckEnginePairLeet[N, K, V] = {
    check(l.l1, l.l2)

    val l1 = e1.acDeltaIx(l.l1)
    val l2 = e2.acDeltaIx(l.l2)

    check(l1, l2)
    DelegateCheckEnginePairLeet(l1, l2)
  }

  override def edges[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Set[(N, N)] = {
    check(l.l1, l.l2)

    val l1 = e1.edges(l.l1)
    val l2 = e2.edges(l.l2)

    assert(l1 == l2)
    l1
  }


  override def edgesIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Set[(N, N)] = {
    check(l.l1, l.l2)

    val l1 = e1.edgesIx(l.l1)
    val l2 = e2.edgesIx(l.l2)

    assert(l1 == l2)
    l1
  }


  override def zeroEdges[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Set[(N, N)] = {
    check(l.l1, l.l2)

    val l1 = e1.zeroEdges(l.l1)
    val l2 = e2.zeroEdges(l.l2)

    val symdiff = l1.diff(l2).union(l2.diff(l1))
    if (symdiff.nonEmpty) {
      val lv1 = e1.relativeValues(l.l1).toMap
      val lv2 = e2.relativeValues(l.l2).toMap
      symdiff.foreach(n => assert(lv1(n) ~= lv2(n)))
    }

    l1
  }

  override def zeroEdgesIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Set[(N, N)] = {

    check(l.l1, l.l2)

    val l1 = e1.zeroEdgesIx(l.l1)
    val l2 = e2.zeroEdgesIx(l.l2)

    val symdiff = l1.diff(l2).union(l2.diff(l1))
    if (symdiff.nonEmpty) {
      val lv1 = e1.relativeValuesIx(l.l1).toSeq.groupBy(_._1).map { case (k, v) => k -> amap(v.map(_._2).toMap) }
      val lv2 = e2.relativeValuesIx(l.l2).toSeq.groupBy(_._1).map { case (k, v) => k -> amap(v.map(_._2).toMap) }
      symdiff.foreach(n => assert(lv1(n) ~= lv2(n)))
    }

    l1
  }


  override def nodes[N: CT, T <: AType : CT](l: DelegateCheckEngineLeet[N, T]): Set[N] = {
    check(l.l1, l.l2)

    val l1 = e1.nodes(l.l1)
    val l2 = e2.nodes(l.l2)

    assert(l1 == l2)
    l1
  }

  override def nodesIx[N: CT, K: CT, T <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, T]): Set[N] = {
    check(l.l1, l.l2)

    val l1 = e1.nodesIx(l.l1)
    val l2 = e2.nodesIx(l.l2)

    assert(l1 == l2)
    l1
  }


  override def abelian[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Group[V] = {
    // TODO: Can this be checked?
    e1.abelian(l.l1)
  }


  override def abelianIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Group[AMap[K, V]] = {
    e1.abelianIx(l.l1)
  }

  //  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V1])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): DelegateCheckEngineLeet[N, V2] = {
  //    check(l.l1, l.l2)
  //
  //    val l1 = e1.tmapIx(l.l1)(f)
  //    val l2 = e2.tmapIx(l.l2)(f)
  //
  //    check(l1, l2)
  //    DelegateCheckEngineLeet(l1, l2)
  //  }

  override def subgraph[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val l1 = e1.subgraph(l.l1, edges, nodes)
    val l2 = e2.subgraph(l.l2, edges, nodes)

    check(l1, l2)

    // TODO: Extract constraints on parameters?
    assert(e1.nodes(l1) == nodes)
    assert(e2.nodes(l2) == nodes)

    DelegateCheckEngineLeet(l1, l2)
  }

  override def append[N: CT, V <: AType : CT](l1: DelegateCheckEngineLeet[N, V], l2: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l1.l1, l1.l2)
    check(l2.l1, l2.l2)

    val ll1 = e1.append(l1.l1, l2.l1)
    val ll2 = e2.append(l1.l2, l2.l2)

    check(ll1, ll2)
    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def values[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] = {
    check(l.l1, l.l2)

    val v1 = e1.values(l.l1, on).toMap
    val v2 = e2.values(l.l2, on).toMap

    (v1.keySet ++ v2.keySet).foreach(k => assert(v1(k) ~= v2(k)))
    e1.values(l.l1, on)
  }

  override def reverse[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.reverse(l.l1)
    val ll2 = e2.reverse(l.l2)

    check(ll1, ll2)
    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def force[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.force(l.l1)
    val ll2 = e2.force(l.l2)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def forceIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): DelegateCheckEnginePairLeet[N, K, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.forceIx(l.l1)
    val ll2 = e2.forceIx(l.l2)

    check(ll1, ll2)

    DelegateCheckEnginePairLeet(ll1, ll2)
  }


  //  override def delta[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
  //    check(l.l1, l.l2)
  //
  //    val ll1 = e1.delta(l.l1)
  //    val ll2 = e2.delta(l.l2)
  //
  //    check(ll1, ll2)
  //
  //    DelegateCheckEngineLeet(ll1, ll2)
  //  }

  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N1, V])(f: N1 => N2): DelegateCheckEngineLeet[N2, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.nmap(l.l1)(f)
    val ll2 = e2.nmap(l.l2)(f)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def authorship[N: CT](l: DelegateCheckEngineLeet[N, ADouble]): DelegateCheckEngineLeet[N, AMap[N, ADouble]] = {
    check(l.l1, l.l2)

    val ll1 = e1.authorship(l.l1)
    val ll2 = e2.authorship(l.l2)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def authorshipIx[N: CT, K: CT](l: DelegateCheckEnginePairLeet[N, K, ADouble]): DelegateCheckEnginePairLeet[N, (N, K), ADouble] = {
    check(l.l1, l.l2)

    val ll1 = e1.authorshipIx(l.l1)
    val ll2 = e2.authorshipIx(l.l2)

    check(ll1, ll2)

    DelegateCheckEnginePairLeet(ll1, ll2)
  }

  override def subgraph[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], nodes: Set[N]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.subgraph(l.l1, nodes)
    val ll2 = e2.subgraph(l.l2, nodes)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def values[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Iterator[(N, V)] = {
    check(l.l1, l.l2)

    val ll1 = e1.values(l.l1).toMap
    val ll2 = e2.values(l.l2).toMap

    assert(ll1.keySet == ll2.keySet)
    assert(ll1.keySet.forall(k => ll1(k) ~= ll2(k)))

    e1.values(l.l1)
  }

  override def size[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Int = {
    check(l.l1, l.l2)

    val ll1 = e1.size(l.l1)
    val ll2 = e2.size(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override def sizeIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Int = {
    check(l.l1, l.l2)

    val ll1 = e1.sizeIx(l.l1)
    val ll2 = e2.sizeIx(l.l2)

    assert(ll1 == ll2)

    ll1
  }


  override def branches[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], line: Seq[N]): DelegateCheckEngineLeet[N, ABag[N]] = {
    check(l.l1, l.l2)

    val ll1 = e1.branches(l.l1, line)
    val ll2 = e2.branches(l.l2, line)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  //
  //  override def collectLinearize[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], line: Seq[N]): DelegateCheckEngineLeet[N, ABag[V]] = {
  //    check(l.l1, l.l2)
  //
  //    val ll1 = e1.collectLinearize(l.l1, line)
  //    val ll2 = e2.collectLinearize(l.l2, line)
  //
  //    check(ll1, ll2)
  //
  //    DelegateCheckEngineLeet(ll1, ll2)
  //  }

  override def acLinearize[N1: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N1, V], line: Seq[N1]): DelegateCheckEngineLeet[N1, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.acLinearize(l.l1, line)
    val ll2 = e2.acLinearize(l.l2, line)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def acLinearizeIx[N1: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N1, K, V], seq: Seq[N1]): DelegateCheckEnginePairLeet[N1, K, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.acLinearizeIx(l.l1, seq)
    val ll2 = e2.acLinearizeIx(l.l2, seq)

    check(ll1, ll2)

    DelegateCheckEnginePairLeet(ll1, ll2)
  }

  override def collectDeltas[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], merges: Boolean = true): DelegateCheckEnginePairLeet[N, N, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.collectDeltas(l.l1, merges)
    val ll2 = e2.collectDeltas(l.l2, merges)

    check(ll1, ll2)

    DelegateCheckEnginePairLeet(ll1, ll2)
  }


  override def collectDeltasIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V], merges: Boolean = true): DelegateCheckEnginePairLeet[N, (N, K), V] = {
    check(l.l1, l.l2)

    val ll1 = e1.collectDeltasIx(l.l1, merges)
    val ll2 = e2.collectDeltasIx(l.l2, merges)

    check(ll1, ll2)

    DelegateCheckEnginePairLeet(ll1, ll2)
  }


  override def incoming[N: CT, T <: AType : CT](l: DelegateCheckEngineLeet[N, T]): Map[N, Set[N]] = {
    check(l.l1, l.l2)

    val ll1 = e1.incoming(l.l1)
    val ll2 = e2.incoming(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override def incomingIx[N: CT, K: CT, T <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, T]): Map[N, Set[N]] = {
    check(l.l1, l.l2)

    val ll1 = e1.incomingIx(l.l1)
    val ll2 = e2.incomingIx(l.l2)

    assert(ll1 == ll2)

    ll1
  }


  override def outgoing[N: CT, T <: AType : CT](l: DelegateCheckEngineLeet[N, T]): Map[N, Set[N]] = {
    check(l.l1, l.l2)

    val ll1 = e1.outgoing(l.l1)
    val ll2 = e2.outgoing(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override def outgoingIx[N: CT, K: CT, T <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, T]): Map[N, Set[N]] = {
    check(l.l1, l.l2)

    val ll1 = e1.outgoingIx(l.l1)
    val ll2 = e2.outgoingIx(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override def roots[N: CT, T <: AType : CT](l: DelegateCheckEngineLeet[N, T]): Set[N] = {
    check(l.l1, l.l2)

    val ll1 = e1.roots(l.l1)
    val ll2 = e2.roots(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override def rootsIx[N: CT, K: CT, T <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, T]): Set[N] = {
    check(l.l1, l.l2)

    val ll1 = e1.rootsIx(l.l1)
    val ll2 = e2.rootsIx(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override def leafs[N: CT, T <: AType : CT](l: DelegateCheckEngineLeet[N, T]): Set[N] = {
    check(l.l1, l.l2)

    val ll1 = e1.leafs(l.l1)
    val ll2 = e2.leafs(l.l2)

    assert(ll1 == ll2)

    ll1
  }


  override def leafsIx[N: CT, K: CT, T <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, T]): Set[N] = {
    check(l.l1, l.l2)

    val ll1 = e1.leafsIx(l.l1)
    val ll2 = e2.leafsIx(l.l2)

    assert(ll1 == ll2)

    ll1
  }


  override def ts[N: CT, T <: AType : CT](l: DelegateCheckEngineLeet[N, T]): Iterator[N] = {
    check(l.l1, l.l2)

    val ll1 = e1.ts(l.l1)
    val ll2 = e2.ts(l.l2)

    assert(ll1.toSeq == ll2.toSeq)

    ll1
  }


  override def tsIx[N: CT, K: CT, T <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, T]): Iterator[N] = {
    check(l.l1, l.l2)

    val ll1 = e1.tsIx(l.l1)
    val ll2 = e2.tsIx(l.l2)

    assert(ll1.toSeq == ll2.toSeq)

    ll1
  }


  override def maskBypassEdges[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): DelegateCheckEngineLeet[N, V] = {
    check(l.l1, l.l2)

    val ll1 = e1.maskBypassEdges(l.l1)
    val ll2 = e2.maskBypassEdges(l.l2)

    check(ll1, ll2)

    DelegateCheckEngineLeet(ll1, ll2)
  }

  override def bypassEdges[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): Iterator[(N, N)] = {
    check(l.l1, l.l2)

    val ll1 = e1.bypassEdges(l.l1)
    val ll2 = e2.bypassEdges(l.l2)

    assert(ll1.toSeq == ll2.toSeq)

    ll1
  }

  override def contractEdges[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V], target: Set[(N, N)]): (DelegateCheckEngineLeet[N, V], Map[N, N]) = {
    check(l.l1, l.l2)

    val (ll1, m1) = e1.contractEdges(l.l1, target)
    val (ll2, m2) = e2.contractEdges(l.l2, target)

    check(ll1, ll2)
    assert(m1 == m2)

    (DelegateCheckEngineLeet(ll1, ll2), m1)
  }

  override def contractZero[N: CT, V <: AType : CT](l: DelegateCheckEngineLeet[N, V]): (DelegateCheckEngineLeet[N, V], Map[N, N]) = {
    check(l.l1, l.l2)

    val (ll1, m1) = e1.contractZero(l.l1)
    val (ll2, m2) = e2.contractZero(l.l2)

    check(ll1, ll2)
    assert(m1 == m2)

    (DelegateCheckEngineLeet(ll1, ll2), m1)
  }

  override def keys[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Set[K] = {
    check(l.l1, l.l2)

    val ll1 = e1.keys(l.l1)
    val ll2 = e2.keys(l.l2)

    assert(ll1 == ll2)

    ll1
  }

  override implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: DelegateCheckEnginePairLeet[N, K, V]): DelegateCheckEngineLeet[N, AMap[K, V]] =
    DelegateCheckEngineLeet(e1.pairLeet2Leet(pairLeet.l1), e2.pairLeet2Leet(pairLeet.l2))

  override implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: DelegateCheckEngineLeet[N, AMap[K, V]]): DelegateCheckEnginePairLeet[N, K, V] =
    DelegateCheckEnginePairLeet(e1.leet2PairLeet(leet.l1), e2.leet2PairLeet(leet.l2))

  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V], on: Set[N]): Iterator[(N, K, V)] = {
    check(l.l1, l.l2)

    val v1 = e1.valuesIx(l.l1, on).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (k, v1, v2) => (v1, v2) }.toMap)) }
    val v2 = e2.valuesIx(l.l2, on).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (k, v1, v2) => (v1, v2) }.toMap)) }

    (v1.keySet ++ v2.keySet).foreach(k => assert(v1(k) ~= v2(k)))
    e1.valuesIx(l.l1, on)
  }

  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: DelegateCheckEnginePairLeet[N, K, V]): Iterator[(N, K, V)] = {
    check(l.l1, l.l2)

    val v1 = e1.valuesIx(l.l1).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (k, v1, v2) => (v1, v2) }.toMap)) }
    val v2 = e2.valuesIx(l.l2).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (k, v1, v2) => (v1, v2) }.toMap)) }

    (v1.keySet ++ v2.keySet).foreach(k => assert(v1(k) ~= v2(k)))
    e1.valuesIx(l.l1)
  }

}
