package org.unknown1337.topleet.evaluation

import java.io.{File, FileReader}

import com.google.common.base.Charsets
import org.apache.commons.csv.CSVFormat
import org.apache.commons.lang.exception.ExceptionUtils
import org.unknown1337.topleet.SparkUtils2
import org.unknown1337.topleet.atypes.AInteger
import org.unknown1337.topleet.atypes.AMap._
import org.unknown1337.topleet.engines.{Engine, IncEngine, IncixRDDEngine}
import org.unknown1337.topleet.evaluation.lisaparser.AntlrJavaParser
import org.unknown1337.topleet.libs.{GitViewers, Gits, SHA, Wrangling}
import org.unknown1337.topleet.ura.Gitobject
import org.unknown1337.topleet.utils.{Isolator, JSONLDPrinter}

import collection.JavaConverters._

object TopleetSolution {

  def main(args: Array[String]): Unit = {

    val repositories = CSVFormat.DEFAULT.withFirstRecordAsHeader()
      .parse(new FileReader("data/topleet/topleets_modernes_leben.csv"))
      .asScala
      .map(_.toMap.asScala)
      .filter(x => x("address") != "Bukkit/CraftBukkit")


    for ((repository, index) <- repositories.zipWithIndex) {
      val append = index != 0
      val address = repository("address")
      println("----------- " + address + " -----------")

      val timeout = 60 * 60 * 12 * 9
      val ncommits = Gitobject(address).commits().size
      val out = try {

        println(Gitobject(address).commits().take(10).toArray.toSeq)

        val partitions = Math.max(32, ncommits / 100)
        val half = Math.ceil(Math.sqrt(partitions)).toInt
        println("Commits: " + ncommits)
        println("Partitions " + partitions)
        println("Half " + half)

        val (time, memory) = Isolator.tmprof({ () => TopleetSolution(new IncixRDDEngine(SparkUtils2.spark(), width = half, height = half, coalesce = half), address, append).run() }, timeout = timeout)

        Map("time[ns]" -> time.toString, "memory" -> memory.toString)
      }
      catch {
        case x: Throwable => {
          x.printStackTrace()
          Map("exception" -> ExceptionUtils.getStackTrace(x))
        }
      }

      val printer = JSONLDPrinter.create(new File("data/topleet/topleet_solution.json"), Charsets.UTF_8, append)
      printer.printRecord(out ++ repository ++ Map("n2commits" -> ncommits.toString))
      printer.close()
    }
  }
}

case class TopleetSolution(engine: IncixRDDEngine, address: String, append: Boolean) extends Gits with GitViewers with Wrangling {

  import engine._

  def run(): Unit = {

    val changes = git(address)
      .resources()
      .filter { case (path, _) => path.endsWith(".java") }
      // Config: Use map for no memorization.
      .dmap { case (path, resource) => amap(path, AInteger(AntlrJavaParser.computeMCC(resource.inputStream()))) }
      .flatten
      .delta()

    // For index based mapping use:
    // .tmapIx{case ((path,resource),AInteger(c)) => amap(path,AInteger(c * AntlrJavaParser.computeMCC(resource.inputStream())))}
    // ... without flatten.

    changes.dumpJsonLD(new File("data/topleet/topleet_solution_output.json"), append = append) { case ((parent, path), AInteger(delta)) => Map("parent" -> parent.toString, "path" -> path, "delta" -> delta.toString) }

  }
}