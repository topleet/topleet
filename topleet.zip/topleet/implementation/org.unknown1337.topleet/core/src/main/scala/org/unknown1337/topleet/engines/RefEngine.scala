package org.unknown1337.topleet.engines

import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes.{ADouble, AMap, ATuple, AType}

import scala.collection.mutable
import scala.reflect.{ClassTag => CT, _}

case class RefEngine() extends BaseEngine {

  case class RefEngineLeet[N, V <: AType](edges: Set[(N, N)], nodes: Map[N, V], abelian: Group[V])

  override type Leet[N, V <: AType] = RefEngineLeet[N, V]

  override type PairLeet[N, K, V <: AType] = RefEngineLeet[N, AMap[K, V]]

  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): RefEngineLeet[N, V] =
    RefEngineLeet(edges, nodes, vAbelian)

  override def merge[N: CT, V <: AType : CT](l1: RefEngineLeet[N, V], l2: RefEngineLeet[N, V]): RefEngineLeet[N, V] = {
    val newValues = (l1.nodes.keySet ++ l2.nodes.keySet).map(k => (k, l1.abelian.merge(l1.nodes(k), l2.nodes(k)))).toMap
    RefEngineLeet(l1.edges, newValues, l1.abelian)
  }

  override def zero[N: CT, V <: AType : CT](l: RefEngineLeet[N, V]): RefEngineLeet[N, V] = {
    val newValues = l.nodes.map { case (k, v) => (k, l.abelian.inverse(v)) }
    RefEngineLeet(l.edges, newValues, l.abelian)
  }

  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: RefEngineLeet[N, V1], l2: RefEngineLeet[N, V2]): RefEngineLeet[N, ATuple[V1, V2]] = {
    val newValues = (l1.nodes.keySet ++ l2.nodes.keySet).map(k => (k, ATuple(l1.nodes(k), l2.nodes(k)))).toMap
    RefEngineLeet(l1.edges, newValues, ATuple.aTupleGroup(l1.abelian, l2.abelian))
  }

  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: RefEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): RefEngineLeet[N, V2] = {
    val newValues = l.nodes.map { case (k, v) => (k, f(v)) }
    RefEngineLeet(l.edges, newValues, v2Abelian)
  }

  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: RefEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): RefEngineLeet[N, V2] =
    tmap(l)(f)

//  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: RefEngineLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): RefEngineLeet[N, V2] =
//    tmap(l)(x => x.value.map(f.tupled).fold(v2Abelian.zero)(v2Abelian.merge))

  override def edges[N: CT, V <: AType : CT](l: RefEngineLeet[N, V]): Set[(N, N)] = l.edges

  override def relativeValues[N: CT, V <: AType : CT](l: RefEngineLeet[N, V]): Iterator[((N, N), V)] =
    l.edges.toIterator.map { case (n1, n2) => ((n1, n2), l.abelian.diff(l.nodes(n1), l.nodes(n2))) }

  override def contract[N: CT, V <: AType : CT](l: RefEngineLeet[N, V], mapping: Map[N, N]): RefEngineLeet[N, V] = {
    val newNodes = l.nodes.keySet.intersect(mapping.values.toSet)
    val newEdges = l.edges.collect { case (n1, n2) if mapping(n1) != mapping(n2) => (mapping(n1), mapping(n2)) }
    val newValues = l.nodes.filterKeys(newNodes)
    RefEngineLeet(newEdges, newValues, l.abelian)
  }

  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: RefEngineLeet[N, V1], to: RefEngineLeet[N, V2], mapping: Map[N, N]): RefEngineLeet[N, V1] = {
    val newEdges = to.edges
    val newValues = to.nodes.keySet.map(n => (n, l.nodes(mapping(n)))).toMap
    RefEngineLeet(newEdges, newValues, l.abelian)
  }

  override def reduce[N: CT, V <: AType : CT](l: RefEngineLeet[N, V])(f: (V, V) => V): V =
    l.nodes.values.reduce(f)

  override def nodes[N: CT, T <: AType : CT](l: RefEngineLeet[N, T]): Set[N] =
    l.nodes.keySet

  override def abelian[N: CT, V <: AType : CT](l: RefEngineLeet[N, V]): Group[V] =
    l.abelian

  override def zeroEdges[N: CT, V <: AType : CT](l: RefEngineLeet[N, V]): Set[(N, N)] =
    l.edges.filter { case (n1, n2) => l.abelian.diff(l.nodes(n1), l.nodes(n2)) == l.abelian.zero }

  override def subgraph[N: CT, V <: AType : CT](l: RefEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): RefEngineLeet[N, V] = {
    val newValues = l.nodes.filterKeys(nodes)
    val newEdges = l.edges.intersect(edges)
    RefEngineLeet(newEdges, newValues, l.abelian)
  }

  override def append[N: CT, V <: AType : CT](l1: RefEngineLeet[N, V], l2: RefEngineLeet[N, V]): RefEngineLeet[N, V] = {
    assert((l1.nodes.keySet ++ l2.nodes.keySet).forall(n => !l1.nodes.isDefinedAt(n) || !l2.nodes.isDefinedAt(n) || l1.nodes.get(n) == l2.nodes.get(n)))
    val newValues = l1.nodes ++ l2.nodes
    val newEdges = l1.edges.union(l2.edges)
    RefEngineLeet(newEdges, newValues, l1.abelian)
  }

  override def reverse[N: CT, V <: AType : CT](l: RefEngineLeet[N, V]): RefEngineLeet[N, V] =
    RefEngineLeet(l.edges.map(_.swap), l.nodes, l.abelian)

  override def values[N: CT, V <: AType : CT](l: RefEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] =
    l.nodes.toIterator.filter { case (n, _) => on.isEmpty || on(n) }

  override def force[N: CT, T <: AType : CT](l: RefEngineLeet[N, T]): RefEngineLeet[N, T] =
    RefEngineLeet(l.edges, l.nodes.view.force, l.abelian)

  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: RefEngineLeet[N1, V])(f: N1 => N2): RefEngineLeet[N2, V] = {
    val newNodes = l.nodes.map { case (n, v) => (f(n), v) }
    val newEdges = l.edges.map { case (n1, n2) => (f(n1), f(n2)) }
    RefEngineLeet(newEdges, newNodes, l.abelian)
  }

  override def keys[N: CT, K: CT, V <: AType : CT](l: RefEngineLeet[N, AMap[K, V]]): Set[K] = l.nodes.values.flatMap(v => v.value.keySet).toSet

  override implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: RefEngineLeet[N, AMap[K, V]]): RefEngineLeet[N, AMap[K, V]] = pairLeet

  override implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: RefEngineLeet[N, AMap[K, V]]): RefEngineLeet[N, AMap[K, V]] = leet

}
