package org.unknown1337.topleet.engines

import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.apache.spark.{HashPartitioner, Partitioner, SparkContext}
import org.unknown1337.topleet.atypes.AMap._
import org.unknown1337.topleet.atypes.{AInteger, AMap, ATuple, AType, AbelianAMap}
import org.unknown1337.topleet.libs.{Gits,  Wrangling}
import org.unknown1337.topleet.utils.Utils
import org.unknown1337.topleet.{Group, SparkUtils2}

import scala.collection.mutable
import scala.reflect.{ClassTag => CT}

case class IncixRDDEnginePartitioner(width: Int, height: Int, nheight: Int) extends Partitioner {
  val dxheight: Int = Math.ceil(nheight.toDouble / height.toDouble).toInt

  def getHeight(key: Any): Int = key match {
    case (x: Long) => (x / dxheight).toInt
  }

  def getWidth(key: Any): Int = Math.abs(key.hashCode()) % width

  def getPartitionWidth(partition: Int): Int = partition % height

  def getPartitionHeight(partition: Int): Int = partition / width

  override def numPartitions: Int = width * height

  override def getPartition(key: Any): Int = key match {
    case ((_: Long, n2: Long), k: Any) => getHeight(n2) * width + getWidth(k)
    case (n2: Long, k: Any) => getHeight(n2) * width + getWidth(k)
  }
}

case class IncixRDDEngine(@transient spark: SparkContext, width: Int = 4, height: Int = 4, coalesce: Int = 16) extends BaseEngine {

  type Leet[N, V <: AType] = IncixRDDEngineLeet[N, V]

  type PairLeet[N, K, V <: AType] = IncixRDDEnginePairLeet[N, K, V]

  case class IncixRDDEngineLeet[N: CT, V <: AType : CT]()

  case class Metadata[N](ids: Map[Long, N], nodes: Set[Long], edges: Set[(Long, Long)], checkpoints: Set[Long])


  case class IncixRDDEnginePairLeet[N: CT, K: CT, V <: AType : CT](metadata: RDD[Metadata[N]],
                                                                   rawCheckpoints: RDD[((Long, K), V)],
                                                                   rawEdges: RDD[(((Long, Long), K), V)],
                                                                   abelian: Group[V],
                                                                   nodes: Set[N],
                                                                   edges: Set[(N, N)],
                                                                   partitioner: IncixRDDEnginePartitioner,
                                                                   partitioned: Boolean) {

    lazy val rddCheckpoints: RDD[((Long, K), V)] =
      if (partitioned) rawCheckpoints
      else rawCheckpoints
        .reduceByKey(partitioner, (x: V, y: V) => abelian.merge(x, y))
        .filter { case (_, v) => !v.isZero }

    lazy val rddEdges: RDD[(((Long, Long), K), V)] =
      if (partitioned) rawEdges
      else rawEdges
        .reduceByKey(partitioner, (x: V, y: V) => abelian.merge(x, y))
        .filter { case (_, v) => !v.isZero }
  }

  override def createIx[N: CT, K: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, AMap[K, V]])(implicit vAbelian: Group[V]): IncixRDDEnginePairLeet[N, K, V] = {
    val aheight = Math.min(height, nodes.size)
    val mapAbelian = AMap.aMapGroup[K, V](vAbelian)
    val partitioner = IncixRDDEnginePartitioner(width, aheight, nodes.size)

    val locations = Utils.tsCCSeq(edges, nodes.keySet).zipWithIndex.map { case (n, i) => (i.toLong, n) }.toMap
    val index = locations.map(_.swap)

    val lookup = locations.keySet
      .groupBy(partitioner.getHeight)
      .map { case (i, ns) =>
        // Remember that not every node in the mapping is maintained in the partition.
        val es = edges.map { case (n1, n2) => (index(n1), index(n2)) }.filter { case (n1, n2) => ns(n1) || ns(n2) }
        val ids = (ns ++ es.flatMap { case (n1, n2) => Seq(n1, n2) }).map(n => (n, locations(n))).toMap
        val checkpoints = Utils.ccs2(es.filter { case (n1, n2) => ns(n1) && ns(n2) }, ns).values.toSet

        i -> Metadata(ids, ns, es, checkpoints)
      }

    val newMetadata = spark.parallelize(Seq[Any](), width * aheight).mapPartitionsWithIndex { case (i, _) => Seq(lookup.getOrElse(partitioner.getPartitionHeight(i), Metadata(Map(), Set(), Set(), Set()))).toIterator }

    val newEdges = spark.parallelize(edges.toSeq.flatMap { case (n1, n2) => mapAbelian.diff(nodes(n1), nodes(n2)).value.map { case (k, v) => (((index(n1), index(n2)), k), v) } }, width * aheight)

    val newCheckpoints = spark.parallelize(lookup.toSeq.flatMap(x => x._2.checkpoints).flatMap { id => nodes(locations(id)).value.map { case (k, v) => ((id, k), v) } }, width * aheight)

    IncixRDDEnginePairLeet(newMetadata.localCheckpoint(), newCheckpoints.localCheckpoint(), newEdges.localCheckpoint(), vAbelian, nodes.keySet, edges, partitioner, partitioned = false)
  }

  override def tmapHomIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncixRDDEnginePairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): IncixRDDEnginePairLeet[N, K2, V2] = {
    val newCheckpoints = l.rddCheckpoints
      .flatMap { case ((n, k), v) => f(k, v).value.map { case (k2, v2) => ((n, k2), v2) } }
      .reduceByKey(l.partitioner, (x: V2, y: V2) => v2Abelian.merge(x, y))
      .filter { case (_, v) => !v.isZero }

    val newEdges = l.rddEdges
      .flatMap { case ((n, k), v) => f(k, v).value.map { case (k2, v2) => ((n, k2), v2) } }
      .reduceByKey(l.partitioner, (x: V2, y: V2) => v2Abelian.merge(x, y))
      .filter { case (_, v) => !v.isZero }

    IncixRDDEnginePairLeet(l.metadata, newCheckpoints, newEdges, v2Abelian, l.nodes, l.edges, l.partitioner, partitioned = true)
  }

  override def tmapDynamic[N: CT, K1: CT, K2: CT, V1 <: AType : CT](l: IncixRDDEnginePairLeet[N, K1, V1])(f: K1 => K2): IncixRDDEnginePairLeet[N, K2, V1] = {
    val checkpointsByKey = l.rddCheckpoints.map { case ((n, k), v1) => (k, (n, v1)) }
    val edgesByKey = l.rddEdges.map { case ((n, k), v1) => (k, (n, v1)) }

    val mapped = checkpointsByKey.cogroup(edgesByKey, new HashPartitioner(width * height)).map {
      case (k1, (l, r)) => (f(k1), (l, r))
    }

    val newCheckpoints = mapped.flatMap {
      case (k2, (iterator, _)) => iterator.map { case (l, v1) => ((l, k2), v1) }
    }.partitionBy(l.partitioner)

    val newEdges = mapped.flatMap {
      case (k2, (_, iterator)) => iterator.map { case (l, v1) => ((l, k2), v1) }
    }.partitionBy(l.partitioner)

    IncixRDDEnginePairLeet(l.metadata, newCheckpoints, newEdges, l.abelian, l.nodes, l.edges, l.partitioner, partitioned = false)
  }

  override def tmapHomLinIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncixRDDEnginePairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): IncixRDDEnginePairLeet[N, K2, V2] = {
    val newCheckpoints = l.rawCheckpoints
      .flatMap { case ((n, k), v) => f(k, v).value.map { case (k2, v2) => ((n, k2), v2) } }

    val newEdges = l.rawEdges
      .flatMap { case ((n, k), v) => f(k, v).value.map { case (k2, v2) => ((n, k2), v2) } }

    IncixRDDEnginePairLeet(l.metadata, newCheckpoints, newEdges, v2Abelian, l.nodes, l.edges, l.partitioner, partitioned = false)
  }


  override def mergeIx[N: CT, K: CT, V <: AType : CT](l1: IncixRDDEnginePairLeet[N, K, V], l2: IncixRDDEnginePairLeet[N, K, V]): IncixRDDEnginePairLeet[N, K, V] = {
    val abl = l1.abelian

    val newCheckpoints = l1.rawCheckpoints.union(l2.rawCheckpoints)

    val newEdges = l1.rawEdges.union(l2.rawEdges)

    IncixRDDEnginePairLeet(l1.metadata, newCheckpoints, newEdges, abl, l1.nodes, l1.edges, l1.partitioner, partitioned = false)
  }

  override def tmapIx[N: CT, K: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V1])(f: (K, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): IncixRDDEnginePairLeet[N, K2, V2] = {
    implicit val av: Group[V1] = l.abelian
    implicit val v1MapAbelian: Group[AMap[K, V1]] = AMap.aMapGroup[K, V1](av)
    implicit val v2MapAbelian: Group[AMap[K2, V2]] = AMap.aMapGroup[K2, V2](v2Abelian)

    val newDeltas = l.rddEdges.zipPartitions(l.metadata, l.rddCheckpoints) { case (iteratorDeltas, metadatas, iteratorCheckpoints) =>
      val metadata = metadatas.next()
      val nodes = metadata.ids.keySet
      val edges = metadata.edges
      val ins = Utils.incoming(edges, nodes)
      val outs = Utils.outgoing(edges, nodes)

      val checkpoints = iteratorCheckpoints.toMap

      val deltas = Utils.groupByKey(iteratorDeltas.collect { case (((n1, n2), k), v) => ((n1, n2), (k, v)) }.toSeq).map { case (k, v) => (k, AMap(v.toMap)) }
        .withDefaultValue(v1MapAbelian.zero)


      distance(edges.map(ns => (ns, deltas(ns))).toMap, nodes, metadata.checkpoints, nodes)
        .flatMap { case ((ncheckpoint, to), offset) =>
          val keys = Utils.groupByKey(
            ins(to).toSeq.flatMap(x => deltas(x, to).keys().toSeq.map { k => k -> (x, to) }) ++
              outs(to).toSeq.flatMap(x => deltas(to, x).keys().toSeq.map { k => k -> (to, x) })
          ).toSeq

          keys.flatMap { case (k, es) =>
            val checkpoint = checkpoints.getOrElse((ncheckpoint, k), av.zero)
            val value = av.merge(checkpoint, offset.getOrElse(k, av.zero))
            val AMap(result) = f(k, value)
            for ((n1, n2) <- es; (k2, v2) <- result.toSeq) yield {
              if (n1 == to)
                (((n1, n2), k2), v2Abelian.inverse(v2))
              else
                (((n1, n2), k2), v2)
            }
          }
        }
    }
      .reduceByKey(l.partitioner, (x: V2, y: V2) => v2Abelian.merge(x, y))
      .filter { case (_, v) => !v.isZero }

    val newCheckpoints = l.rddCheckpoints
      .flatMap { case ((n, k), v) => f(k, v).value.map { case (k2, v2) => ((n, k2), v2) } }
      .reduceByKey(l.partitioner, (x: V2, y: V2) => v2Abelian.merge(x, y))
      .filter { case (_, v) => !v.isZero }

    IncixRDDEnginePairLeet(l.metadata, newCheckpoints, newDeltas, v2Abelian, l.nodes, l.edges, l.partitioner, partitioned = true)
  }

  override def keys[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V]): Set[K] =
    (l.rddEdges.map { case (((_, k)), v) => k } ++ l.rddCheckpoints.map { case (((_, k)), v) => k }).distinct().collect().toSet

  //l..values.collect { case (_, Some(v)) => v.keys() }.reduce(_ ++ _) ++ l.rddEdges.map(_._2.keys()).reduce(_ ++ _)

  override def abelianIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V]): Group[AMap[K, V]] = AbelianAMap[K, V](l.abelian)

  override def collectDeltasIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V], merges: Boolean = true): IncixRDDEnginePairLeet[N, (N, K), V] = {
    val abl = l.abelian

    val delta = l.rddEdges.zipPartitions(l.metadata) { case (deltaIterator, metadataIterator) =>
      val metadata = metadataIterator.next()
      val in = Utils.incoming(metadata.edges, metadata.ids.keySet)
      deltaIterator
        .filter { case (((n1, n2), k), v) => in(n2).size == 1 || merges }
        .map { case (((n1, n2), k), v) => ((n2, (metadata.ids(n1), k)), v) }
    }.reduceByKey(l.partitioner, (x, y) => abl.merge(x, y))

    val newDeltas = delta.zipPartitions(l.metadata) { case (deltaIterator, metadataIterator) =>
      val metadata = metadataIterator.next()
      val in = Utils.incoming(metadata.edges, metadata.ids.keySet)
      val out = Utils.outgoing(metadata.edges, metadata.ids.keySet)

      deltaIterator.flatMap { case ((n2, (n, k)), v) =>
        in(n2).toSeq.map { n1 => (((n1, n2), (n, k)), v) } ++ out(n2).toSeq.map { n3 => (((n2, n3), (n, k)), abl.inverse(v)) }
      }
    }
      .reduceByKey(l.partitioner, (x, y) => abl.merge(x, y))
      .filter { case (_, v) => !v.isZero }

    val newCheckpoints = delta.zipPartitions(l.metadata) { case (deltaIterator, metadataIterator) =>
      val metadata = metadataIterator.next()
      deltaIterator.filter { case ((n, _), _) => metadata.checkpoints(n) }
    }

    IncixRDDEnginePairLeet(l.metadata, newCheckpoints, newDeltas, l.abelian, l.nodes, l.edges, l.partitioner, partitioned = true)
  }

  override def forceIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V]): IncixRDDEnginePairLeet[N, K, V] =
    IncixRDDEnginePairLeet(l.metadata, l.rawCheckpoints.persist(StorageLevel.MEMORY_AND_DISK), l.rawEdges.persist(StorageLevel.MEMORY_AND_DISK), l.abelian, l.nodes, l.edges, l.partitioner, partitioned = l.partitioned)

  override def productIx[N: CT, K1: CT, V1 <: AType : CT, K2: CT, V2 <: AType : CT](l1: IncixRDDEnginePairLeet[N, K1, V1], l2: IncixRDDEnginePairLeet[N, K2, V2]): IncixRDDEnginePairLeet[N, (K1, K2), ATuple[V1, V2]] = {
    implicit val abl1: Group[V1] = l1.abelian
    implicit val abl2: Group[V2] = l2.abelian

    val keys1 = l1.keys()
    val keys2 = l2.keys()

    //    val pair1 = l1.rddEdges.flatMap{ case (((n1,n2),k1),v1) => keys2.map(k2 => (((n1,n2),(k1,k2)),ATuple(v1,abl2.zero)))}
    //    val pair2 = l2.rddEdges.flatMap{ case (((n1,n2),k2),v2) => keys1.map(k1 => (((n1,n2),(k1,k2)),ATuple(abl1.zero,v2)))}

    val pairs1 = tmapHomIx(l1) { case (k1, v1) => amap(keys2.map(k2 => (k1, k2) -> ATuple(v1, abl2.zero)).toMap) }
    val pairs2 = tmapHomIx(l2) { case (k2, v2) => amap(keys1.map(k1 => (k1, k2) -> ATuple(abl1.zero, v2)).toMap) }

    mergeIx(pairs1, pairs2).tmapIx { case ((k1, k2), ATuple(v1, v2)) => if (v1.isZero || v2.isZero) AMap.zero() else amap((k1, k2), ATuple(v1, v2)) }
  }

  override def relativeValuesIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V]): Iterator[((N, N), (K, V))] = {
    l.rddEdges.zipPartitions(l.metadata) { case (relative, metadatas) =>
      val metadata = metadatas.next()
      relative.map { case (((n1, n2), k), v) => ((metadata.ids(n1), metadata.ids(n2)), (k, v)) }
    }.coalesce(coalesce).toLocalIterator
  }

  // TODO: Make on an option to select.
  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V], on: Set[N]): Iterator[(N, K, V)] = {
    // TODO: Check if this can be implemented in terms of indexing.
    //    implicit val abl: Group[V] = l.abelian
    //
    //    val intermediate = tmapHomIx(l) { case (k, v) => amap((k, 0), v) }
    //    val out = tmapIx(intermediate){case ((k,i),v) => amap((k,i+1),v)}

    // Make a local index
    //val out = tmapIx(l){case (k,v) => amap((k,v), AInteger(1))}


    implicit val mapAbelian: Group[AMap[K, V]] = abelianIx(l)

    val notOns = l.nodes.diff(on)

    l.rddEdges.zipPartitions(l.metadata, l.rddCheckpoints) { case (iteratorDeltas, metadatas, iteratorCheckpoints) =>
      val metadata = metadatas.next()
      val nodes = metadata.nodes
      val edges = metadata.edges.filter { case (n1, n2) => nodes(n1) && nodes(n2) }
      val checkpoints = Utils.groupByKey(iteratorCheckpoints.map { case ((id, k), v) => (id, (k, v)) }.toSeq).map { case (k, v) => (k, AMap(v.toMap)) }
      // Just use delta fully in this partition.
      val index = metadata.ids.map(_.swap)

      val deltas = Utils.groupByKey(iteratorDeltas.collect { case (((n1, n2), k), v) if metadata.nodes(n1) => ((n1, n2), (k, v)) }.toSeq).map { case (k, v) => (k, AMap(v.toMap)) }

      distance(edges.map(e => (e, deltas.getOrElse(e, mapAbelian.zero))).toMap, nodes.diff(notOns.map(x => index(x))), metadata.checkpoints, nodes).flatMap { case ((from, to), map) =>
        mapAbelian.merge(checkpoints.getOrElse(from, mapAbelian.zero), map).value.map { case (k, v) => (metadata.ids(to), k, v) }
      }
    }.coalesce(coalesce).toLocalIterator
  }


  /**
    * Computes the distance between from and to. For each to nodes a distance is contained but not necessary all from
    * nodes are used. Returns ((from,to),diff).
    */
  def distance[V <: AType : CT](delta: Map[(Long, Long), V], nodes: Set[Long], froms: Set[Long], tos: Set[Long])(implicit abl: Group[V]): Iterator[((Long, Long), V)] = {
    // Temp graph data.
    val in = Utils.incoming(delta.keySet, nodes)
    val out = Utils.outgoing(delta.keySet, nodes)
    // In out with empty nodes.
    val inOut = Utils.groupByKey(
      in.toSeq.flatMap { case (n, ns) => ns.map(x => (n, (true, x))) } ++
        out.toSeq.flatMap { case (n, ns) => ns.map(x => (n, (false, x))) }) ++
      nodes.collect { case n if in(n).isEmpty && out(n).isEmpty => (n, Seq[(Boolean, Long)]()) }.toMap

    // Compute the Dijkstra.
    val hops = Utils.dijkstra(inOut.map { case (k, v) => (k, v.map(_._2).toSet) }, froms)

    // Cache for already computed to nodes.
    // TODO: Indeed an easy way is to used the distance computed by dijkstra!
    val cache = mutable.Map[Long, (Long, V)]()

    // Recursive computation of the distance along the hops.
    def compute(x: Long): (Long, V) = x match {
      case to if froms.contains(to) => (to, abl.zero)
      // Check if already computed or computes the distance.
      case to => cache.getOrElseUpdate(to, {

        // Find neighbour with lowest hop count.
        val neighbours = inOut(to)
        val (isIncoming, neighbour) = neighbours.minBy { case (_, n) => hops(n) }

        //  Recursively compute the neighbour's distance.
        val (from, dist) = compute(neighbour)

        // Apply the delta to this node.
        val result =
          if (isIncoming) abl.merge(dist, delta(neighbour, to))
          else abl.merge(dist, abl.inverse(delta(to, neighbour)))

        (from, result)
      })
    }

    // Steam based mapping to distances between froms.
    tos.map(n => (n, hops(n))).toSeq.sortBy(_._2).toIterator.map { case (to, hop) =>
      val (f, d) = compute(to)
      val del = cache.keys.filter(n => hops(n) < hop - 1)
      del.foreach(cache.remove)
      ((f, to), d)
    }
  }

  override def nodesIx[N: CT, K: CT, T <: AType : CT](l: IncixRDDEnginePairLeet[N, K, T]): Set[N] = l.nodes

  override def edgesIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V]): Set[(N, N)] = l.edges

  // ----------------------- TODO: Currently to complicated, uses regular delta without merges -------------------------------------------------------.
  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: IncixRDDEnginePairLeet[N, K, V]): IncixRDDEnginePairLeet[N, K, V] = ???

  // ----------------------- Old non-pair methods -------------------------------------------------------.
  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): IncixRDDEngineLeet[N, V] = ???

  override def subgraph[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): IncixRDDEngineLeet[N, V] = ???

  override def nodes[N: CT, T <: AType : CT](l: IncixRDDEngineLeet[N, T]): Set[N] = ???

  override implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: IncixRDDEnginePairLeet[N, K, V]): IncixRDDEngineLeet[N, AMap[K, V]] = ???

  override implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: IncixRDDEngineLeet[N, AMap[K, V]]): IncixRDDEnginePairLeet[N, K, V] = ???

  override def reverse[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): IncixRDDEngineLeet[N, V] = ???

  override def append[N: CT, V <: AType : CT](l1: IncixRDDEngineLeet[N, V], l2: IncixRDDEngineLeet[N, V]): IncixRDDEngineLeet[N, V] = ???

  override def merge[N: CT, V <: AType : CT](l1: IncixRDDEngineLeet[N, V], l2: IncixRDDEngineLeet[N, V]): IncixRDDEngineLeet[N, V] = ???

  override def zero[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): IncixRDDEngineLeet[N, V] = ???

  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: IncixRDDEngineLeet[N, V1], l2: IncixRDDEngineLeet[N, V2]): IncixRDDEngineLeet[N, ATuple[V1, V2]] = ???

  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncixRDDEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncixRDDEngineLeet[N, V2] = ???

  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncixRDDEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncixRDDEngineLeet[N, V2] = ???

  override def edges[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): Set[(N, N)] = ???

  override def zeroEdges[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): Set[(N, N)] = ???

  override def values[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] = ???

  override def relativeValues[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): Iterator[((N, N), V)] = ???

  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: IncixRDDEngineLeet[N1, V])(f: N1 => N2): IncixRDDEngineLeet[N2, V] = ???

  override def contract[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V], mapping: Map[N, N]): IncixRDDEngineLeet[N, V] = ???

  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncixRDDEngineLeet[N, V1], to: IncixRDDEngineLeet[N, V2], mapping: Map[N, N]): IncixRDDEngineLeet[N, V1] = ???

  override def reduce[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V])(f: (V, V) => V): V = ???

  override def force[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): IncixRDDEngineLeet[N, V] = ???

  override def abelian[N: CT, V <: AType : CT](l: IncixRDDEngineLeet[N, V]): Group[V] = ???
}