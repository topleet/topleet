package org.unknown1337.topleet

import org.unknown1337.topleet.atypes.AType

abstract class Group[V <: AType] extends Serializable {

  def merge(v1: V, v2: V): V

  def inverse(v: V): V

  def zero: V

  def diff(v1: V, v2: V): V = merge(inverse(v1), v2)
}
