package org.unknown1337.topleet.engines

import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes._

import org.unknown1337.topleet.utils.Utils

import scala.collection.mutable
import scala.reflect.{ClassTag => CT}
import org.unknown1337.topleet.atypes.AMap._

// TODO: Add 'distinct' as this might used contraction.
trait BaseEngine extends Engine {

  override def close(): Unit = {}

  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): Leet[N, V]

  override def subgraph[N: CT, V <: AType : CT](l: Leet[N, V], edges: Set[(N, N)], nodes: Set[N]): Leet[N, V]

  override def subgraph[N: CT, V <: AType : CT](l: Leet[N, V], nodes: Set[N]): Leet[N, V] =
    subgraph(l, edges(l).filter { case (n1, n2) => nodes(n1) && nodes(n2) }, nodes)

  //  override def cartesian[N: CT, V1: CT, V2: CT](l1: Leet[N, ABag[V1]], l2: Leet[N, ABag[V2]]): Leet[N, ABag[(V1, V2)]] =
  //    tmap(product(l1, l2)) { case ATuple(l, r) =>
  //      amap(for ((lv, lcount) <- l.value; (rv, rcount) <- r.value) yield ((lv, rv), AInteger(rcount.value * lcount.value)))
  //    }

  //  override def tmapIxHomValues[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: Leet[N, AMap[K, V1]])(f: V1 => V2)(implicit v2Abelian: Group[V2]): Leet[N, AMap[K, V2]] =
  //    tmapHom(l)(x => x.mapValues { case (k, v) => amap(Map(k -> f(v))) })

  override def acDelta[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V] = {
    implicit val abl: Group[V] = abelian(l)

    val in = incoming(l)
    val bufferTc = mutable.Map[N, Set[N]]()
    val bufferAcyclicDelta = mutable.Map[N, V]()
    val lookup = values(l).toMap

    def tc(n: N): Set[N] = bufferTc.getOrElseUpdate(n, {
      Set(n) ++ in(n).flatMap(x => tc(x))
    })

    def acyclicDelta(n: N): V = bufferAcyclicDelta.getOrElseUpdate(n, {
      val previousAcyclicDelta = tc(n).diff(Set(n)).toSeq.map(x => acyclicDelta(x)).fold(abl.zero)(abl.merge)
      abl.diff(previousAcyclicDelta, lookup(n))
    })

    create(edges(l), ts(l).map(n => (n, acyclicDelta(n))).toMap)
  }

  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V], on: Set[N]): Iterator[(N, K, V)] =
    values(l, on).flatMap { case (n, am) => am.value.map { case (k, v) => (n, k, v) } }


  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Iterator[(N, K, V)] =
    valuesIx(l, nodesIx(l))

  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): PairLeet[N, K, V] = acDelta(l)

  override def size[N: CT, V <: AType : CT](l: Leet[N, V]): Int = nodes(l).size

  override def values[N: CT, V <: AType : CT](l: Leet[N, V]): Iterator[(N, V)] = values(l, nodes(l))

  override def branches[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, ABag[N]] = {
    val in = incoming(l)
    val out = outgoing(l)

    // Remove incomings of n from prev and add n
    val branches = line.scanLeft(Seq[N]()) { case (prev, n) if in(n).toSeq.intersect(prev) == in(n).toSeq => prev.diff(in(n).toSeq).union(List.fill(out(n).size)(n)) }.tail

    // New absolute values.
    val absolutes = line.zip(branches.map(x => abag(x))).toMap

    // New edges.
    val edges = line.zip(line.drop(1)).toSet

    create(edges, absolutes)
  }

  //
  //  override def collectLinearize[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, ABag[V]] = {
  //    val absolutes = values(l).toMap
  //
  //    tmap(branches(l, line)) { x => x.map(absolutes) }
  //  }

  def inDegree[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Int] = {
    val in = incoming(l)
    nodes(l).map(n => (n, in.getOrElse(n, Set()).size)).toMap
  }

  def outDegree[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Int] = {
    val out = outgoing(l)
    nodes(l).map(n => (n, out.getOrElse(n, Set()).size)).toMap
  }

  def degree[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Int] = {
    val in = incoming(l)
    val out = outgoing(l)
    nodes(l).map(n => (n, in.getOrElse(n, Set()).size + out.getOrElse(n, Set()).size)).toMap
  }

  //  // This is most fine grained data.
  //  override def absLinearize[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, V] = {
  //    ???
  //  }
  //
  //  // This is one reduction.
  //  override def firstParentLinearize[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, V] = {
  //    ???
  //  }

  // This is another reduction without 'back and forth' error.
  override def acLinearize[N1: CT, V <: AType : CT](l: Leet[N1, V], line: Seq[N1]): Leet[N1, V] = {
    implicit val abl: Group[V] = abelian(l)
    val ad = values(acDelta(l)).toMap
    val absolutes = line.zip(line.scanLeft(abl.zero) { case (t, n) => abl.merge(t, ad(n)) }).toMap
    val edges = line.zip(line.drop(1)).toSet
    create(edges, absolutes)
  }

  override def acLinearizeIx[N1: CT, K: CT, V <: AType : CT](l: PairLeet[N1, K, V], seq: Seq[N1]): PairLeet[N1, K, V] = {
    implicit val abl: Group[AMap[K, V]] = abelian(l)
    val ad = values(acDeltaIx(l)).toMap
    val absolutes = seq.zip(seq.scanLeft(abl.zero) { case (t, n) => abl.merge(t, ad(n)) }).toMap
    val edges = seq.zip(seq.drop(1)).toSet
    create(edges, absolutes)
  }

  override def authorship[N: CT](l: Leet[N, ADouble]): Leet[N, AMap[N, ADouble]] = {
    val deltas = values(acDelta(l)).toMap.map { case (k, v) => (k, v.toDouble) }
    val lookup = values(l).toMap.map { case (k, v) => (k, v.toDouble) }
    val in = incoming(l)
    val out = outgoing(l)
    val sorting = ts(l).toSeq.reverse
    val bufferTc = mutable.Map[N, Set[N]]()

    def tc(n: N): Set[N] = bufferTc.getOrElseUpdate(n, {
      Set(n) ++ in(n).flatMap(x => tc(x))
    })

    // TODO: Might be a target for dynamic programming.
    val attrs = for (n <- nodes(l)) yield {
      val attr = mutable.Map[N, ADouble]()
      var live = lookup(n)
      var factor = 1.0
      // Walk the revers ts and attribute nodes but only on the nodes contained in the tc.
      for (x <- sorting.intersect(tc(n).toSeq) if factor > 0.0) {
        // Get Change.
        val change = deltas(x)

        if (change > 0) attr.put(x, change * factor)
        else if (change < 0) factor = factor * (live / (live - change))

        live = live - change
      }
      (n, attr.toMap)
    }
    create(edges(l), attrs.toMap.map { case (n, v) => (n, AMap(v)) })
  }

  override def authorshipIx[N: CT, K: CT](l: PairLeet[N, K, ADouble]): PairLeet[N, (N, K), ADouble] = {
    implicit val abl: Group[AMap[(N, K), ADouble]] = AMap.aMapGroup[(N, K), ADouble](ADouble.aDoubleGroup)
    val parts: Iterator[Leet[N, AMap[(N, K), ADouble]]] = for (k <- keys(l).toIterator) yield {
      tmap(authorship(tmap(l) { x => x.value.getOrElse(k, ADouble.zero) })) { r => r.map { n => (n, k) } }
    }
    parts.fold(tmap(zero(l))(_ => abl.zero))(merge(_, _))
  }

  //
  //
  //  // TODO: Implement this as collectDelta and remove it from this interface (to base library).
  //  override def delta[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V] = {
  //    implicit val abl: Group[V] = abelian(l)
  //    val nodeValues = relativeValues(l).toStream.groupBy { case ((_, n2), _) => n2 }
  //      .map { case (n, vs) => (n, vs.map(_._2).fold(abl.zero)(abl.merge)) }
  //    val rootValues = roots(l).map(x => (x, abl.zero)).toMap
  //
  //    create(edges(l), nodeValues ++ rootValues)
  //  }

  /**
    * Moves the delta located on the edges onto the nodes. The delta on the edges is reproduced according
    * to the new node values.
    */
  override def collectDeltas[N: CT, V <: AType : CT](l: Leet[N, V], merges: Boolean = true): PairLeet[N, N, V] = {
    implicit val abl: Group[AMap[N, V]] = AMap.aMapGroup[N, V](abelian(l))
    val exlude = if (!merges) inDegree(l).collect { case (n, i) if i > 1 => n }.toSet else Set[N]()

    val nodeValues = relativeValues(l).toStream.groupBy { case ((_, n2), _) => n2 }
      .map { case (n, vs) => (n, vs.filter(!_._2.isZero).map { case ((n1, _), v) => amap(n1, v) }.fold(abl.zero)(abl.merge)) }

    val rootValues = roots(l).map(x => (x, abl.zero)).toMap

    create(edges(l), (nodeValues ++ rootValues).map {
      case (n, v) if exlude(n) => (n, abl.zero)
      case (n, v) => (n, v)
    })
  }

  //  // TODO: Nice ja: Not sure if M should be AType but looks nice. Maybe N needs to be added.
  //  def acPregel[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: Leet[N, V1])(
  //    message: (V1, V2) => Option[V2])(implicit v2Abelian: Group[V2]): Leet[N, V2]

  //  def aggregateMessages[Msg: ClassTag](
  //                                        sendMsg: EdgeContext[VD, ED, Msg] => Unit,
  //                                        mergeMsg: (Msg, Msg) => Msg,
  //                                        tripletFields: TripletFields = TripletFields.All)
  //  : VertexRDD[A]


  //    = {val abl = abelian(l)
  //    acPregel(l) {
  //      case (v1, v2) if v2 == abl.zero => Some(v1)
  //      case _ => None
  //    }
  //  }

  //
  //  def inDegree[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, AInteger] =
  //    tmap(pregel(tmap(l) { _ => AInteger(-1) })(AInteger(-1), direction = true)(
  //      { case (_, m) => m },
  //      {
  //        case AInteger(-1) => Seq(AInteger(1))
  //        case _ => Seq()
  //      },
  //      { case (AInteger(m1), AInteger(m2)) => AInteger(m1 + m2) }
  //    )) {
  //      case AInteger(-1) => AInteger(-1)
  //      case x => x
  //    }

  // Graph accessors.
  override def incoming[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Set[N]] =
    Utils.incoming(edges(l), nodes(l))

  override def outgoing[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Set[N]] =
    Utils.outgoing(edges(l), nodes(l))

  override def nodes[N: CT, T <: AType : CT](l: Leet[N, T]): Set[N]

  override def roots[N: CT, T <: AType : CT](l: Leet[N, T]): Set[N] =
    Utils.roots(edges(l), nodes(l))

  override def leafs[N: CT, T <: AType : CT](l: Leet[N, T]): Set[N] =
    Utils.leafs(edges(l), nodes(l))

  /**
    * Creates a topological sorting of the acyclic graph.
    */
  override def ts[N: CT, T <: AType : CT](l: Leet[N, T]): Iterator[N] = Utils.ts(edges(l), nodes(l))

  // Not sure if this is needed.
  override def maskBypassEdges[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V] =
    subgraph(l, edges(l).diff(bypassEdges(l).toSet), nodes(l))

  override def bypassEdges[N: CT, V <: AType : CT](l: Leet[N, V]): Iterator[(N, N)] = {
    // Only maintain interesting nodes in tc.
    val ins = incoming(l)
    val outs = outgoing(l)
    val active = mutable.Map[N, Int]()
    val tcs = mutable.Map[N, Set[N]]()

    (for (n <- ts(l)) yield {
      // Check on bypasses.
      val bypasses = ins(n).flatMap(x => tcs(x).diff(Set(x))).intersect(ins(n))

      // The tc of this node is needed outs(n) times.
      active.put(n, outs(n).size)

      // Construct this tc (only containing nodes with more that one output).
      val tc = ins(n).flatMap(x => tcs.getOrElse(x, Set())) ++ (if (outs(n).size > 1) Set(n) else Set())
      tcs.put(n, tc)

      // Decrease activeness.
      for (in <- ins(n)) active.put(in, active(in) - 1)

      // Clean up previous nodes in necessary.
      val clean = ins(n).filter(active(_) == 0)
      clean.foreach(tcs.remove)
      for (x <- tcs.keySet) tcs.put(x, tcs(x).diff(clean))

      // return bypasses.
      bypasses.map(x => (x, n))
    }).flatten
  }

  override def contractEdges[N: CT, V <: AType : CT](l: Leet[N, V], target: Set[(N, N)]): (Leet[N, V], Map[N, N]) = {
    // Recursively contract linear zero sequences.
    val index = ts(l).zipWithIndex.toMap
    val in = incoming(l)

    // Check that there is no bypass preventing things.
    val bypass = Utils.groupByKey(bypassEdges(l).map(_.swap).toSeq).withDefaultValue(Set[N]())

    val contraction = in.toSeq
      .map { case (n, inn) => (n, inn.diff(bypass(n).toSet)) }
      .collect { case (n, inn) if inn.size == 1 => (inn.head, n) }
      .filter(x => target(x)).toSet

    val mapping = Utils.ccsMin(contraction, nodes(l))(index)

    if (mapping.exists { case (n1, n2) => n1 != n2 }) {
      val adaptedTarget = target.map { case (n1, n2) => (mapping(n1), mapping(n2)) }
      val (resultT, resultM) = contractEdges(contract(l, mapping), adaptedTarget)
      (resultT, mapping.mapValues(resultM(_)))
    }
    else (l, mapping)
  }


  override def contractZero[N: CT, V <: AType : CT](l: Leet[N, V]): (Leet[N, V], Map[N, N]) = {
    contractEdges(l, zeroEdges(l))
    //    // Recursively contract linear zero sequences.
    //    lazy val myZeroEdges = zeroEdges(l)
    //    val index = ts(l).zipWithIndex.toMap
    //    val in = incoming(l)
    //
    //    // Check that there is no bypass preventing things.
    //    val bypass = Utils.groupByKey(bypassEdges(l).map(_.swap).toSeq).withDefaultValue(Set[N]())
    //
    //    val contraction = in.toSeq
    //      .map { case (n, inn) => (n, inn.diff(bypass(n).toSet)) }
    //      .collect { case (n, inn) if inn.size == 1 => (inn.head, n) }
    //      .filter(x => myZeroEdges(x)).toSet
    //
    //    val mapping = Utils.ccsMin(contraction, nodes(l))(index)
    //
    //    if (mapping.exists { case (n1, n2) => n1 != n2 }) {
    //      val (resultT, resultM) = contractZero(contract(l, mapping))
    //      (resultT, mapping.mapValues(resultM(_)))
    //    }
    //    else (l, mapping)
  }


  override def createIx[N: CT, K: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, AMap[K, V]])(implicit vAbelian: Group[V]): PairLeet[N, K, V] = leet2PairLeet(create(edges, nodes))

  override def mergeIx[N: CT, K: CT, V <: AType : CT](l1: PairLeet[N, K, V], l2: PairLeet[N, K, V]): PairLeet[N, K, V] = merge(pairLeet2Leet(l1), pairLeet2Leet(l2))

  override def productIx[N: CT, K1: CT, V1 <: AType : CT, K2: CT, V2 <: AType : CT](l1: PairLeet[N, K1, V1], l2: PairLeet[N, K2, V2]): PairLeet[N, (K1, K2), ATuple[V1, V2]] = {
    implicit val ablv1 = abelianIx(l1).asInstanceOf[AbelianAMap[K1, V1]].vAbelian
    implicit val ablv2 = abelianIx(l2).asInstanceOf[AbelianAMap[K2, V2]].vAbelian
    val out = product(pairLeet2Leet(l1), pairLeet2Leet(l2))
    out.tmap { case ATuple(l, r) => l.mapValues { case (k1, v1) => r.mapValues { case (k2, v2) => amap((k1, k2), ATuple(v1, v2)) } } }
  }

  override def tmapIx[N: CT, K: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K, V1])(f: (K, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PairLeet[N, K2, V2] =
    tmap(pairLeet2Leet(l))(x => x.mapValues(f))

  override def tmapHomIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PairLeet[N, K2, V2] =
    tmapHom(pairLeet2Leet(l))(x => x.mapValues(f))

  override def tmapDynamic[N: CT, K1: CT, K2: CT, V1 <: AType : CT](l: PairLeet[N, K1, V1])(f: K1 => K2): PairLeet[N, K2, V1] = {
    implicit val out: Group[V1] = abelianIx(l).asInstanceOf[AbelianAMap[K1,V1]].vAbelian
    tmapHomLinIx(l){case (k,v) => amap(f(k),v)}
  }

  override def tmapHomLinIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PairLeet[N, K2, V2] =
    tmapHomIx(l)(f)

  override def edgesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Set[(N, N)] = edges(pairLeet2Leet(l))

  override def zeroEdgesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Set[(N, N)] = zeroEdges(pairLeet2Leet(l))

  override def relativeValuesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Iterator[((N, N), (K, V))] = relativeValues(pairLeet2Leet(l)).flatMap { case (ns, m) => m.value.toSeq.map(x => (ns, x)) }

  override def sizeIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Int = size(pairLeet2Leet(l))

  override def forceIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): PairLeet[N, K, V] = force(pairLeet2Leet(l))

  override def collectDeltasIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V], merges: Boolean = true): PairLeet[N, (N, K), V] =
    collectDeltas(pairLeet2Leet(l), merges).ungroup()

  override def incomingIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Map[N, Set[N]] = incoming(pairLeet2Leet(l))

  override def outgoingIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Map[N, Set[N]] = outgoing(pairLeet2Leet(l))

  override def nodesIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Set[N] = nodes(pairLeet2Leet(l))

  override def rootsIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Set[N] = roots(pairLeet2Leet(l))

  override def leafsIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Set[N] = leafs(pairLeet2Leet(l))

  override def tsIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Iterator[N] = ts(pairLeet2Leet(l))

  override def abelianIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Group[AMap[K, V]] = abelian(pairLeet2Leet(l))

}


//  // TODO: Signature in progress.
//  def linearize[N1: CT, T: CT](t: Leet[N1, T], seq: Seq[N1]): Leet[N1, T] = {
//    val g = abelian(t)
//    val acdeltas = acdelta(t).values()
//    val absolutes = seq.zip(seq.scanLeft(g.zero) { case (t, n) => g.merge(t, acdeltas(n)) }).toMap
//    val edges = seq.zip(seq.drop(1)).toSet
//    create(edges, absolutes)(classTag[N1], classTag[T], g)
//  }
//

//  //  // TODO: Improve this implementation. (Currently I don't care!)
//  //  def integrate[N: CT, T: CT](t: Leet[N, T]): T = {
//  //    val gt = abelian(t)
//  //    reduce(t)(gt.merge)
//  //  }
//
//

//    val sorted = times.toSeq.sortBy(_._2)
//
//    tmap(l) {
//      case Some(sha) => times(sha)
//      // TODO: This is a hack. remove None node and only use those with sha. Can raise issues with multiple root nodes.
//      case None => times.values.min - 1.0
//    }
//  }
//
//def authorship[N: CT](l: Leet[N, ADouble]): Leet[N, AMap[N, ADouble]] = {
//  val acDeltas = values(acDelta(l)).toMap.map { case (k, v) => (k, v.toDouble) }
//
//  // TODO: There is still an error as this has to be computed for every node.
//  val runs = 100
//  val attributions: Seq[Map[N, Map[N, Double]]] = (1 to runs)
//  .map { seed =>
//  val random = new Random(seed)
//  val ins = incoming(l)
//  val outs = outgoing(l)
//
//  val border = ListBuffer[N]()
//  val visited = mutable.Set[N]()
//  nodes(l).filter(x => ins(x).isEmpty).foreach(border.append(_))
//
//  val sorting = Iterator.fill(size(l)) {
//  // Take a random node from the border or a simple node with one predecessor.
//  val ix = border.indexWhere(x => ins(x).size == 1)
//  val current = border.remove(if (ix == -1) random.nextInt(border.size) else ix)
//  visited.add(current)
//  // Add available elements to the border.
//  for (o <- outs(current) if ins(o).forall(visited))
//  border.append(o)
//  current
//}
//
//  sorting.scanLeft((None.asInstanceOf[Option[N]], Map[N, Double](), 0.0)) {
//  case ((_, b, v), n) if v + acDeltas(n) == 0.0 => (Some(n), Map(), 0.0)
//  case ((_, b, v), n) if acDeltas(n) == 0.0 => (Some(n), b, v)
//  case ((_, b, v), n) if acDeltas(n) > 0.0 => (Some(n), b.updated(n, acDeltas(n)), v + acDeltas(n))
//  case ((_, b, v), n) if acDeltas(n) < 0.0 => (Some(n), b.map { case (k, x) => (k, x * ((v + acDeltas(n)) / v)) }, v + acDeltas(n))
//}.collect { case (Some(n), attr, _) => (n, attr) }.toMap
//}
//
//  val attribution = attributions.reduce[Map[N, Map[N, Double]]] {
//  case (x, y) => (x.keySet ++ y.keySet).map { n => (n, Utils.reduceByKey(x(n).toSeq ++ y(n).toSeq)(_ + _)) }.toMap
//}
//
//  create(edges(l), attribution.mapValues(x => AMap(x.mapValues(y => ADouble(0, y / runs.toDouble))))
//  )
//}