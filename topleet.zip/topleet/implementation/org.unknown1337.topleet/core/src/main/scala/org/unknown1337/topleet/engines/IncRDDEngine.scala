package org.unknown1337.topleet.engines

import scala.reflect._
import org.apache.spark.{HashPartitioner, Partitioner, SparkContext}
import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel
import org.unknown1337.topleet.{Group, SparkUtils2}
import org.unknown1337.topleet.atypes.AMap.ABag
import org.unknown1337.topleet.atypes._
import org.unknown1337.topleet.atypes._
import org.unknown1337.topleet.atypes.AMap._
import org.unknown1337.topleet.libs.{IO, GitViewers, Gits}
import org.unknown1337.topleet.utils.{EdgeUtils, Utils}

import scala.annotation.tailrec
import scala.collection.mutable
import scala.reflect.{ClassTag => CT}


//// TODO: Dont use graph x!
//object IncRDDEngine {
//  def main(args: Array[String]): Unit = {
//    //IncRDDEngineApplication(DelegateCheckEngine(LogEngine(IncRDDEngine(SparkUtils2.spark())), IncEngine())).execute()
//    //IncRDDEngineApplication(IncRDDEngine(SparkUtils2.spark())).execute()
//
//
//    val application = new TracingEntities {
//      @transient
//      override val engine: Engine = LogEngine(IncRDDEngine(SparkUtils2.spark())) //LogEngine()
//    }
//
//    val sha = application.git("jwtk/jjwt")
//    val out = application.application(sha)
//    println(application.engine.values(out))
//  }
//}
//
//case class IncRDDEngineApplication(@transient engine: IncRDDEngine) extends Base with Gits with GitViewers with Javas {
//
//  val charset: String = "UTF-8"
//
//
//  def execute(): Unit = {
//
//    val l = git("Teevity/ice")
//      .resources()
//      .filter { case (path, _) => path.endsWith(".java") }
//      .map(x => x._2)
//      .javaMethodLOC(charset)
//      .group()
//      .acDelta()
//      .sum()
//    //.flatten()
//    //      .map(_._2)
//    //      .sum()
//    //      .force()
//
//    println(l.viewValues())
//  }
//
//}


case class IncRDDPartitioner(partitions: Int, size: Int, checkpointRatio: Double, onlyRootCheckpoint: Boolean) extends Partitioner {

  override def numPartitions: Int = partitions

  override def getPartition(key: Any): Int = key match {
    case l: Long => ((l.toFloat / size.toFloat) * partitions.toFloat).toInt
    case (_: Long, l2: Long) => ((l2.toFloat / size.toFloat) * partitions.toFloat).toInt
  }

  def checkpoint(l: Long): Boolean = if (onlyRootCheckpoint) l == 0 else l % math.max(((size / partitions).toDouble * checkpointRatio).toInt, 1) == 0
}

case class IncRDDEngine(@transient spark: SparkContext, partitions: Int = 64, checkpointRatio: Double = 1.0, persistAll: Boolean = false, onlyRootCheckpoint: Boolean = true) extends BaseEngine {

  type Leet[N, V <: AType] = IncRDDLeet[N, V]

  type PairLeet[N, K, V <: AType] = IncRDDLeet[N, AMap[K, V]]

  val local: IncEngine = IncEngine(threshold = 24)


  case class IncRDDLeet[N: CT, V <: AType : CT](rddNodes: RDD[(Long, (N, Option[V]))],
                                                rddEdges: RDD[((Long, Long), V)],
                                                abelian: Group[V],
                                                nodes: Set[N],
                                                edges: Set[(N, N)],
                                                partitioner: IncRDDPartitioner)

  def createLeet[N: CT, V <: AType : CT](rddNodes: RDD[(Long, (N, Option[V]))],
                                         rddEdges: RDD[((Long, Long), V)],
                                         abelian: Group[V],
                                         nodes: Set[N],
                                         edges: Set[(N, N)],
                                         partitioner: IncRDDPartitioner): IncRDDLeet[N, V] = {
    if (persistAll)
      IncRDDLeet(rddNodes.persist(StorageLevel.MEMORY_AND_DISK), rddEdges.persist(StorageLevel.MEMORY_AND_DISK), abelian, nodes, edges, partitioner)
    else
      IncRDDLeet(rddNodes, rddEdges, abelian, nodes, edges, partitioner)
  }

  def createInner[N: CT, K: CT, V <: AType : CT](vertex: Map[Long, (N, Option[AMap[K, V]])],
                                                 edges: Map[(Long, Long), AMap[K, V]])(implicit abl: Group[AMap[K, V]]): local.Leet[N, AMap[K, V]] = {

    val nodes = vertex.map { case (_, (n, _)) => n }.toSet
    val checkpoints = vertex.collect { case (_, (n, Some(v))) => (n, v) }
    val delta = edges.map { case ((vid1, vid2), v) => ((vertex(vid1)._1, vertex(vid2)._1), v) }
    local.createIncEngineLeet(delta, nodes, checkpoints, abl)
  }

  override def valuesIx[N: CT, K: CT, V <: AType : CT](ll: IncRDDLeet[N, AMap[K, V]], on: Set[N]): Iterator[(N, K, V)] = {
    implicit val abl: Group[AMap[K, V]] = ll.abelian

    val l = if (on != ll.nodes) {
      // Phase 1: Create a subgraph that just contains relevant regions for on.
      val info = ll.rddNodes.map { case (vid, (n, v)) => (n, (vid, v.isDefined)) }.collect().toMap
      val paths = Utils.paths(ll.edges, ll.nodes)
      val checkpoints = info.collect { case (n, (_, true)) => n }.toSet
      val dijkstra = Utils.dijkstra(paths, checkpoints)

      // Build a set of the nodes to keep in the data structure.
      val keep = mutable.Set[N]()

      def travers(x: N): Unit = x match {
        case n if !keep(n) & checkpoints(n) =>
          keep.add(n)
        case n if !keep(n) & !checkpoints(n) =>
          keep.add(n)
          travers(paths(n).minBy(dijkstra))
        case _ =>
      }

      for (n <- on.toSeq.sortBy(dijkstra)) travers(n)

      subgraph(ll, keep.toSet)
      // Phase 2: TODO: Optionally on can use contract before making values thick.
    } else ll

    val vertex = l.rddNodes.flatMap {
      case (vid, (n, Some(v))) =>
        val present = v.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
          .map { case (hash, vv) => (hash, (vid, (n, Some(AMap(vv))))) }
        (0 until partitions).map(p => (p, present.getOrElse(p, (vid, (n, Some(abl.zero))))))
      case (vid, (n, None)) =>
        (0 until partitions).map(p => (p, (vid, (n, None))))
    }.partitionBy(new HashPartitioner(partitions))

    val edges = l.rddEdges.flatMap { case ((vid1, vid2), amap) =>
      val present = amap.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
        .map { case (hash, vv) => (hash, ((vid1, vid2), AMap(vv))) }

      (0 until partitions).map(p => (p, present.getOrElse(p, ((vid1, vid2), abl.zero))))
    }.partitionBy(new HashPartitioner(partitions))

    vertex.zipPartitions(edges) { case (vertexIterator, edgeIterator) =>
      val inner = createInner(vertexIterator.map(_._2).toMap, edgeIterator.map(_._2).toMap)
      local.valuesIx(inner, on)
    }.collect().toIterator
  }

  //  override def cartesian[N: CT, V1: CT, V2: CT](l1: IncRDDLeet[N, ABag[V1]], l2: IncRDDLeet[N, ABag[V2]]): IncRDDLeet[N, ABag[(V1, V2)]] = {
  //    val info = l1.rddNodes.map { case (vid, (n, v)) => (n, (vid, v.isDefined)) }.collect().toMap
  //    val checkpoints = info.collect { case (n, (_, true)) => n }.toSet
  //
  //    val partitions = math.sqrt(this.partitions).toInt
  //    implicit val abl1: Group[ABag[V1]] = l1.abelian
  //    implicit val abl2: Group[ABag[V2]] = l2.abelian
  //
  //    val vertex1 = l1.rddNodes.flatMap {
  //      case (vid, (n, Some(v))) =>
  //        val present = v.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
  //          .map { case (hash, vv) => (hash, (vid, (n, Some(AMap(vv))))) }
  //        (0 until partitions).map(p => (p, present.getOrElse(p, (vid, (n, Some(abl1.zero))))))
  //      case (vid, (n, None)) =>
  //        (0 until partitions).map(p => (p, (vid, (n, None))))
  //    }.partitionBy(new HashPartitioner(partitions))
  //      .glom()
  //
  //
  //    val edges1 = l1.rddEdges.flatMap { case ((vid1, vid2), amap) =>
  //      val present = amap.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
  //        .map { case (hash, vv) => (hash, ((vid1, vid2), AMap(vv))) }
  //
  //      (0 until partitions).map(p => (p, present.getOrElse(p, ((vid1, vid2), abl1.zero))))
  //    }.partitionBy(new HashPartitioner(partitions))
  //      .glom()
  //
  //    val vertex2 = l2.rddNodes.flatMap {
  //      case (vid, (n, Some(v))) =>
  //        val present = v.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
  //          .map { case (hash, vv) => (hash, (vid, (n, Some(AMap(vv))))) }
  //        (0 until partitions).map(p => (p, present.getOrElse(p, (vid, (n, Some(abl2.zero))))))
  //      case (vid, (n, None)) =>
  //        (0 until partitions).map(p => (p, (vid, (n, None))))
  //    }.partitionBy(new HashPartitioner(partitions))
  //      .glom()
  //
  //
  //    val edges2 = l2.rddEdges.flatMap { case ((vid1, vid2), amap) =>
  //      val present = amap.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
  //        .map { case (hash, vv) => (hash, ((vid1, vid2), AMap(vv))) }
  //
  //      (0 until partitions).map(p => (p, present.getOrElse(p, ((vid1, vid2), abl2.zero))))
  //    }.partitionBy(new HashPartitioner(partitions))
  //      .glom()
  //
  //
  //    val results = vertex1.zip(edges1).cartesian(vertex2.zip(edges2)).flatMap { case ((v1, e1), (v2, e2)) =>
  //      val vertex1 = v1.map(_._2).toMap
  //      val edges1 = e1.map(_._2).toMap
  //      val vertex2 = v2.map(_._2).toMap
  //      val edges2 = e2.map(_._2).toMap
  //
  //      val inner1 = createInner(vertex1, edges1)
  //      val inner2 = createInner(vertex2, edges2)
  //
  //      val result = local.moveCheckpoints(local.cartesian(inner1, inner2), checkpoints)
  //      //      val result =  local.tmap(local.product(inner1, inner2)) { case ATuple(l, r) =>
  //      //        amap(for ((lv, lcount) <- l.value; (rv, rcount) <- r.value) yield ((lv, rv), AInteger(rcount.value * lcount.value)))
  //      //      }
  //
  //      // Map shit back.
  //      val inv = vertex1.map { case (vid, (n, _)) => (n, vid) }
  //      val newVertex = result.nodes.map { n => (inv(n), (n, result.checkpoints.get(n))) }
  //      val newEdges = result.delta.map { case ((n1, n2), v) => ((inv(n1), inv(n2)), v) }
  //
  //      newEdges.toIterator ++ newVertex.toIterator
  //    }.persist(StorageLevel.MEMORY_AND_DISK)
  //
  //    val v2Abelian: Group[ABag[(V1, V2)]] = AMap.aMapGroup[(V1, V2), AInteger](AInteger.aIntegerGroup)
  //
  //    // Bring back and sum by abelian.
  //    // TODO: This can be simplified!
  //    val nns = results.collect { case (vid: Long, (n: N, v: Option[ABag[(V1, V2)]])) => (vid, (n, v)) }
  //      .reduceByKey(l1.partitioner, func = {
  //        case ((n1, Some(v1)), (n2, Some(v2))) if n1 == n2 => (n1, Some(v2Abelian.merge(v1, v2)))
  //        case ((n1, None), (n2, None)) if n1 == n2 => (n1, None)
  //      })
  //
  //    val nes = results.collect { case ((vid1: Long, vid2: Long), v: ABag[(V1, V2)]) => ((vid1, vid2), v) }
  //      .reduceByKey(l1.partitioner, func = {
  //        case (a: ABag[(V1, V2)], b: ABag[(V1, V2)]) => v2Abelian.merge(a, b)
  //      })
  //
  //    createLeet(nns, nes, v2Abelian, l1.nodes, l1.edges, l1.partitioner)
  //  }


  def localIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncRDDLeet[N, AMap[K, V1]])(f: local.Leet[N, AMap[K, V1]] => local.Leet[N, V2])(implicit v2Abelian: Group[V2]): IncRDDLeet[N, V2] = {
    implicit val abl = l.abelian
    val vertex = l.rddNodes.flatMap {
      case (vid, (n, Some(v))) =>
        val present = v.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
          .map { case (hash, vv) => (hash, (vid, (n, Some(AMap(vv))))) }
        (0 until partitions).map(p => (p, present.getOrElse(p, (vid, (n, Some(abl.zero))))))
      case (vid, (n, None)) =>
        (0 until partitions).map(p => (p, (vid, (n, None))))
    }.partitionBy(new HashPartitioner(partitions))

    val edges = l.rddEdges.flatMap { case ((vid1, vid2), amap) =>
      val present = amap.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
        .map { case (hash, vv) => (hash, ((vid1, vid2), AMap(vv))) }

      (0 until partitions).map(p => (p, present.getOrElse(p, ((vid1, vid2), abl.zero))))
    }.partitionBy(new HashPartitioner(partitions))

    val results = vertex.zipPartitions(edges) { case (vertexIterator, edgeIterator) =>
      val vertex = vertexIterator.map(_._2).toMap
      val edges = edgeIterator.map(_._2).toMap

      val result = f(createInner(vertex, edges))

      // Map shit back.
      val inv = vertex.map { case (vid, (n, _)) => (n, vid) }
      val newVertex = result.nodes.map { n => (inv(n), (n, result.checkpoints.get(n))) }
      val newEdges = result.delta.map { case ((n1, n2), v) => ((inv(n1), inv(n2)), v) }

      newEdges.toIterator ++ newVertex.toIterator
    }.persist(StorageLevel.MEMORY_AND_DISK)
    // Bring back and sum by abelian.
    // TODO: This can be simplified!
    val nns = results.collect { case (vid: Long, (n: N, v: Option[V2])) => (vid, (n, v)) }
      .reduceByKey(l.partitioner, func = {
        case ((n1, Some(v1)), (n2, Some(v2))) if n1 == n2 => (n1, Some(v2Abelian.merge(v1, v2)))
        case ((n1, None), (n2, None)) if n1 == n2 => (n1, None)
      })

    val nes = results.collect { case ((vid1: Long, vid2: Long), v: V2) => ((vid1, vid2), v) }
      .reduceByKey(l.partitioner, func = {
        case (a: V2, b: V2) => v2Abelian.merge(a, b)
      })

    createLeet(nns, nes, v2Abelian, l.nodes, l.edges, l.partitioner)
  }

  def thickPartition[N: CT, V <: AType : CT](rddNodes: RDD[(Long, (N, Option[V]))], rddEdges: RDD[((Long, Long), V)], partitioner: IncRDDPartitioner, vAbelian: Group[V]): RDD[(Long, (N, Option[V]))] = {
    rddNodes.zipPartitions(rddEdges, preservesPartitioning = true) { case (vertexIterator, edgeIterator) =>
      val vertexArray = vertexIterator.toArray
      val edgeArray = edgeIterator.toArray

      // Delta between nodes in any direction.
      val delta = Utils.groupByKey(
        edgeArray.map { case ((src, dst), attr) => (src, (dst, attr)) }.toSeq ++
          edgeArray.map { case ((src, dst), attr) => (dst, (src, vAbelian.inverse(attr))) }.toSeq)

      // Currently available data.
      val checkpoints = vertexArray.collect { case (id, (_, Some(v))) => (id, v) }.toMap

      @tailrec
      def traverse(current: Map[Long, V], border: Set[Long]): Map[Long, V] = {
        if (border.isEmpty) current
        else {
          val added = (for (b <- border; (vid, d) <- delta.getOrElse(b, Seq()) if !current.isDefinedAt(vid)) yield vid -> vAbelian.merge(current(b), d)).toMap
          traverse(current ++ added, added.keySet)
        }
      }

      val thick = traverse(checkpoints, checkpoints.keySet)

      vertexArray.toIterator.map { case (vid, (n, _)) => (vid, (n, thick.get(vid))) }
    }
  }

  def thick1Hop[N: CT, V <: AType : CT](rddNodes: RDD[(Long, (N, Option[V]))], rddEdges: RDD[((Long, Long), V)], partitioner: IncRDDPartitioner, vAbelian: Group[V]): RDD[(Long, (N, Option[V]))] = {
    val crossPartitionEdges = rddEdges.filter { case ((vid1, vid2), _) => partitioner.getPartition(vid1) != partitioner.getPartition(vid2) }
    val out = EdgeUtils.triplets(crossPartitionEdges, rddNodes, partitioner)
      .flatMap { case ((vid1, vid2), (Some((n1, v1)), delta, Some((n2, v2)))) =>
        v2.toSeq.map(v => (vid1, (n1, Some(vAbelian.merge(v, vAbelian.inverse(delta))).asInstanceOf[Option[V]]))) ++
          v1.toSeq.map(v => (vid2, (n2, Some(vAbelian.merge(v, delta)).asInstanceOf[Option[V]])))
      }

    (out ++ rddNodes).reduceByKey(partitioner, func = {
      case ((n1, Some(v)), (n2, _)) if n1 == n2 => (n1, Some(v))
      case ((n1, _), (n2, Some(v))) if n1 == n2 => (n1, Some(v))
      case ((n1, _), (n2, _)) if n1 == n2 => (n1, None)
    })
  }

  def thick[N: CT, V <: AType : CT](rddNodes: RDD[(Long, (N, Option[V]))], rddEdges: RDD[((Long, Long), V)], partitioner: IncRDDPartitioner, vAbelian: Group[V]): RDD[(Long, (N, V))] = {

    def missingThick(ns: RDD[(Long, (N, Option[V]))]) = ns.map {
      case (_, (_, v)) if v.isDefined => 0
      case _ => 1
    }.sum()

    // Iteratively materialize partition and cross partition.
    var current = thickPartition(rddNodes, rddEdges, partitioner, vAbelian).persist(StorageLevel.MEMORY_AND_DISK)
    var last = current
    var mt = missingThick(current)
    while (mt != 0) {
      current = thick1Hop(current, rddEdges, partitioner, vAbelian)
      current = thickPartition(current, rddEdges, partitioner, vAbelian).persist(StorageLevel.MEMORY_AND_DISK)
      mt = missingThick(current)
      last.unpersist()
    }
    current.mapValues { case (n, Some(v)) => (n, v) }
  }

  def thin[N: CT, V <: AType : CT](vertices: RDD[(Long, (N, V))], edges: RDD[((Long, Long), Void)], partitioner: IncRDDPartitioner, vAbelian: Group[V]):
  (RDD[(Long, (N, Option[V]))], RDD[((Long, Long), V)]) = {
    // Create delta edges.
    val deltas = EdgeUtils.triplets(edges, vertices.mapValues(_._2), partitioner)
      .mapValues { case (Some(v1), _, Some(v2)) => vAbelian.diff(v1, v2) }

    // Create thin representation.
    val thinVertices = vertices.mapPartitions({ it =>
      it.map {
        case (vid, (n, v)) if partitioner.checkpoint(vid) => (vid, (n, Some(v)))
        case (vid, (n, v)) if !partitioner.checkpoint(vid) => (vid, (n, None))
      }
    }, true)

    (thinVertices, deltas)
  }

  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): IncRDDLeet[N, V] = {
    val index = Utils.ts(edges, nodes.keySet).zipWithIndex.toMap.map { case (k, v) => (k, v.toLong) }
    // Create the partitioner for this topology.
    val partitioner = IncRDDPartitioner(partitions, nodes.size, checkpointRatio, onlyRootCheckpoint)

    val thickNodes = spark.parallelize(nodes.toSeq, partitions)
      .map { case (n, v) => (index(n), (n, v)) }
      .partitionBy(partitioner)
    val thickEdges = spark.parallelize(edges.toSeq, partitions)
      .map { case (n1, n2) => ((index(n1), index(n2)), null.asInstanceOf[Void]) }
      .partitionBy(partitioner)

    val (nns, nes) = thin(thickNodes, thickEdges, partitioner, vAbelian)

    createLeet(nns, nes, vAbelian, nodes.keySet, edges, partitioner)
  }

  override def nodes[N: CT, T <: AType : CT](l: IncRDDLeet[N, T]): Set[N] = l.nodes

  override def reverse[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): IncRDDLeet[N, V] = {
    val vAbelian = l.abelian
    val nes = l.rddEdges.map { case ((vid1, vid2), v) => ((vid2, vid2), vAbelian.inverse(v)) }
      .partitionBy(l.partitioner)

    createLeet(l.rddNodes, nes, vAbelian, l.nodes, l.edges.map(_.swap), l.partitioner)
  }

  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncRDDLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncRDDLeet[N, V2] = {
    val thickNodes = thick(l.rddNodes, l.rddEdges, l.partitioner, l.abelian).mapValues { case (n, v1) => (n, f(v1)) }
    val thickEdges = l.rddEdges.mapValues(v => null.asInstanceOf[Void])

    val (thinNodes, thinEdges) = thin(thickNodes, thickEdges, l.partitioner, v2Abelian)

    createLeet(thinNodes, thinEdges, v2Abelian, l.nodes, l.edges, l.partitioner)
  }

  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncRDDLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncRDDLeet[N, V2] = {
    val nns = l.rddNodes.mapValues { case (n, v) => (n, v.map(f)) }
    val nes = l.rddEdges.mapValues(f)
    createLeet(nns, nes, v2Abelian, l.nodes, l.edges, l.partitioner)
  }

  //  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncRDDLeet[N, K, V1])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): IncRDDLeet[N, V2] =
  //    localIx(l)(x => local.tmapIx(x)(f))

  override def merge[N: CT, V <: AType : CT](l1: IncRDDLeet[N, V], l2: IncRDDLeet[N, V]): IncRDDLeet[N, V] = {
    assert(l1.partitioner == l2.partitioner)
    val vAbelian = l1.abelian
    val nns = l1.rddNodes.join(l2.rddNodes, l1.partitioner).mapValues {
      case ((n1, Some(v1)), (n2, Some(v2))) if n1 == n2 => (n1, Some(vAbelian.merge(v1, v2)))
      case ((n1, None), (n2, None)) if n1 == n2 => (n1, None)
    }

    val nes = l1.rddEdges.join(l2.rddEdges, l1.partitioner).mapValues {
      case (v1, v2) => vAbelian.merge(v1, v2)
    }
    createLeet(nns, nes, vAbelian, l1.nodes, l1.edges, l1.partitioner)
  }

  override def zero[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): IncRDDLeet[N, V] = ???

  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: IncRDDLeet[N, V1], l2: IncRDDLeet[N, V2]): IncRDDLeet[N, ATuple[V1, V2]] = {
    assert(l1.partitioner == l2.partitioner)
    val abl = ATuple.aTupleGroup(l1.abelian, l2.abelian)
    val nns = l1.rddNodes.join(l2.rddNodes, l1.partitioner).mapValues {
      case ((n1, Some(v1)), (n2, Some(v2))) if n1 == n2 => (n1, Some(ATuple(v1, v2)))
      case ((n1, None), (n2, None)) if n1 == n2 => (n1, None)
    }

    val nes = l1.rddEdges.join(l2.rddEdges, l1.partitioner).mapValues {
      case (v1, v2) => ATuple(v1, v2)
    }
    createLeet(nns, nes, abl, l1.nodes, l1.edges, l1.partitioner)
  }

  override def edges[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): Set[(N, N)] = l.edges

  override def zeroEdges[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): Set[(N, N)] =
    EdgeUtils.triplets(l.rddEdges, l.rddNodes.mapValues(_._1), l.partitioner).collect { case (_, (Some(n1), delta, Some(n2))) if delta.isZero => (n1, n2) }.collect().toSet

  // TODO: Figure out some way to consider parameter 'on' in thick. I think this should be possible by just keeping 'ons' and computing all others just one time. DO THAT!
  override def values[N: CT, V <: AType : CT](ll: IncRDDLeet[N, V], on: Set[N]): Iterator[(N, V)] = {

    val abl = ll.abelian
    val vertex = ll.rddNodes.map { case (id, (n, v)) => (id, n) }.collectAsMap()
    val edges = ll.edges
    val nodes = ll.nodes
    val checkpoints = ll.rddNodes.collect { case (_, (n, Some(v))) => (n, v) }.collectAsMap().toMap
    val delta = ll.rddEdges.collectAsMap().toMap.map { case ((vid1, vid2), v) => ((vertex(vid1), vertex(vid2)), v) }

    local.values(local.createIncEngineLeet(delta, nodes, checkpoints, abl), on)

    //    val l = if (on != ll.nodes) {
    //      // Phase 1: Create a subgraph that just contains relevant regions for on.
    //      val info = ll.rddNodes.map { case (vid, (n, v)) => (n, (vid, v.isDefined)) }.collect().toMap
    //      val paths = Utils.paths(ll.edges, ll.nodes)
    //      val checkpoints = info.collect { case (n, (_, true)) => n }.toSet
    //      println("check: " + checkpoints.size)
    //      println("nodes: " + ll.nodes.size)
    //      val dijkstra = Utils.dijkstra(paths, checkpoints)
    //
    //      // Build a set of the nodes to keep in the data structure.
    //      val keep = mutable.Set[N]()
    //
    //      def travers(x: N): Unit = x match {
    //        case n if !keep(n) & checkpoints(n) =>
    //          keep.add(n)
    //        case n if !keep(n) & !checkpoints(n) =>
    //          keep.add(n)
    //          travers(paths(n).minBy(dijkstra))
    //        case _ =>
    //      }
    //
    //      for (n <- on.toSeq.sortBy(dijkstra)) travers(n)
    //
    //      println("keep: " + keep.size)
    //      subgraph(ll, keep.toSet)
    //      // Phase 2: TODO: Optionally on can use contract before making values thick.
    //    } else ll
    //
    //    thick(l.rddNodes, l.rddEdges, l.partitioner, l.abelian).values.filter { case (n, _) => on(n) }.collect().toIterator
  }


  override def relativeValues[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): Iterator[((N, N), V)] =
    EdgeUtils.triplets(l.rddEdges, l.rddNodes.mapValues(_._1), l.partitioner).map { case (_, (Some(n1), delta, Some(n2))) => ((n1, n2), delta) }.collect().toIterator

  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: IncRDDLeet[N1, V])(f: N1 => N2): IncRDDLeet[N2, V] = ???

  override def contract[N: CT, V <: AType : CT](l: IncRDDLeet[N, V], mapping: Map[N, N]): IncRDDLeet[N, V] = ???

  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncRDDLeet[N, V1], to: IncRDDLeet[N, V2], mapping: Map[N, N]): IncRDDLeet[N, V1] = ???

  override def reduce[N: CT, V <: AType : CT](l: IncRDDLeet[N, V])(f: (V, V) => V): V =
    thick(l.rddNodes, l.rddEdges, l.partitioner, l.abelian).map(_._2._2).reduce(f)

  override def keys[N: CT, K: CT, V <: AType : CT](l: IncRDDLeet[N, AMap[K, V]]): Set[K] =
    l.rddNodes.values.collect { case (_, Some(v)) => v.keys() }.reduce(_ ++ _) ++ l.rddEdges.map(_._2.keys()).reduce(_ ++ _)

  override def force[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): IncRDDLeet[N, V] =
    createLeet(l.rddNodes.persist(StorageLevel.MEMORY_AND_DISK), l.rddEdges.persist(StorageLevel.MEMORY_AND_DISK), l.abelian, l.nodes, l.edges, l.partitioner)

  //  def checkpoint[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): IncRDDLeet[N, V] =
  //    createLeet(l.rddNodes., l.rddEdges.persist(StorageLevel.MEMORY_AND_DISK), l.abelian, l.nodes, l.edges, l.partitioner)


  override def abelian[N: CT, V <: AType : CT](l: IncRDDLeet[N, V]): Group[V] = l.abelian

  override def subgraph[N: CT, V <: AType : CT](l: IncRDDLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): IncRDDLeet[N, V] = {
    val nns = l.rddNodes.filter { case (_, (n, _)) => nodes(n) }
    val nes = EdgeUtils.triplets(l.rddEdges, l.rddNodes.mapValues(_._1), l.partitioner).mapPartitions({ iterator =>
      iterator.collect { case ((vid1, vid2), (Some(n1), d, Some(n2))) if edges((n1, n2)) => ((vid1, vid2), d) }
    }, true)
    createLeet(nns, nes, l.abelian, nodes.intersect(l.nodes), edges.intersect(l.edges), l.partitioner)
  }

  override def append[N: CT, V <: AType : CT](l1: IncRDDLeet[N, V], l2: IncRDDLeet[N, V]): IncRDDLeet[N, V] = ???

  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: IncRDDLeet[N, AMap[K, V]]): IncRDDLeet[N, AMap[K, V]] = {
    implicit val abl: Group[AMap[K, V]] = l.abelian
    localIx(l)(x => local.acDeltaIx(x))
  }

  override def authorshipIx[N: CT, K: CT](l: IncRDDLeet[N, AMap[K, ADouble]]): IncRDDLeet[N, AMap[(N, K), ADouble]] =
    localIx(l)(x => local.authorshipIx(x))

  override def collectDeltas[N: CT, V <: AType : CT](l: IncRDDLeet[N, V], merges: Boolean = true): IncRDDLeet[N, AMap[N, V]] = {
    // TODO: Currently merges are not included/excluded.
    ???
    //    val ablMap = AMap.aMapGroup[N, V](l.abelian)
    //
    //    val deltas = EdgeUtils.triplets(l.rddEdges.filter(!_._2.isZero), l.rddNodes, l.partitioner)
    //      .map { case ((_, vid2), (Some((nsrc, _)), delta, Some((ndst, _)))) => (vid2, (ndst, AMap.create(nsrc, delta))) }
    //
    //    val zeros = l.rddNodes.map { case (vid, (n, _)) => (vid, (n, ablMap.zero)) }
    //
    //    val thickNodes = (deltas ++ zeros)
    //      .reduceByKey(l.partitioner, func = {
    //        case ((n1, v1), (n2, v2)) if n1 == n2 => (n1, ablMap.merge(v1, v2))
    //      })
    //    val thickEdges = l.rddEdges.mapValues(_ => null.asInstanceOf[Void])
    //
    //    val (nns, nes) = thin(thickNodes, thickEdges, l.partitioner, ablMap)
    //
    //    createLeet(nns, nes, ablMap, l.nodes, l.edges, l.partitioner)

  }

  override implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: IncRDDLeet[N, AMap[K, V]]): IncRDDLeet[N, AMap[K, V]] = pairLeet

  override implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: IncRDDLeet[N, AMap[K, V]]): IncRDDLeet[N, AMap[K, V]] = leet

  //override def productIx[N: CT, K1 :  CT, V1 <: AType : CT, K2 : CT, V2 <: AType : CT](l1: IncRDDLeet[N, AMap[K1, V1]], l2: IncRDDLeet[N, K2, V2]): IncRDDLeet[N, (K1, K2), ATuple[V1, V2]] = ???
}