//package org.unknown1337.topleet.engines
//
//import org.unknown1337.topleet.Group
//import org.unknown1337.topleet.atypes._
//
//import scala.reflect.{ClassTag => CT, _}
//
//class DelegateEngine(var delegate: Engine) extends Engine {
//
//  case class DelegateEngineLeet[N:CT,V<: AType:CT](engine: Engine)( val leet: engine.Leet[N,V])
//
//  override type Leet[N, V <: AType] = DelegateEngineLeet[N, V]
//
//  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): DelegateEngineLeet[N, V] =
//    DelegateEngineLeet(delegate)(delegate.create(edges, nodes))
//
//  override def reverse[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] =
//    DelegateEngineLeet(l.engine)(l.engine.reverse(l.leet))
//
//  override def subgraph[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): DelegateEngineLeet[N, V] = ???
//
//  override def subgraph[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], nodes: Set[N]): DelegateEngineLeet[N, V] = ???
//
//  override def append[N: CT, V <: AType : CT](l1: DelegateEngineLeet[N, V], l2: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def merge[N: CT, V <: AType : CT](l1: DelegateEngineLeet[N, V], l2: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def zero[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: DelegateEngineLeet[N, V1], l2: DelegateEngineLeet[N, V2]): DelegateEngineLeet[N, ATuple[V1, V2]] = ???
//
//  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DelegateEngineLeet[N, V2] = ???
//
//  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DelegateEngineLeet[N, V2] = ???
//
//  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateEngineLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): DelegateEngineLeet[N, V2] = ???
//
//  override def tmapIxHomValues[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateEngineLeet[N, AMap[K, V1]])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DelegateEngineLeet[N, AMap[K, V2]] = ???
//
//  override def edges[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Set[(N, N)] = ???
//
//  override def zeroEdges[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Set[(N, N)] = ???
//
//  override def values[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Iterator[(N, V)] = ???
//
//  override def values[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] = ???
//
//  override def relativeValues[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Iterator[((N, N), V)] = ???
//
//  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: DelegateEngineLeet[N1, V])(f: N1 => N2): DelegateEngineLeet[N2, V] = ???
//
//  override def contract[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], mapping: Map[N, N]): DelegateEngineLeet[N, V] = ???
//
//  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DelegateEngineLeet[N, V1], to: DelegateEngineLeet[N, V2], mapping: Map[N, N]): DelegateEngineLeet[N, V1] = ???
//
//  override def reduce[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V])(f: (V, V) => V): V = ???
//
//  override def cartesian[N: CT, V1: CT, V2](l1: DelegateEngineLeet[N, ABag[V1]], l2: DelegateEngineLeet[N, ABag[V2]]): DelegateEngineLeet[N, ABag[(V1, V2)]] = ???
//
//  override def acDelta[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: DelegateEngineLeet[N, AMap[K, V]]): DelegateEngineLeet[N, AMap[K, V]] = ???
//
//  override def size[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Int = ???
//
//  override def branches[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], line: Seq[N]): DelegateEngineLeet[N, ABag[N]] = ???
//
//  override def collectLinearize[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], line: Seq[N]): DelegateEngineLeet[N, ABag[V]] = ???
//
//  override def acLinearize[N1: CT, V <: AType : CT](l: DelegateEngineLeet[N1, V], line: Seq[N1]): DelegateEngineLeet[N1, V] = ???
//
//  override def acLinearizeIx[N1: CT, K: CT, V <: AType : CT](l: DelegateEngineLeet[N1, AMap[K, V]], seq: Seq[N1]): DelegateEngineLeet[N1, AMap[K, V]] = ???
//
//  override def authorship[N: CT](l: DelegateEngineLeet[N, ADouble]): DelegateEngineLeet[N, AMap[N, ADouble]] = ???
//
//  override def authorshipIx[N: CT, K: CT](l: DelegateEngineLeet[N, AMap[K, ADouble]]): DelegateEngineLeet[N, AMap[(N, K), ADouble]] = ???
//
//  override def force[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def delta[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def collectDeltas[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, AMap[N, V]] = ???
//
//  override def incoming[N: CT, T <: AType : CT](l: DelegateEngineLeet[N, T]): Map[N, Set[N]] = ???
//
//  override def outgoing[N: CT, T <: AType : CT](l: DelegateEngineLeet[N, T]): Map[N, Set[N]] = ???
//
//  override def nodes[N: CT, T <: AType : CT](l: DelegateEngineLeet[N, T]): Set[N] = ???
//
//  override def roots[N: CT, T <: AType : CT](l: DelegateEngineLeet[N, T]): Set[N] = ???
//
//  override def leafs[N: CT, T <: AType : CT](l: DelegateEngineLeet[N, T]): Set[N] = ???
//
//  override def ts[N: CT, T <: AType : CT](l: DelegateEngineLeet[N, T]): Iterator[N] = ???
//
//  override def abelian[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Group[V] = ???
//
//  override def maskBypassEdges[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): DelegateEngineLeet[N, V] = ???
//
//  override def bypassEdges[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): Iterator[(N, N)] = ???
//
//  override def contractEdges[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V], target: Set[(N, N)]): (DelegateEngineLeet[N, V], Map[N, N]) = ???
//
//  override def contractZero[N: CT, V <: AType : CT](l: DelegateEngineLeet[N, V]): (DelegateEngineLeet[N, V], Map[N, N]) = ???
//
//}
