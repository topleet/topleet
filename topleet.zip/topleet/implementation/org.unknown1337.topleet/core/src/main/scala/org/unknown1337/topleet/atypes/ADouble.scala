package org.unknown1337.topleet.atypes

import org.unknown1337.topleet.Group

object ADouble {

  implicit def toADouble(x: Double): ADouble = if (x.isNaN | x.isInfinity) ADouble(1, 0) else ADouble(0, x)

  def zero: ADouble = ADouble(0, 0.0)

  def inverse(v: ADouble): ADouble = ADouble(-v.nans, -v.value)

  def merge(v1: ADouble, v2: ADouble): ADouble = ADouble(v1.nans + v2.nans, v1.value + v2.value)

  implicit def aDoubleGroup: Group[ADouble] = new Group[ADouble] {

    override def merge(v1: ADouble, v2: ADouble): ADouble = ADouble.merge(v1, v2)

    override def inverse(v: ADouble): ADouble = ADouble.inverse(v)

    override def zero: ADouble = ADouble.zero
  }
}

case class ADouble(nans: Int, value: Double) extends AType {

  implicit def toDouble: Double = if (nans != 0) Double.NaN else value

  override def toString: String = nans match {
    case 0 => "(Abl) " + value
    //case 0 => "(Abl) " + BigDecimal(value).setScale(8, BigDecimal.RoundingMode.HALF_UP).toDouble.toString
    case x if x < 0 => "(Abl) -NaN "
    case x if x > 0 => "(Abl) +NaN"
  }

  override def ~=(other: AType): Boolean = {
    if (!other.isInstanceOf[ADouble]) return false
    val o = other.asInstanceOf[ADouble]
    // Also using relative change in case of big values.
    o.nans == this.nans && (Math.abs(o.value - this.value) < 0.00001)
  }

  override def isZero: Boolean = ADouble.zero == this

  override def isApproxZero: Boolean = ADouble.zero ~= this

  override def pretty(): String = value.toString

  /**
    * Length of the delta in terms of effort needed to conduct it.
    */
  override def dlength(): Double = Math.abs(value) + Math.abs(nans).toDouble
}
