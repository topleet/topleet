package org.unknown1337.topleet.libs

import org.unknown1337.topleet.atypes._
import org.unknown1337.topleet.engines.Engine

import AMap._
import scala.reflect.{ClassTag => CT}

trait Wrangling {

  val engine: Engine

  implicit class ADoublesProvide[N: CT](@transient l: engine.Leet[N, ADouble]) extends Serializable {

    //    def pow(exponent: Double): engine.Leet[N, ADouble] = l.tmap { x => Math.pow(x, exponent) }
    //
    //    def *(that: Double): engine.Leet[N, ADouble] = l.tmapHom { x => x * that }
    //
    //    def /(that: Double): engine.Leet[N, ADouble] = l.tmapHom { x => x / that }
    //
    //    def *(that: engine.Leet[N, ADouble]): engine.Leet[N, ADouble] = product(l, that).tmap { case ATuple(x, y) => x * y }
    //
    //    def -(that: engine.Leet[N, ADouble]): engine.Leet[N, ADouble] = l + that.neg()
    //
    //    def /(that: engine.Leet[N, ADouble]): engine.Leet[N, ADouble] = l * that.pow(-1)
    //
    //    def toInt: engine.Leet[N, AInteger] = l.tmap { x => x.toInt }

    def acDelta(): engine.Leet[N, ADouble] = engine.acDelta(l)
  }

  implicit class AIntegersProvide[N: CT](@transient l: engine.Leet[N, AInteger]) extends Serializable {
    //
    //    def *(that: Integer): engine.Leet[N, AInteger] = l.tmapHom { x => x * that }
    //
    //    def /(that: Integer): engine.Leet[N, AInteger] = l.tmapHom { x => x / that }
    //
    //    def *(that: engine.Leet[N, AInteger]): engine.Leet[N, AInteger] = product(l, that).tmap { case ATuple(x, y) => x * y }
    //
    //    def -(that: engine.Leet[N, AInteger]): engine.Leet[N, AInteger] = l + that.neg()
    //
    //    def /(that: engine.Leet[N, AInteger]): engine.Leet[N, AInteger] = product(l, that).tmap { case ATuple(x, y) => x / y }
    //
    //    def toDouble: engine.Leet[N, ADouble] = l.tmapHom { x => x.toDouble }

    def acDelta(): engine.Leet[N, AInteger] = engine.acDelta(l)

    //    def valuesAInteger(): Iterator[(N, Int)] = engine.values(l).map { case (n, AInteger(v)) => (n, v) }
  }

  //
  //  implicit class BagsWithNumbersOfDoubleProvide[N: CT](@transient l: engine.Leet[N, ABag[Double]]) extends Serializable {
  //
  //    def neg(): engine.Leet[N, ABag[Double]] = l.map { x => -x }
  //
  //    def pow(exponent: Double): engine.Leet[N, ABag[Double]] = l.map { x => Math.pow(x, exponent) }
  //
  //    def *(that: engine.Leet[N, ADouble]): engine.Leet[N, ABag[Double]] =
  //      product(l, that).tmap { case ATuple(bag, d) => ABag.map(bag)(v => v * d) }
  //
  //    def +(that: engine.Leet[N, ADouble]): engine.Leet[N, ABag[Double]] =
  //      product(l, that).tmap { case ATuple(bag, d) => ABag.map(bag)(v => v + d) }
  //
  //    def /(that: engine.Leet[N, ADouble]): engine.Leet[N, ABag[Double]] = l * that.pow(-1)
  //
  //    def -(that: engine.Leet[N, ADouble]): engine.Leet[N, ABag[Double]] = l + that.neg()
  //
  //    def toInt: engine.Leet[N, ABag[Int]] = l.map { x => x.toInt }
  //
  //    def sum(): engine.Leet[N, ADouble] = engine.tmapHom(l)(v => ABag.sumDouble(v))
  //
  //    def mean(): engine.Leet[N, ADouble] = l.sum() / l.count().toDouble
  //
  //    def variance(): engine.Leet[N, ADouble] = (l - l.mean()).pow(2).sum() / l.count().toDouble
  //
  //    //    def variance(): engine.Leet[N, ADouble] = product((l - l.mean()).pow(2).sum(), l.count().toDouble).tmap {
  //    //      case ATuple(s, c) => if (c < 2) 0.0 else s / c
  //    //    }
  //
  //    def std(): engine.Leet[N, ADouble] = l.variance().pow(1.0 / 2.0)
  //  }
  //
  //  implicit class BagsWithNumbersOfIntegersProvide[N: CT](@transient l: engine.Leet[N, ABag[Int]]) extends Serializable {
  //
  //    def neg(): engine.Leet[N, ABag[Int]] = l.map { x => -x }
  //
  //    //def pow(exponent: Double): engine.Leet[N, Bag[Integer]] = l.map { x => Math.pow(x, exponent) }
  //
  //    def *(that: engine.Leet[N, AInteger]): engine.Leet[N, ABag[Int]] =
  //      product(l, that).tmap { case ATuple(bag, d) => ABag.map(bag)(v => v * d) }
  //
  //    def +(that: engine.Leet[N, AInteger]): engine.Leet[N, ABag[Int]] =
  //      product(l, that).tmap { case ATuple(bag, d) => ABag.map(bag)(v => v + d) }
  //
  //    def /(that: engine.Leet[N, AInteger]): engine.Leet[N, ABag[Int]] =
  //      product(l, that).tmap { case ATuple(bag, d) => ABag.map(bag)(v => v / d) }
  //
  //    def -(that: engine.Leet[N, AInteger]): engine.Leet[N, ABag[Int]] = l + that.neg()
  //
  //    def toDouble: engine.Leet[N, ABag[Double]] = l.map { x => x.toDouble }
  //
  //    def sum(): engine.Leet[N, AInteger] = engine.tmapHom(l)(v => ABag.sumInt(v))
  //  }
  //
  //  implicit class MapsWithDoubleProvide2[N: CT, K: CT](@transient l: engine.Leet[N, AMap[K, ADouble]]) extends Serializable {
  //
  //    // TODO: This might also be some indexed application.
  //    def *(that: engine.Leet[N, ADouble]): engine.Leet[N, AMap[K, ADouble]] =
  //      product(l, that).tmap { case ATuple(x, y) => AMap.mapValues(x)(v => v * y) }
  //
  //  }
  //
  implicit class MapsWithDoubleProvide1[N: CT, K: CT](@transient l: engine.Leet[N, AMap[K, ADouble]]) extends Serializable {
    //    def neg(): engine.Leet[N, AMap[K, ADouble]] = l.tmapIxValues { x => -x }
    //
    //    def pow(exponent: Double): engine.Leet[N, AMap[K, ADouble]] = l.tmapIxValues { x => Math.pow(x.toDouble, exponent) }
    //
    //    def *(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ADouble]] =
    //      join(l, that).tmapIxValues { case ATuple(x, y) => x.toDouble * y.toDouble }

    //
    //    // TODO: Not shure if this is a homo.
    //    def +(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ADouble]] =
    //      join(l, that).tmapHom { x => AMap.mapValues(x)(v => v.t1 + v.t2) }
    //
    //    def /(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ADouble]] = l * that.pow(-1)
    //
    //    def -(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ADouble]] = l + that.neg()

    //    def toInt: engine.Leet[N, AMap[K, AInteger]] = l.tmapIxValues { x => x.toDouble.toInt }
  }

  implicit class MapsWithIntProvide[N: CT, K: CT](@transient l: engine.Leet[N, AMap[K, AInteger]]) extends Serializable {
    //    def neg(): engine.Leet[N, AMap[K, AInteger]] = l.tmapIxValues { x => -x }
    //  TODO: Seem to be wrong.
    //    def *(that: engine.Leet[N, AMap[K, AInteger]]): engine.Leet[N, AMap[K, AInteger]] =
    //      join(l, that).tmap { x => AMap.mapValues(x)(v => v.t1 * v.t2) }
    //
    //    // TODO: Not shure if this is a homo.
    //    def +(that: engine.Leet[N, AMap[K, AInteger]]): engine.Leet[N, AMap[K, AInteger]] =
    //      join(l, that).tmapHom { x => AMap.mapValues(x)(v => v.t1 + v.t2) }
    //
    //    def -(that: engine.Leet[N, AMap[K, AInteger]]): engine.Leet[N, AMap[K, AInteger]] = l + that.neg()

    //    def toDouble: engine.Leet[N, AMap[K, ADouble]] = l.tmapIxHomValues { x => x.toInt.toDouble }
  }


  implicit class MapsOfBagsWithDoubleProvide[N: CT, K: CT](@transient l: engine.Leet[N, AMap[K, ABag[Double]]]) extends Serializable {
    //
    //    def sum(): engine.Leet[N, AMap[K, ADouble]] = engine.tmapIxHomValues(l)(v => v.sum)
    //
    //
    //    def pow(exp: Double): engine.Leet[N, AMap[K, ABag[Double]]] = l.tmapIxValues { abag => abag.map(x => Math.pow(x, exp)) }

    //
    //    def neg(): engine.Leet[N, AMap[K, ABag[Double]]] = l.tmapIxValues { abag => ABag.map(abag)(x => -x) }
    //
    //    def *(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ABag[Double]]] =
    //      join(l, that).tmapIxValues { case ATuple(abag, y) => abag.map(x => x * y.toDouble) }

    //
    //    // Not sure if this is hom.
    //    def +(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ABag[Double]]] =
    //      join(l, that).tmapIxValues { case ATuple(abag, y) => ABag.map(abag)(x => x + y) }
    //
    //    def -(that: engine.Leet[N, AMap[K, ADouble]]): engine.Leet[N, AMap[K, ABag[Double]]] = l + that.neg()
    //
    //    def count(): engine.Leet[N, AMap[K, AInteger]] = engine.tmapIxHomValues(l)(v => ABag.count(v))
    //
    //    def mean(): engine.Leet[N, AMap[K, ADouble]] = l.sum() / l.count().toDouble
    //
    //    def variance(): engine.Leet[N, AMap[K, ADouble]] = (l - l.mean()).pow(2).sum() / l.count().toDouble
    //
    //    def std(): engine.Leet[N, AMap[K, ADouble]] = l.variance().pow(1.0 / 2.0)
  }


  implicit class PairOfBagsWithIntegerProvide[N: CT, K: CT](@transient l: engine.PairLeet[N, K, ABag[Int]]) extends Serializable {
    def sum(): engine.PairLeet[N, K, AInteger] = engine.tmapHomIx(l) { case (k, v) => amap(k, AInteger(v.sum)) }
  }


  implicit class PairOfBagsWithDoubleProvide[N: CT, K: CT](@transient l: engine.PairLeet[N, K, ABag[Double]]) extends Serializable {
    def sum(): engine.PairLeet[N, K, ADouble] = engine.tmapHomIx(l) { case (k, v) => amap(k, ADouble.toADouble(v.sum)) }
  }

  implicit class MapsOfBagsWithIntegerProvide[N: CT, K: CT](@transient l: engine.Leet[N, AMap[K, ABag[Int]]]) extends Serializable {
    //
    //    def sum(): engine.Leet[N, AMap[K, AInteger]] = engine.tmapIxHomValues(l)(v => v.sum)

    //    def neg(): engine.Leet[N, AMap[K, ABag[Int]]] = l.tmapIxValues { abag => ABag.map(abag)(x => -x) }
    //
    //    def *(that: engine.Leet[N, AMap[K, AInteger]]): engine.Leet[N, AMap[K, ABag[AInteger]]] =
    //      join(l, that).tmapIxValues { case ATuple(abag, y) => ABag.map(abag)(x => x * y) }
    //
    //    // Not sure if this is hom.
    //    def +(that: engine.Leet[N, AMap[K, AInteger]]): engine.Leet[N, AMap[K, ABag[AInteger]]] =
    //      join(l, that).tmapIxValues { case ATuple(abag, y) => ABag.map(abag)(x => x + y) }
    //
    //    def -(that: engine.Leet[N, AMap[K, AInteger]]): engine.Leet[N, AMap[K, ABag[AInteger]]] = l + that.neg()
    //
    //    def count(): engine.Leet[N, AMap[K, AInteger]] = engine.tmapIxHomValues(l)(v => ABag.count(v))

  }

}
