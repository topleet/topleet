package org.unknown1337.topleet.libs

import java.io.File

import com.google.common.base.Charsets
import com.google.common.io.Files
import org.apache.commons.lang.StringEscapeUtils
import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes.AType
import org.unknown1337.topleet.engines.Engine

import scala.reflect.{ClassTag => CT}

trait Viewers {

  val engine: Engine

  implicit class ViewersProvide[N: CT, V <: AType : CT](@transient l: engine.Leet[N, V]) extends Serializable {
    def runGraph(contract: Boolean = true, file: File = new File("temp/tempview.html"), edgeLabel: Boolean = true, horizontal: Boolean = false): Unit = {

      val (lcontrated, mapping) = if (contract) engine.contractZero(l) else (l, engine.nodes(l).map(x => (x, x)).toMap)

      lcontrated.runGraph(mapping, file, true, edgeLabel, horizontal)
    }

    // TODO: Add all kinds of configurations like path, orientation, ...
    def runGraph(mapping: Map[N, N], file: File, open: Boolean, edgeLabel: Boolean, horizontal: Boolean): Unit = {
      def attributes(x: Map[String, String]) = "[" + x.map { case (k, v) => k + "=\"" + StringEscapeUtils.escapeJavaScript(v) + "\"" }.reduceOption(_ + ", " + _).getOrElse("") + "]"

      val imapping = mapping.toSeq.groupBy(_._2).mapValues(_.map(_._1))

      val bypass = engine.bypassEdges(l).toSet

      val es = engine.edges(l).zipWithIndex
      val ns = engine.nodes(l).toSeq.zipWithIndex.toMap
      val absolute = engine.values(l).toMap
      val relative = engine.relativeValues(l).toMap

      def label(x: AType) = x.pretty()

      val edgesDot = es.map { case ((n1, n2), id) => "nd" + ns(n1) + " -> " + "nd" + ns(n2) + attributes(Map("id" -> ("e" + id)) ++ Map("label" -> (if (edgeLabel) label(relative(n1, n2)) else ""))) + ";" }.reduce(_ + " " + _)
      val vertexDot = ns.map { case (n, id) => "nd" + id + attributes(Map("id" -> ("n" + id)) ++ Map("label" -> label(absolute(n)), "shape" -> (if (label(absolute(n)).contains("\n")) "box" else "ellipse"))) + ";" }.reduce(_ + " " + _)

      def kv(key: String, value: String): String = "\"" + key + "\":\"" + value + "\""

      val json = (es.map { case ((sha1, sha2), eid) =>
        val annotations = "{" + kv("bypass", bypass((sha1, sha2)).toString) + "}"
        val hover = ""
        "\"" + "e" + eid + "\":{\"hover\":[" + hover + "],\"svg\":" + annotations + "}"
      } ++ ns.map { case (nodeSha, nid) =>
        val annotations = "{" + "}"

        val hover = ""
        "\"" + "n" + nid + "\":{\"hover\":[" + hover + "],\"svg\":" + annotations + "}"
      }).reduceOption(_ + "," + _).getOrElse("")

      val options = if (horizontal) "rankdir=\"LR\";" else ""

      val templete = Files.asCharSource(new File("core/src/main/resources/viewer/viewer2.html"), Charsets.UTF_8).read()
      val instance = templete
        .replace("digraph R {}", "digraph R {" + StringEscapeUtils.escapeJavaScript(options + vertexDot + edgesDot).replace("\\\\r\\\\n", "\\\\l") + "}")
        .replace("jsondata = {}", "jsondata = {" + json + "}")

      Files.createParentDirs(file)
      Files.asCharSink(file, Charsets.UTF_8).write(instance)

      if (open) Runtime.getRuntime.exec("rundll32 url.dll,FileProtocolHandler " + new File("temp/tempview.html").getAbsolutePath)
    }
  }

}
