//package org.unknown1337.topleet.engines
//
//import org.apache.spark.{Partitioner, SparkContext}
//import org.apache.spark.rdd.RDD
//import org.unknown1337.topleet.Group
//import org.unknown1337.topleet.atypes.{ADouble, AMap, ATuple, AType}
//import org.unknown1337.topleet.utils.{EdgeUtils, Utils}
//
//import scala.reflect.{ClassTag => CT}
//
//abstract class DistributedEngine(@transient spark: SparkContext, partitionSize: Int, engine: Engine) extends BaseEngine {
//
//  private def partitioner[N](npartitions: Int): Partitioner = new Partitioner {
//    override def numPartitions: Int = npartitions
//
//    override def getPartition(key: Any): Int = key match {
//      case i: Int => i
//      case (i: Int, _) => i
//      case ((i1: Int, _: N), (i2: Int, _: N)) => Math.min(i1, i2)
//    }
//  }
//
//  case class PartialLeet[N, V <: AType](l: engine.Leet[(Int, N), V])
//
//  // TODO: Maybe make nodes and edges local again (or remove and use leets as this is duplication of content).
//  case class DistributedEngineLeet[N, V <: AType](partitions: Int,
//                                                  nodes: RDD[(Int, N)],
//                                                  edges: RDD[((Int, N), (Int, N))],
//                                                  leets: RDD[(Int, PartialLeet[N, V])],
//                                                  abelian: Group[V])
//
//  override type Leet[N, V <: AType] = DistributedEngineLeet[N, V]
//
//  override def close(): Unit = {
//    spark.stop()
//  }
//
//  // TODO: Centering distribution around THIS OPERATION. Anyway, keys can also be translated into an partition index (using nmap) and
//  // TODO: thereby this solves almost all problems (linearize, contaction and ixAcDelta. I think redundant partitioning is needed.
//  private def redistribute[N: CT, V <: AType : CT](locations: Map[N, Int], l: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] = {
//    // Creating sub-graphs of the current partial leets according to locations and redistribute those.
//    val leets = l.leets.flatMap { case (i, PartialLeet(ll)) =>
//      val current = engine.nmap(ll) { case (_, n) => (locations(n), n) }
//      for ((partition, nodes) <- engine.nodes(current).groupBy(_._1)) yield {
//        // TODO: Somehow the edges need to be appended to this. But this must only be done for the min.
//        val dangling = engine.edges(current).collect { case (n1, n2) if nodes(n1) || nodes(n2) => Seq(n1, n2) }.flatten
//        (partition, PartialLeet(engine.subgraph(current, nodes ++ dangling)))
//      }
//    }.reduceByKey { case (PartialLeet(x), PartialLeet(y)) => PartialLeet(engine.append(x, y)) }
//
//    val newNodes = l.nodes.map { case (_, n) => (locations(n), n) }
//    val newEdges = l.edges.map { case ((_, n1), (_, n2)) => ((locations(n1), n1), (locations(n2), n2)) }
//
//    DistributedEngineLeet(locations.values.max + 1, newNodes, newEdges, leets, l.abelian)
//  }
//
//  private def createFromRDDs[N: CT, V <: AType : CT](partitions: Int, vAbelian: Group[V], ixEdges: RDD[((Int, N), (Int, N))], ixVertices: RDD[((Int, N), V)]) = {
//    // Distribute.
//    val indexedEdgesWithNull = ixEdges.map { ns => (ns, null) }
//    val distributedEdges = EdgeUtils.triplets(indexedEdgesWithNull, ixVertices, partitioner(partitions)).map {
//      case ((n1, n2), (Some(v1), _, Some(v2))) => ((n1, n2), (v1, v2))
//    }.partitionBy(partitioner(partitions))
//    val distributedNodes = ixVertices.partitionBy(partitioner(partitions))
//
//    val leets = distributedNodes.zipPartitions(distributedEdges) { case (iteratorNodes, iteratorEdges) =>
//      val rawNodes = iteratorNodes.toMap
//      // Edges with value value payload.
//      val esVV = iteratorEdges.toMap
//      // Nodes of this partition.
//      val ns = rawNodes ++ esVV.flatMap { case ((n1, n2), (v1, v2)) => Seq((n1, v1), (n2, v2)) }
//      // Edges of this partition.
//      val es = esVV.keySet
//      val index = rawNodes.keySet.map(_._1)
//      assert(index.size == 1)
//
//      implicit val abl: Group[V] = vAbelian
//      Seq((index.head, PartialLeet(engine.create(es, ns)))).toIterator
//    }.partitionBy(partitioner(partitions))
//
//    DistributedEngineLeet(partitions, ixVertices.keys, ixEdges, leets, vAbelian)
//  }
//
//  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): DistributedEngineLeet[N, V] = {
//    // Partition index to a node.
//    val index = Utils.ts(edges, nodes.keySet)
//      .grouped(Math.min((nodes.size / 16) + 1, partitionSize))
//      .zipWithIndex
//      .flatMap { case (seq, idx) => seq.map(x => (x, idx)) }
//      .toMap
//
//    val partitions = index.values.max + 1
//
//    // Create the indexed nodes and edges.
//    val ixEdges = spark.parallelize(edges.map { case (n1, n2) => ((index(n1), n1), (index(n2), n2)) }.toSeq)
//    val ixVertices = spark.parallelize(nodes.map { case (n, v) => ((index(n), n), v) }.toSeq)
//
//    createFromRDDs(partitions, vAbelian, ixEdges, ixVertices)
//  }
//
//  private def mapPartitionOperation[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DistributedEngineLeet[N, V1])(f: engine.Leet[(Int, N), V1] => engine.Leet[(Int, N), V2])(abl: Group[V2]): DistributedEngineLeet[N, V2] = {
//    val leets = l.leets.mapPartitions({ p => p.map { case (index, PartialLeet(x)) => (index, PartialLeet(f(x))) } }, preservesPartitioning = true)
//
//    DistributedEngineLeet(l.partitions, l.nodes, l.edges, leets, abl)
//  }
//
//  private def zipPartitionOperation[N: CT, V1 <: AType : CT, V2 <: AType : CT, V3 <: AType : CT](l1: DistributedEngineLeet[N, V1], l2: DistributedEngineLeet[N, V2])(f: (engine.Leet[(Int, N), V1], engine.Leet[(Int, N), V2]) => engine.Leet[(Int, N), V3])(abl: Group[V3]): DistributedEngineLeet[N, V3] = {
//    val ll1 = l1.leets.partitionBy(partitioner(l1.partitions))
//    val ll2 = l2.leets.partitionBy(partitioner(l1.partitions))
//    val leets = ll1.zipPartitions(ll2) { case (iterator1, iterator2) =>
//      val (ix1, l1) :: Nil = iterator1.toList
//      val (ix2, l2) :: Nil = iterator2.toList
//      assert(ix1 == ix2)
//
//      Seq((ix1, PartialLeet(f(l1.l, l2.l)))).toIterator
//    }
//
//    DistributedEngineLeet(l1.partitions, l1.nodes, l1.edges, leets, abl)
//  }
//
//  override def merge[N: CT, V <: AType : CT](l1: DistributedEngineLeet[N, V], l2: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] =
//    zipPartitionOperation(l1, l2) { case (x, y) => engine.merge(x, y) }(l1.abelian)
//
//  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: DistributedEngineLeet[N, V1], l2: DistributedEngineLeet[N, V2]): DistributedEngineLeet[N, ATuple[V1, V2]] =
//    zipPartitionOperation(l1, l2) { case (x, y) => engine.product(x, y) }(ATuple.aTupleGroup(l1.abelian, l2.abelian))
//
//  override def zero[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] =
//    mapPartitionOperation(l)(engine.zero(_))(l.abelian)
//
//  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DistributedEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DistributedEngineLeet[N, V2] =
//    mapPartitionOperation(l)(x => engine.tmap(x)(f))(v2Abelian)
//
//  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DistributedEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DistributedEngineLeet[N, V2] =
//    mapPartitionOperation(l)(x => engine.tmapHom(x)(f))(v2Abelian)
//
//  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: DistributedEngineLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): DistributedEngineLeet[N, V2] =
//    mapPartitionOperation(l)(x => engine.tmapIx(x)(f))(v2Abelian)
//
//  override def tmapIxHomValues[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: DistributedEngineLeet[N, AMap[K, V1]])(f: V1 => V2)(implicit v2Abelian: Group[V2]): DistributedEngineLeet[N, AMap[K, V2]] =
//    mapPartitionOperation(l)(x => engine.tmapIxHomValues(x)(f))(AMap.aMapGroup(v2Abelian))
//
//  override def edges[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): Set[(N, N)] =
//    l.edges.map { case ((_, n1), (_, n2)) => (n1, n2) }.collect().toSet
//
//  override def zeroEdges[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): Set[(N, N)] =
//    l.leets.flatMap { case (_, PartialLeet(x)) => engine.zeroEdges(x).map { case ((_, n1), (_, n2)) => (n1, n2) } }.collect().toSet
//
//  override def values[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] =
//    l.leets.flatMap { case (i, PartialLeet(x)) => engine.values(x).collect { case ((ii, n), v) if ii == i => (n, v) } }.toLocalIterator
//
//  override def relativeValues[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): Iterator[((N, N), V)] =
//    l.leets.flatMap { case (_, PartialLeet(x)) => engine.relativeValues(x).map { case (((_, n1), (_, n2)), v) => ((n1, n2), v) } }.toLocalIterator
//
//  override def contract[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V], mapping: Map[N, N]): DistributedEngineLeet[N, V] = {
////    // Pulling all 'from' nodes into the 'to' partition.
////    val ns= l.nodes.collect().toSet
////    // Edges that are somehow affected by a contraction.
////    val affected = l.edges.collect().filter{case ((_,n1),(_,n2)) => mapping(n1) != n1 || mapping(n2)!= n2}.toSet
////    val partitions = Utils.ccs(affected,ns)
////
////    val newLocations = mapping.map { case (from, to) => (from, location(to)) }
////    val redistributed = redistribute(newLocations, l)
////    val ixMapping = mapping.map { case (f, t) => ((newLocations(f), f), (newLocations(t), t)) }
////    val temp = mapPartitionOperation(redistributed) { x =>
////      val ns = engine.nodes(x)
////      engine.contract(x, ixMapping.filter { case (from, _) =>  ns(from) })
////    }(l.abelian)
////    val newNodesFilter = mapping.values.toSet
////    // TODO: I don't like this.
////    val newNodes = redistributed.nodes.filter { case (_, n) => newNodesFilter(n) }
////    val newEdges = redistributed.edges.filter { case ((_, n1), (_, n2)) => mapping(n1) != mapping(n2) }
////      .map { case ((i1, n1), (i2, n2)) => ((i1, mapping(n1)), (i2, mapping(n2))) }
////      .distinct()
////
////    DistributedEngineLeet(temp.partitions, newNodes, newEdges, temp.leets, redistributed.abelian)
//    ???
//  }
//
//  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: DistributedEngineLeet[N, V1], to: DistributedEngineLeet[N, V2], mapping: Map[N, N]): DistributedEngineLeet[N, V1] = {
//    ???
//  }
//
//  // TODO: Bring back to efficient reduce.
//  override def reduce[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V])(f: (V, V) => V): V =
//    l.leets.map { case (i, PartialLeet(x)) => engine.values(x).collect { case ((ii, n), v) if ii == i => v }.reduce(f) }.reduce(f)
//
//
//  override def delta[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] = {
//    val vAbelian: Group[V] = l.abelian
//    val relative = l.leets.flatMap { case (_, PartialLeet(x)) => engine.relativeValues(x) }
//    // Incoming delta and zero for every nodes also fix the initials.
//    val in = relative.map { case ((_, n2), v) => (n2, v) }
//    val zero = l.nodes.map(n => (n, vAbelian.zero))
//
//    val delta = (in ++ zero).reduceByKey(vAbelian.merge)
//
//    createFromRDDs(l.partitions, vAbelian, l.edges, delta)
//  }
//
//  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: DistributedEngineLeet[N, AMap[K, V]]): DistributedEngineLeet[N, AMap[K, V]] = {
//    //    val partitionedByKey = l.leet.flatMap { case (index, ll) => engine.relativeValues(ll).toSeq.flatMap { case ((n1, n2), vs) => vs.value.toSeq.map { case (k, v) => (k, (index, (n1, n2), v)) } } }
//    //      .partitionBy(l.leet.partitioner.get)
//    //
//    //    val edges = l.edges
//    //    partitionedByKey.glom().map{ array =>
//    //      //engine.create(edges,)
//    //      // TODO: Here we have a problem!
//    //      ???
//    //    }
//    // Bring distribution back on graph.
//
//    ???
//  }
//
//  override def nodes[N: CT, T <: AType : CT](l: DistributedEngineLeet[N, T]): Set[N] =
//    l.nodes.values.collect().toSet
//
//  override def abelian[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): Group[V] =
//    l.abelian
//
//  override def subgraph[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): DistributedEngineLeet[N, V] =
//    ???
//
//  override def append[N: CT, V <: AType : CT](l1: DistributedEngineLeet[N, V], l2: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] =
//    ???
//
//  override def reverse[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] = {
//    DistributedEngineLeet(l.partitions, l.nodes, l.edges.map(_.swap), mapPartitionOperation(l)(x => engine.reverse(x))(l.abelian).leets, l.abelian)
//  }
//
//  override def force[N: CT, V <: AType : CT](l: DistributedEngineLeet[N, V]): DistributedEngineLeet[N, V] =
//    mapPartitionOperation(l)(x => engine.force(x))(l.abelian)
//
//  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: DistributedEngineLeet[N1, V])(f: N1 => N2): DistributedEngineLeet[N2, V] =
//    ???
//
//  override def authorshipIx[N: CT, K: CT](l: DistributedEngineLeet[N, AMap[K, ADouble]]): DistributedEngineLeet[N, AMap[(N, K), ADouble]] = ???
//}
//
