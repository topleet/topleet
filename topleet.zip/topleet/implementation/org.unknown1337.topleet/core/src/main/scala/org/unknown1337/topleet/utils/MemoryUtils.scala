package org.unknown1337.topleet.utils

import java.lang.management.ManagementFactory

object MemoryUtils {


  def getCurrentlyUsedMemory: Long =
    ManagementFactory.getMemoryMXBean.getHeapMemoryUsage.getUsed +
      ManagementFactory.getMemoryMXBean.getNonHeapMemoryUsage.getUsed

  /**
    * @return in bytes
    */
  def getPossiblyReallyUsedMemory: Long = {
    System.gc()
    getCurrentlyUsedMemory
  }

  def getGcCount: Long = {
    var sum = 0l
    import scala.collection.JavaConversions._
    for (b <- ManagementFactory.getGarbageCollectorMXBeans) {
      val count = b.getCollectionCount
      if (count != -1) sum = sum + count
    }
    sum
  }

  def getReallyUsedMemory: Long = {
    val before = getGcCount
    System.gc()
    while ( {
      getGcCount == before
    }) {}
    getCurrentlyUsedMemory
  }

}
