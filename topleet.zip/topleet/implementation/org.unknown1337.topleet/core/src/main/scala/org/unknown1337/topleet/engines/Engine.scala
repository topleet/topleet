package org.unknown1337.topleet.engines

import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes._

import scala.reflect.{classTag, ClassTag => CT}

import org.unknown1337.topleet.atypes.{AMap, _}
import AMap._

import org.unknown1337.topleet.utils.Utils

trait Engine {

  type Leet[N, T <: AType]

  type PairLeet[N, K, V <: AType] // = Leet[N, AMap[K, V]]

  implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: PairLeet[N, K, V]): Leet[N, AMap[K, V]]

  implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: Leet[N, AMap[K, V]]): PairLeet[N, K, V]

  def close(): Unit = {}

  def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): Leet[N, V]

  def createIx[N: CT, K: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, AMap[K, V]])(implicit vAbelian: Group[V]): PairLeet[N, K, V]

  def subgraph[N: CT, V <: AType : CT](l: Leet[N, V], edges: Set[(N, N)], nodes: Set[N]): Leet[N, V]

  def subgraph[N: CT, V <: AType : CT](l: Leet[N, V], nodes: Set[N]): Leet[N, V]


  def reverse[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V]

  def append[N: CT, V <: AType : CT](l1: Leet[N, V], l2: Leet[N, V]): Leet[N, V]

  def merge[N: CT, V <: AType : CT](l1: Leet[N, V], l2: Leet[N, V]): Leet[N, V]

  def mergeIx[N: CT, K: CT, V <: AType : CT](l1: PairLeet[N, K, V], l2: PairLeet[N, K, V]): PairLeet[N, K, V]

  def zero[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V]

  /**
    * This is the inner product.
    */
  def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: Leet[N, V1], l2: Leet[N, V2]): Leet[N, ATuple[V1, V2]]

  /**
    * This is the inner product.
    */
  def productIx[N: CT, K1: CT, V1 <: AType : CT, K2: CT, V2 <: AType : CT](l1: PairLeet[N, K1, V1], l2: PairLeet[N, K2, V2]): PairLeet[N, (K1, K2), ATuple[V1, V2]]

  def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: Leet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): Leet[N, V2]

  def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: Leet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): Leet[N, V2]

  def tmapIx[N: CT, K: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K, V1])(f: (K, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PairLeet[N, K2, V2]

  def tmapHomIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PairLeet[N, K2, V2]

  def tmapHomLinIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PairLeet[N, K2, V2]

  def tmapDynamic[N: CT, K1: CT, K2: CT, V1 <: AType : CT](l: PairLeet[N, K1, V1])(f: K1 => K2): PairLeet[N, K2, V1]

  // TODO: Remove from interface.
  //  def tmapIxHomValues[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: PairLeet[N, K, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): PairLeet[N, K, V2]

  def edges[N: CT, V <: AType : CT](l: Leet[N, V]): Set[(N, N)]

  def edgesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Set[(N, N)]

  def zeroEdges[N: CT, V <: AType : CT](l: Leet[N, V]): Set[(N, N)]

  def zeroEdgesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Set[(N, N)]

  def values[N: CT, V <: AType : CT](l: Leet[N, V]): Iterator[(N, V)]

  def valuesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V], on: Set[N]): Iterator[(N, K, V)]

  def valuesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Iterator[(N, K, V)]

  def values[N: CT, V <: AType : CT](l: Leet[N, V], on: Set[N]): Iterator[(N, V)]

  def relativeValues[N: CT, V <: AType : CT](l: Leet[N, V]): Iterator[((N, N), V)]

  def relativeValuesIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Iterator[((N, N), (K, V))]

  def nmap[N1: CT, N2: CT, V <: AType : CT](l: Leet[N1, V])(f: N1 => N2): Leet[N2, V]

  def contract[N: CT, V <: AType : CT](l: Leet[N, V], mapping: Map[N, N]): Leet[N, V]

  def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: Leet[N, V1], to: Leet[N, V2], mapping: Map[N, N]): Leet[N, V1]

  def reduce[N: CT, V <: AType : CT](l: Leet[N, V])(f: (V, V) => V): V

  def acDelta[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V]

  def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): PairLeet[N, K, V]

  def keys[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Set[K]

  def size[N: CT, V <: AType : CT](l: Leet[N, V]): Int

  def sizeIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Int

  def branches[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, ABag[N]]

  //def collectLinearize[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, ABag[V]]

  //  def firstParentLinearize[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, V]
  //
  //  def absLinearize[N: CT, V <: AType : CT](l: Leet[N, V], line: Seq[N]): Leet[N, V]

  def acLinearize[N1: CT, V <: AType : CT](l: Leet[N1, V], line: Seq[N1]): Leet[N1, V]

  def acLinearizeIx[N1: CT, K: CT, V <: AType : CT](l: PairLeet[N1, K, V], line: Seq[N1]): PairLeet[N1, K, V]

  def authorship[N: CT](l: Leet[N, ADouble]): Leet[N, AMap[N, ADouble]]

  def authorshipIx[N: CT, K: CT](l: PairLeet[N, K, ADouble]): PairLeet[N, (N, K), ADouble]

  def force[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V]

  def forceIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): PairLeet[N, K, V]

  //  def delta[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V]

  def collectDeltas[N: CT, V <: AType : CT](l: Leet[N, V], merges: Boolean = true): PairLeet[N, N, V]

  def collectDeltasIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V], merges: Boolean = true): PairLeet[N, (N, K), V]

  def incoming[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Set[N]]

  def incomingIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Map[N, Set[N]]

  def outgoing[N: CT, T <: AType : CT](l: Leet[N, T]): Map[N, Set[N]]

  def outgoingIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Map[N, Set[N]]

  def nodes[N: CT, T <: AType : CT](l: Leet[N, T]): Set[N]

  def nodesIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Set[N]

  def roots[N: CT, T <: AType : CT](l: Leet[N, T]): Set[N]

  def rootsIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Set[N]

  def leafs[N: CT, T <: AType : CT](l: Leet[N, T]): Set[N]

  def leafsIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Set[N]

  def ts[N: CT, T <: AType : CT](l: Leet[N, T]): Iterator[N]

  def tsIx[N: CT, K: CT, T <: AType : CT](l: PairLeet[N, K, T]): Iterator[N]

  def abelian[N: CT, V <: AType : CT](l: Leet[N, V]): Group[V]

  def abelianIx[N: CT, K: CT, V <: AType : CT](l: PairLeet[N, K, V]): Group[AMap[K, V]]

  def maskBypassEdges[N: CT, V <: AType : CT](l: Leet[N, V]): Leet[N, V]

  def bypassEdges[N: CT, V <: AType : CT](l: Leet[N, V]): Iterator[(N, N)]

  def contractEdges[N: CT, V <: AType : CT](l: Leet[N, V], target: Set[(N, N)]): (Leet[N, V], Map[N, N])

  def contractZero[N: CT, V <: AType : CT](l: Leet[N, V]): (Leet[N, V], Map[N, N])

  //
  //  def create[N: CT, V <: AType : CT](edges: Set[(N, N)], values: Map[N, V])(implicit vAbelian: Group[V]): Engine.this.Leet[N, V] =
  //    Engine.this.create(edges, values)
  //
  //  def product[N: CT, T1 <: AType : CT, T2 <: AType : CT](l1: Engine.this.Leet[N, T1], l2: Engine.this.Leet[N, T2]): Engine.this.Leet[N, ATuple[T1, T2]] =
  //    Engine.this.product(l1, l2)

  // TODO: Add right and left outer and others.
  def join2[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l1: Engine.this.PairLeet[N, K, V1], l2: Engine.this.PairLeet[N, K, V2]): Engine.this.PairLeet[N, K, ATuple[V1, V2]] = {
    implicit val v1Abelian: Group[V1] = Engine.this.abelianIx(l1).asInstanceOf[AbelianAMap[K, V1]].vAbelian
    implicit val v2Abelian: Group[V2] = Engine.this.abelianIx(l2).asInstanceOf[AbelianAMap[K, V2]].vAbelian
    implicit val tupleGroup: Group[ATuple[V1, V2]] = ATuple.aTupleGroup(v1Abelian, v2Abelian)
    implicit val mapGroup: Group[AMap[K, ATuple[V1, V2]]] = AMap.aMapGroup(tupleGroup)

    Engine.this.mergeIx(l1.tmapHomIx { case (k, v) => amap(k, ATuple(v, v2Abelian.zero)) }, l2.tmapHomIx { case (k, v) => amap(k, ATuple(v1Abelian.zero, v)) })
  }

  def join[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l1: Engine.this.PairLeet[N, K, ABag[V1]], l2: Engine.this.PairLeet[N, K, ABag[V2]]): Engine.this.PairLeet[N, K, ABag[(V1, V2)]] = {
//    join2(l1,l2).tmapIx{ case (k,ATuple(l,r))=> ???
//
//    }
   ???
  }

  def cartesianIx[N: CT, V1: CT, V2: CT](l1: Engine.this.PairLeet[N, V1, AInteger], l2: Engine.this.PairLeet[N, V2, AInteger]): Engine.this.PairLeet[N, (V1, V2), AInteger] =
    Engine.this.productIx(l1, l2).tmapIx { case (k, ATuple(c1, c2)) => amap(k, AInteger.toAInterger(c1.toInt * c2.toInt)) }


  implicit class BaseProvide[N: CT, V <: AType : CT](@transient l: Engine.this.Leet[N, V]) extends Serializable {

    implicit lazy val vabelian: Group[V] = Engine.this.abelian(l)

    def neg(): Engine.this.Leet[N, V] = l.tmapHom { x => vabelian.inverse(x) }(classTag[V], Engine.this.abelian(l))

    def +(that: Engine.this.Leet[N, V]): Engine.this.Leet[N, V] = product(l, that).tmapHom { case ATuple(x, y) => vabelian.merge(x, y) }(classTag[V], Engine.this.abelian(l))

    def tmap[V2 <: AType : CT](f: V => V2)(implicit abelV2: Group[V2]): Engine.this.Leet[N, V2] = Engine.this.tmap(l)(f)

    def tmapHom[V2 <: AType : CT](f: V => V2)(implicit abelV2: Group[V2]): Engine.this.Leet[N, V2] = Engine.this.tmapHom(l)(f)

    def viewValues(): Iterator[(N, V)] = Engine.this.values(l)

    def force(): Engine.this.Leet[N, V] = Engine.this.force(l)

    def reduce(f: (V, V) => V): V = Engine.this.reduce(l)(f)

    def reverse(): Engine.this.Leet[N, V] = Engine.this.reverse(l)

    //    def delta(): Engine.this.Leet[N, V] = {
    //      import Engine.this.leet2PairLeet
    //      import Engine.this.pairLeet2Leet
    //
    //      val delta = Engine.this.collectDeltas(l)
    //
    //      delta.tmapIx{case (k,v)=> v}
    //    }


    def topology(): Engine.this.PairLeet[N, N, AInteger] = Engine.this.createIx(Engine.this.edges(l), Engine.this.nodes(l).map(n => (n, abl(n))).toMap)

    def reduceAbl(): V = {
      val abl = Engine.this.abelian(l)
      Engine.this.reduce(l)(abl.merge)
    }

    def ccs(): Iterator[Engine.this.Leet[N, V]] = {
      val edges = Engine.this.edges(l)
      val nodes = Engine.this.nodes(l)
      val ccs = Utils.groupByValue(Utils.ccs2(edges, nodes).toSeq)
      if (ccs.size == 1)
        Seq(l).toIterator
      else
        ccs.toIterator.map { case (_, ccNodes) =>
          Engine.this.subgraph(l, ccNodes.toSet)
        }
    }
  }

  //  implicit def leet2PairsProvide[N: CT, K: CT, V <: AType : CT](leet: Engine.this.Leet[N, AMap[K, V]]): PairLeetProvides[N, K, V] =
  //    PairLeetProvides(Engine.this.leet2PairLeet(leet))

  implicit class PairLeetProvides[N: CT, K: CT, V <: AType : CT](@transient l: Engine.this.PairLeet[N, K, V]) extends Serializable {

    lazy implicit val vAbelian: Group[V] = Engine.this.abelianIx(l).asInstanceOf[AbelianAMap[K, V]].vAbelian

    def filter(f: K => Boolean): Engine.this.PairLeet[N, K, V] =
      Engine.this.tmapHomLinIx(l) { case (k, v) => if (f(k)) amap(Map(k -> v)) else AMap.zero() }

    def dmap[K2: CT](f: K => K2): Engine.this.PairLeet[N, K2, V] = {
      implicit val outAbelian: Group[AMap[K2, V]] = AMap.aMapGroup[K2, V](vAbelian)

      Engine.this.tmapDynamic(l)(f)
    }

    def map[K2: CT](f: K => K2): Engine.this.PairLeet[N, K2, V] = {
      implicit val outAbelian: Group[AMap[K2, V]] = AMap.aMapGroup[K2, V](vAbelian)

      Engine.this.tmapHomIx(l) { case (k, v) => amap(Map(f(k) -> v)) }
    }

    def lmap[K2: CT](f: K => K2): Engine.this.PairLeet[N, K2, V] = {
      implicit val outAbelian: Group[AMap[K2, V]] = AMap.aMapGroup[K2, V](vAbelian)

      Engine.this.tmapHomLinIx(l) { case (k, v) => amap(Map(f(k) -> v)) }
    }

    def tmapHom[K2: CT, V2 <: AType : CT](f: AMap[K, V] => AMap[K2, V2])(implicit v2Abelian: Group[V2]): Engine.this.PairLeet[N, K2, V2] =
      l.map(k => (Unit, k)).group().tmapHomIx { case (_, v) => f(v) }


    def tmap[K2: CT, V2 <: AType : CT](f: AMap[K, V] => AMap[K2, V2])(implicit v2Abelian: Group[V2]): Engine.this.PairLeet[N, K2, V2] =
      l.map(k => (Unit, k)).group().tmapIx { case (_, v) => f(v) }


    def tmapIx[K2: CT, V2 <: AType : CT](f: (K, V) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): Engine.this.PairLeet[N, K2, V2] =
      Engine.this.tmapIx(l)(f)


    def tmapHomIx[K2: CT, V2 <: AType : CT](f: (K, V) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): Engine.this.PairLeet[N, K2, V2] =
      Engine.this.tmapHomIx(l)(f)

    //Engine.this.tmapIxHomValues(l)(f)

    // TODO: We need some rename here.
    //    def values(): Engine.this.Leet[N, V] = {
    //      implicit val vAbelin: Group[V] = Engine.this.abelian(l).asInstanceOf[AbelianAMap[K,V]].vAbelian
    //      l.tmapHom(amap => AMap.map(amap) { case x => x._2 })
    //    }

    def keys(): Set[K] = Engine.this.keys(l)

    def acLinearize(line: Seq[N]): Engine.this.PairLeet[N, K, V] = Engine.this.acLinearizeIx(l, line)

    def acDelta(): Engine.this.PairLeet[N, K, V] = Engine.this.acDeltaIx(l)

    def delta(merges: Boolean = true): Engine.this.PairLeet[N, (N, K), V] = Engine.this.collectDeltasIx(l, merges)

    def values(on: Set[N] = Engine.this.nodesIx(l)): Iterator[(N, K, V)] = Engine.this.valuesIx(l, on)

    def valuesAMap(on: Set[N] = Engine.this.nodesIx(l)): Map[N, AMap[K, V]] = Engine.this.valuesIx(l, on).toSeq.groupBy(_._1)
      .map { case (k, v) => (k, AMap(v.map { case (k, v1, v2) => (v1, v2) }.toMap)) }

    // TODO: Use slice
    //def headOption(): Engine.this.Leet[N, Abl[Option[V]]] = l.tmap(x => Abl(ABag.toSeq(x).headOption))
    // TODO: Sum fold is missing doing counts.

  }

  implicit class PairLeetWithAMapsProvide[N: CT, K1: CT, K2: CT, V <: AType : CT](@transient l: Engine.this.PairLeet[N, K1, AMap[K2, V]]) extends Serializable {
    implicit val vabl = abelianIx(l).asInstanceOf[AbelianAMap[K1, AMap[K2, V]]].vAbelian.asInstanceOf[AbelianAMap[K2, V]].vAbelian

    def ungroup(): Engine.this.PairLeet[N, (K1, K2), V] = l.tmapHomIx { case (k1, v) => v.map(k2 => (k1, k2)) }
  }

  implicit class PairLeetWithTuplesProvide[N: CT, K1: CT, K2: CT, V <: AType : CT](@transient l: Engine.this.PairLeet[N, (K1, K2), V]) extends Serializable {

    def group(): Engine.this.PairLeet[N, K1, AMap[K2, V]] = {
      implicit val vAbelian: Group[V] = Engine.this.abelianIx(l).asInstanceOf[AbelianAMap[(K1, K2), V]].vAbelian
      implicit val intemediate = AMap.aMapGroup[K2, V](vAbelian)
      implicit val outMap: Group[AMap[K1, AMap[K2, V]]] = AMap.aMapGroup[K1, AMap[K2, V]](intemediate)

      //Engine.this.tmapHomIx(l) { x => AMap(x.value.groupBy(_._1._1).map { case (k, v) => (k, AMap(v).map(_._2)) }) }

      Engine.this.tmapHomLinIx(l) { case ((k1, k2), v) => amap(k1, amap(k2, v)) }
    }
  }

  //
  //  implicit class MapsOfValueTuplesProvide[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](@transient l: Engine.this.Leet[N, AMap[K, ATuple[V1, V2]]]) extends Serializable {
  //    // This seems to be not hom.
  //    def groupValues(): AMap[AMap[K, V1], V2] = ??? //Engine.this.tmapIx(l){case (k,ATuple(l,r)) =>  }
  //  }
  //
  //  implicit class MapsOfValueMapsProvide[N: CT, K1: CT, K2: CT, V <: AType : CT](@transient l: Engine.this.Leet[N, AMap[K1, AMap[K2, V]]]) extends Serializable {
  //    lazy implicit val vAbelian: Group[V] = Engine.this.abelian(l).asInstanceOf[AbelianAMap[K1, AMap[K2, V]]].vAbelian.asInstanceOf[AbelianAMap[K2, V]].vAbelian
  //
  //    def ungroupValues(): Engine.this.Leet[N, AMap[(K1, K2), V]] =
  //      l.tmapHom { x => x.mapValues { case (k1, v) => v.map(k2 => (k1, k2)) } }
  //  }
  //
  //  implicit class MapsOfKeyMapsProvide[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](@transient l: Engine.this.Leet[N, AMap[AMap[K, V1], V2]]) extends Serializable {
  //    // TODO: No need for implicit. Wrong. Must flatten Bags of bags
  //    def ungroup(implicit ablv1: Group[V1], ablv2: Group[V2]): Engine.this.Leet[N, AMap[K, ATuple[V1, V2]]] = ???
  //
  //    //l.tmapIx { x => x.mapValues { case (km, v2) => km.mapValues { case (k, v1) => AMap.create(k, ATuple(v1, v2)) } } }
  //  }


  implicit def leet2BagsPairsProvide[N: CT, V <: AType : CT](leet: Engine.this.Leet[N, ABag[V]]): BagsPairsProvide[N, V] =
    BagsPairsProvide(Engine.this.leet2PairLeet(leet))

  implicit class BagsPairsProvide[N: CT, V: CT](@transient l: Engine.this.PairLeet[N, V, AInteger]) extends Serializable {
    def distinct(): Engine.this.PairLeet[N, V, AInteger] =
      ???

    //Engine.this.tmapIx(l) { case (k, AInteger(count)) if count > 0 => AMap.create(k, AInteger(1)) }

    def count(): Engine.this.Leet[N, AInteger] =
      Engine.this.tmapHom(l)(x => x.mapValues({ case (_, v) => v }))
  }

  implicit def leet2BagsPairsOfBagsProvide[N: CT, V <: AType : CT](leet: Engine.this.Leet[N, ABag[ABag[V]]]): BagsPairsOfBagsProvide[N, V] =
    BagsPairsOfBagsProvide(Engine.this.leet2PairLeet(leet))

  implicit class BagsPairsOfBagsProvide[N: CT, V: CT](@transient l: Engine.this.PairLeet[N, ABag[V], AInteger]) extends Serializable {

    def flatten: Engine.this.PairLeet[N, V, AInteger] = Engine.this.tmapHomLinIx(l) { case (k, c1) => amap(k.value.map { case (k2, c2) => k2 -> AInteger(c1.toInt * c2.toInt) }) }

  }

}