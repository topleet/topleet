package org.unknown1337.topleet.engines

import java.io._
import java.nio.charset.Charset
import java.text.SimpleDateFormat
import java.util.Date

import org.unknown1337.topleet.Group
import org.unknown1337.topleet.atypes._
import AMap._
import org.unknown1337.topleet.utils.Utils

import scala.reflect.{ClassTag => CT}


object LogEngine {
  def create(e: Engine, inspection: Boolean = true, file: File, charset: Charset, append: Boolean = false) =
    LogEngine(e, inspection, Some(new OutputStreamWriter(new FileOutputStream(file, append), charset)))
}

// TODO: Print Use a counter to print results step by step.
case class LogEngine(e: Engine, inspection: Boolean = false, appendable: Option[Appendable] = None) extends Engine {

  var i = 0
  var message = ""

  def outnl(x: String): Unit = appendable match {
    case Some(a) =>
      a.append(x + "\n")
      flush()
    case None => println(x)
  }

  def flush(): Unit = {
    appendable match {
      case x: Flushable =>
        x.flush()
      case _ =>
    }
  }

  def log[N: CT, K: CT, V <: AType : CT](operation: String, l: PrintEnginePairLeet[N, K, V]): PrintEnginePairLeet[N, K, V] = {

    val stack = Seq(i.toString + " (Pair) - " + operation + " @ " + new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()) + " --------------------------------------------------------------") ++
      Thread.currentThread().getStackTrace.toSeq.drop(4).map(x => x.toString)

    if (inspection) {
      for (s <- stack) {
        outnl(s)
      }
      val ns = e.nodes(e.pairLeet2Leet(l.wrapped))
      val es = e.edges(e.pairLeet2Leet(l.wrapped))
      val ts = Utils.ts(es, ns)
      val vs = e.valuesIx(l.wrapped).toSeq.groupBy(_._1).map { case (k, v) => (k, AMap(v.map { case (k, v1, v2) => (v1, v2) }.toMap)) }

      outnl("nodes:" + ns.size + " edges:" + es.size + " zeroEdges:" + e.zeroEdges(e.pairLeet2Leet(l.wrapped)).size)
      for (n <- ts.take(4)) outnl(n.toString + " = " + vs(n).toString.take(300) + (if (vs(n).toString.length > 300) "..." else ""))
    } else {

      message = stack.reduce(_ + "\n" + _)
      outnl(message)
    }
    i = i + 1
    l
  }


  def log[N: CT, V <: AType : CT](operation: String, l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] = {

    val stack = Seq(i.toString + " - " + operation + " @ " + new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date()) + " --------------------------------------------------------------") ++
      Thread.currentThread().getStackTrace.toSeq.drop(4).map(x => x.toString)

    if (inspection) {
      for (s <- stack) {
        outnl(s)
      }
      val ns = e.nodes(l.wrapped)
      val es = e.edges(l.wrapped)
      val ts = Utils.ts(es, ns)
      val vs = e.values(l.wrapped).toMap

      outnl("nodes:" + ns.size + " edges:" + es.size + " zeroEdges:" + e.zeroEdges(l.wrapped).size)
      for (n <- ts.take(4)) outnl(n.toString + " = " + vs(n).toString.take(300) + (if (vs(n).toString.length > 300) "..." else ""))
    } else {

      message = stack.reduce(_ + "\n" + _)
      outnl(message)
    }
    i = i + 1
    l
  }

  override type Leet[N, V <: AType] = PrintEngineLeet[N, V]

  override type PairLeet[N, K, V <: AType] = PrintEnginePairLeet[N, K, V]

  case class PrintEngineLeet[N, V <: AType](wrapped: e.Leet[N, V])

  case class PrintEnginePairLeet[N, K, V <: AType](wrapped: e.PairLeet[N, K, V])

  //  override def cartesian[N: CT, V1: CT, V2: CT](l1: PrintEngineLeet[N, ABag[V1]], l2: PrintEngineLeet[N, ABag[V2]]): PrintEngineLeet[N, ABag[(V1, V2)]] =
  //    log("cartesian", PrintEngineLeet(e.cartesian(l1.wrapped, l2.wrapped)))


  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): PrintEngineLeet[N, V] =
    log("create", PrintEngineLeet(e.create(edges, nodes)))

  override def subgraph[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): PrintEngineLeet[N, V] =
    log("subgraph", PrintEngineLeet(e.subgraph(l.wrapped, edges, nodes)))

  override def reverse[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("reverse", PrintEngineLeet(e.reverse(l.wrapped)))

  /**
    * This is not the same as merge as it add another graph to the data structure. Double node definitions must carry the same values.
    */
  override def append[N: CT, V <: AType : CT](l1: PrintEngineLeet[N, V], l2: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("append", PrintEngineLeet(e.append(l1.wrapped, l2.wrapped)))

  override def merge[N: CT, V <: AType : CT](l1: PrintEngineLeet[N, V], l2: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("merge", PrintEngineLeet(e.merge(l1.wrapped, l2.wrapped)))

  override def mergeIx[N: CT, K: CT, V <: AType : CT](l1: PrintEnginePairLeet[N, K, V], l2: PrintEnginePairLeet[N, K, V]): PrintEnginePairLeet[N, K, V] =
    log("mergeIx", PrintEnginePairLeet(e.mergeIx(l1.wrapped, l2.wrapped)))

  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: PrintEngineLeet[N, V1], l2: PrintEngineLeet[N, V2]): PrintEngineLeet[N, ATuple[V1, V2]] =
    log("product", PrintEngineLeet(e.product(l1.wrapped, l2.wrapped)))

  override def productIx[N: CT, K1: CT, V1 <: AType : CT, K2: CT, V2 <: AType : CT](l1: PrintEnginePairLeet[N, K1, V1], l2: PrintEnginePairLeet[N, K2, V2]): PrintEnginePairLeet[N, (K1, K2), ATuple[V1, V2]] =
    log("productIx", PrintEnginePairLeet(e.productIx(l1.wrapped, l2.wrapped)))

  override def zero[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("zero", PrintEngineLeet(e.zero(l.wrapped)))

  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): PrintEngineLeet[N, V2] =
    log("tmap", PrintEngineLeet(e.tmap(l.wrapped)(f)))

  override def tmapIx[N: CT, K: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEnginePairLeet[N, K, V1])(f: (K, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PrintEnginePairLeet[N, K2, V2] =
    log("tmapIx", PrintEnginePairLeet(e.tmapIx(l.wrapped)(f)))

  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEngineLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): PrintEngineLeet[N, V2] =
    log("tmapHom", PrintEngineLeet(e.tmapHom(l.wrapped)(f)))

  override def tmapHomIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEnginePairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PrintEnginePairLeet[N, K2, V2] =
    log("tmapHomIx", PrintEnginePairLeet(e.tmapHomIx(l.wrapped)(f)))

  override def tmapHomLinIx[N: CT, K1: CT, K2: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEnginePairLeet[N, K1, V1])(f: (K1, V1) => AMap[K2, V2])(implicit v2Abelian: Group[V2]): PrintEnginePairLeet[N, K2, V2] =
    log("tmapHomLinIx", PrintEnginePairLeet(e.tmapHomLinIx(l.wrapped)(f)))

  override def tmapDynamic[N: CT, K1: CT, K2: CT, V1 <: AType : CT](l: PrintEnginePairLeet[N, K1, V1])(f: K1 => K2): PrintEnginePairLeet[N, K2, V1] =
    log("tmapDynamic", PrintEnginePairLeet(e.tmapDynamic(l.wrapped)(f)))

  override def edges[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Set[(N, N)] =
    e.edges(l.wrapped)

  override def edgesIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Set[(N, N)] =
    e.edgesIx(l.wrapped)

  override def zeroEdges[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Set[(N, N)] =
    e.zeroEdges(l.wrapped)

  override def zeroEdgesIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Set[(N, N)] =
    e.zeroEdgesIx(l.wrapped)

  override def values[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], on: Set[N]): Iterator[(N, V)] =
    e.values(l.wrapped, on)

  override def relativeValues[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Iterator[((N, N), V)] =
    e.relativeValues(l.wrapped)

  override def relativeValuesIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Iterator[((N, N), (K, V))] =
    e.relativeValuesIx(l.wrapped)

  override def contract[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], mapping: Map[N, N]): PrintEngineLeet[N, V] =
    log("contract", PrintEngineLeet(e.contract(l.wrapped, mapping)))

  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEngineLeet[N, V1], to: PrintEngineLeet[N, V2], mapping: Map[N, N]): PrintEngineLeet[N, V1] =
    log("uncontract", PrintEngineLeet(e.uncontract(l.wrapped, to.wrapped, mapping)))

  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: PrintEngineLeet[N1, V])(f: N1 => N2): PrintEngineLeet[N2, V] =
    log("nmap", PrintEngineLeet(e.nmap(l.wrapped)(f)))

  override def reduce[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V])(f: (V, V) => V): V =
    e.reduce(l.wrapped)(f)

  override def acDelta[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("acDelta", PrintEngineLeet(e.acDelta(l.wrapped)))

  override def force[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("force", PrintEngineLeet(e.force(l.wrapped)))

  override def forceIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): PrintEnginePairLeet[N, K, V] =
    log("forceIx", PrintEnginePairLeet(e.forceIx(l.wrapped)))

  //  override def delta[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
  //    log("delta", PrintEngineLeet(e.delta(l.wrapped)))

  override def nodes[N: CT, T <: AType : CT](l: PrintEngineLeet[N, T]): Set[N] =
    e.nodes(l.wrapped)

  override def nodesIx[N: CT, K: CT, T <: AType : CT](l: PrintEnginePairLeet[N, K, T]): Set[N] =
    e.nodesIx(l.wrapped)

  override def abelian[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Group[V] =
    e.abelian(l.wrapped)

  override def abelianIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Group[AMap[K, V]] =
    e.abelianIx(l.wrapped)

  override def close(): Unit = {
    e.close()
    appendable match {
      case x: Closeable =>
        x.close()
      case _ =>
    }
  }

  override def authorship[N: CT](l: PrintEngineLeet[N, ADouble]): PrintEngineLeet[N, AMap[N, ADouble]] =
    log("authorship", PrintEngineLeet(e.authorship(l.wrapped)))

  override def subgraph[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], nodes: Set[N]): PrintEngineLeet[N, V] =
    log("subgraph", PrintEngineLeet(e.subgraph(l.wrapped, nodes)))

  override def values[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Iterator[(N, V)] =
    e.values(l.wrapped)

  override def size[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Int =
    e.size(l.wrapped)

  override def sizeIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Int =
    e.sizeIx(l.wrapped)

  override def branches[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], line: Seq[N]): PrintEngineLeet[N, ABag[N]] =
    log("branches", PrintEngineLeet(e.branches(l.wrapped, line)))

  //  override def collectLinearize[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], line: Seq[N]): PrintEngineLeet[N, ABag[V]] =
  //    log("collectLinearize", PrintEngineLeet(e.collectLinearize(l.wrapped, line)))

  override def acLinearize[N1: CT, V <: AType : CT](l: PrintEngineLeet[N1, V], line: Seq[N1]): PrintEngineLeet[N1, V] =
    log("acLinearize", PrintEngineLeet(e.acLinearize(l.wrapped, line)))

  override def collectDeltas[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], merges: Boolean = true): PrintEnginePairLeet[N, N, V] =
    log("collectDeltas", PrintEnginePairLeet(e.collectDeltas(l.wrapped, merges)))

  override def collectDeltasIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V], merges: Boolean = true): PrintEnginePairLeet[N, (N, K), V] =
    log("collectDeltasIx", PrintEnginePairLeet(e.collectDeltasIx(l.wrapped, merges)))

  override def incoming[N: CT, T <: AType : CT](l: PrintEngineLeet[N, T]): Map[N, Set[N]] =
    e.incoming(l.wrapped)

  override def incomingIx[N: CT, K: CT, T <: AType : CT](l: PrintEnginePairLeet[N, K, T]): Map[N, Set[N]] =
    e.incomingIx(l.wrapped)

  override def outgoing[N: CT, T <: AType : CT](l: PrintEngineLeet[N, T]): Map[N, Set[N]] =
    e.outgoing(l.wrapped)

  override def outgoingIx[N: CT, K: CT, T <: AType : CT](l: PrintEnginePairLeet[N, K, T]): Map[N, Set[N]] =
    e.outgoingIx(l.wrapped)

  override def roots[N: CT, T <: AType : CT](l: PrintEngineLeet[N, T]): Set[N] =
    e.roots(l.wrapped)

  override def rootsIx[N: CT, K: CT, T <: AType : CT](l: PrintEnginePairLeet[N, K, T]): Set[N] =
    e.rootsIx(l.wrapped)

  override def leafs[N: CT, T <: AType : CT](l: PrintEngineLeet[N, T]): Set[N] =
    e.leafs(l.wrapped)

  override def leafsIx[N: CT, K: CT, T <: AType : CT](l: PrintEnginePairLeet[N, K, T]): Set[N] =
    e.leafsIx(l.wrapped)

  override def ts[N: CT, T <: AType : CT](l: PrintEngineLeet[N, T]): Iterator[N] =
    e.ts(l.wrapped)

  override def tsIx[N: CT, K: CT, T <: AType : CT](l: PrintEnginePairLeet[N, K, T]): Iterator[N] =
    e.tsIx(l.wrapped)

  override def maskBypassEdges[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): PrintEngineLeet[N, V] =
    log("maskBypassEdges", PrintEngineLeet(e.maskBypassEdges(l.wrapped)))

  override def bypassEdges[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): Iterator[(N, N)] =
    e.bypassEdges(l.wrapped)

  override def contractEdges[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V], target: Set[(N, N)]): (PrintEngineLeet[N, V], Map[N, N]) = {
    val (r, m) = e.contractEdges(l.wrapped, target)

    (log("contractEdges", PrintEngineLeet(r)), m)
  }

  override def contractZero[N: CT, V <: AType : CT](l: PrintEngineLeet[N, V]): (PrintEngineLeet[N, V], Map[N, N]) = {
    val (r, m) = e.contractZero(l.wrapped)

    (log("contractEdges", PrintEngineLeet(r)), m)
  }

  override def keys[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Set[K] =
    e.keys(l.wrapped)


  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V], on: Set[N]): Iterator[(N, K, V)] =
    e.valuesIx(l.wrapped, on)

  override def valuesIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): Iterator[(N, K, V)] =
    e.valuesIx(l.wrapped)

  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N, K, V]): PrintEnginePairLeet[N, K, V] =
    log("acDeltaIx", PrintEnginePairLeet(e.acDeltaIx(l.wrapped)))

  override def authorshipIx[N: CT, K: CT](l: PrintEnginePairLeet[N, K, ADouble]): PrintEnginePairLeet[N, (N, K), ADouble] =
    log("authorshipIx", PrintEnginePairLeet(e.authorshipIx(l.wrapped)))

  override def acLinearizeIx[N1: CT, K: CT, V <: AType : CT](l: PrintEnginePairLeet[N1, K, V], line: Seq[N1]): PrintEnginePairLeet[N1, K, V] =
    log("acLinearizeIx", PrintEnginePairLeet(e.acLinearizeIx(l.wrapped, line)))

  //  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: PrintEnginePairLeet[N, K, V1])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): PrintEngineLeet[N, V2] =
  //    log("tmapIx", PrintEngineLeet(e.tmapIx(l.wrapped)(f)))

  override implicit def pairLeet2Leet[N: CT, K: CT, V <: AType : CT](pairLeet: PrintEnginePairLeet[N, K, V]): PrintEngineLeet[N, AMap[K, V]] =
    PrintEngineLeet(e.pairLeet2Leet(pairLeet.wrapped))

  override implicit def leet2PairLeet[N: CT, K: CT, V <: AType : CT](leet: PrintEngineLeet[N, AMap[K, V]]): PrintEnginePairLeet[N, K, V] =
    PrintEnginePairLeet(e.leet2PairLeet(leet.wrapped))

  override def createIx[N: CT, K: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, AMap[K, V]])(implicit vAbelian: Group[V]): PrintEnginePairLeet[N, K, V] =
    log("createIx", PrintEnginePairLeet(e.createIx(edges, nodes)))


}
