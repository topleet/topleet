//package org.unknown1337.topleet.atypes
//
//
//object Abl {
//
//
////
////  implicit def abl[T](aMap: AMap[T,AInteger]):Abl =
////
////  implicit def ablGroup[T]: Group[Abl[T]] = new Group[Abl[T]] {
////    override def merge(v1: Abl[T], v2: Abl[T]): Abl[T] = Abl.merge(v1, v2)
////
////    override def inverse(v: Abl[T]): Abl[T] = Abl.inverse(v)
////
////    override def zero: Abl[T] = Abl.zero()
////  }
//
////  def isSingle[T](x: Abl[T]): Boolean = x.value.values.sum == 1 && x.value.values.size == 1
////
////  def unapply[V](arg: Abl[V]): Option[V] = {
////    if (arg.value.values.sum == 1 && arg.value.values.size == 1) Some(arg.value.head._1)
////    else None
////  }
////
////  def apply[T](t: T) = AMap.create(t,AInteger(1))
//
////  def merge[T](bag1: Abl[T], bag2: Abl[T]): Abl[T] =
////    new Abl((bag1.value.keySet ++ bag2.value.keySet)
////      .map(k => k -> (bag1.value.getOrElse(k, 0) + bag2.value.getOrElse(k, 0)))
////      .filter(_._2 != 0).toMap)
////
////  def inverse[T](bag: Abl[T]): Abl[T] = new Abl(bag.value.map({
////    case (value, count) => (value, -count)
////  }))
////
////  def zero[T](): Abl[T] = new Abl(Map[T, Int]())
//}
//
////
////class Abl[T](val value: Map[T, Int]) extends AType with Serializable {
////  override def toString: String = this match {
////    case x if x.value.size > 1 => "Abl(" + value.toString() + ")"
////    case Abl(x) => "Abl " + x.toString
////    case x => x.toString
////  }
////
////
////  def canEqual(other: Any): Boolean = other.isInstanceOf[Abl[_]]
////
////  override def equals(other: Any): Boolean = other match {
////    case that: Abl[_] =>
////      (that canEqual this) &&
////        value == that.value
////    case _ => false
////  }
////
////  override def hashCode(): Int = {
////    val state = Seq(value)
////    state.map(_.hashCode()).foldLeft(0)((a, b) => 31 * a + b)
////  }
////
////  override def ~=(other: AType): Boolean = {
////    if (!other.isInstanceOf[Abl[T]]) return false
////    val o = other.asInstanceOf[Abl[T]]
////    this.value == o.value
////  }
////
////  override def isZero: Boolean = false
////
////  override def isApproxZero: Boolean = isZero
////
////  /**
////    * Length of the delta in terms of effort needed to conduct it.
////    */
////  override def dlength(): Double = value.toSeq.map(_._2).map(Math.abs).sum.toDouble
////}
////
