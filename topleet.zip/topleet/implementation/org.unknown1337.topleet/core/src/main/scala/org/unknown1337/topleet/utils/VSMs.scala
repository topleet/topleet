package org.unknown1337.topleet.utils

import java.util.regex.Pattern

import org.unknown1337.topleet.atypes.{ADouble, AMap}

import scala.collection.mutable

import AMap._

object VSMs {

  type Vector[T] = AMap[T, ADouble]

  def JavaStopwords = Set("abstract", "assert", "boolean", "break",
    "byte", "case", "catch", "char",
    "class", "const", "continue", "default",
    "do", "double", "else", "enum",
    "extends", "final", "finally", "float",
    "for", "goto", "if", "implements",
    "import", "instanceof", "int", "interface",
    "long", "native", "new", "package",
    "private", "protected", "public", "return",
    "short", "static", "strictfp", "super",
    "switch", "synchronized", "this", "throw",
    "throws", "transient", "try", "void",
    "volatile", "while", "true", "false",
    "null")

  // TODO: Check this implementation of cosine as I don't like it.
  //  def cosine[T](a: Map[T, Double], b: Map[T, Double]): Double = {
  //    val left = a.map { case (_, value) => math.pow(value, 2d) }.fold(0d)(_ + _)
  //    val right = b.map { case (_, value) => math.pow(value, 2d) }.fold(0d)(_ + _)
  //    val index = a.keySet.intersect(b.keySet).toSeq
  //
  //    val top = index.map { term => a(term) * b(term) }.fold(0d)(_ + _)
  //    val bottom = math.sqrt(right) * math.sqrt(left)
  //
  //    val result = Math.abs(top / bottom)
  //
  //    if (result.isNaN) 0
  //    else result
  //  }

  def dot[T](a: Vector[T], b: Vector[T]): Double =
    a.value.keySet.intersect(b.value.keySet).toSeq.map(t => a.value(t).value * b.value(t).value).sum

  //  def lp[T](a: Vector[T], b: Vector[T], p: Int): Double =
  //    Math.pow(a.value.keySet.union(b.value.keySet).toSeq.map(t => Math.pow(Math.abs(a.value.getOrElse(t, 0.0) - b.value.getOrElse(t, 0.0)), p)).sum, 1.0 / p.toDouble)

  def insert(regex: String, content: String, offset: Integer): String => String = x => {
    val matcher = Pattern.compile(regex).matcher(x)
    var current = x
    var number = 0
    while (matcher.find()) {
      def position = matcher.start() + offset + number

      current = current.substring(0, position) + content + current.substring(position)
      number = number + 1
    }
    current
  }

  def replace(map: Map[String, String]): String => String = x => map.foldRight(x)((l, r) => r.replaceAll(l._1, l._2))

  def keepLetters(x: String): String = replace(Map("[^a-zA-Z]" -> " "))(x)

  def keepLettersNoWs(x: String): String = replace(Map("[^a-zA-Z]" -> ""))(x)

  def toLower(x: String): String = x.toLowerCase

  def splitCamelCase(x: String): String = insert("[A-Z][A-Z][a-z]", " ", 1)(insert("[a-z][A-Z]", " ", 1)(x))

  def neg[T](x: Vector[T]): Vector[T] =
    AMap.aMapGroup[T, ADouble](ADouble.aDoubleGroup).inverse(x)

  def add[T](x: Vector[T], y: Vector[T]): Vector[T] =
    AMap.aMapGroup[T, ADouble](ADouble.aDoubleGroup).merge(x, y)

  def zero[T]: Vector[T] = AMap.aMapGroup[T, ADouble](ADouble.aDoubleGroup).zero

  def length[T](a: Vector[T]): Double = a.value.toSeq.map { case (_, v) => Math.abs(v.toDouble) }.sum

  def negLength[T](a: Vector[T]): Double = -a.value.toSeq.map { case (_, v) => Math.min(v.toDouble, 0) }.sum

  def posLength[T](a: Vector[T]): Double = a.value.toSeq.map { case (_, v) => Math.max(v.toDouble, 0) }.sum

  def unitLength[T](a: Vector[T]): Vector[T] = {
    val aLength = length(a)
    a.mapValues { case (k, v) => amap(k, ADouble.toADouble(v.toDouble / aLength)) }
  }

  def tokenize(x: String): Seq[String] = x.split(" ").filter { x => !("".equals(x) || " ".equals(x)) }

  def vectorize[T](x: Seq[T]): Vector[T] = AMap(x.groupBy(identity).map { case (k, v) => (k, ADouble.toADouble(v.size)) })

  //  def invertedIndex[D, T](documents: Iterable[(D, Map[T, Double])]): Map[T, Seq[(D, Double)]] =
  //    Utils.groupByKey(documents.flatMap { case (d, terms) => terms.map { case (term, weight) => (term, (d, weight)) } }.toSeq)

  //  def dotInvertedIndex[D, T](query: Map[T, Double], invertedIndex: Map[T, Seq[(D, Double)]]): Map[D, Double] = {
  //    val dots = mutable.Map[D, Double]()
  //    for ((t, wq) <- query; (d, wd) <- invertedIndex(t)) {
  //      dots.put(d, dots.getOrElse(d, 0.0) + wq + wd)
  //    }
  //    dots.toMap
  //  }


}
