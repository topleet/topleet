package org.unknown1337.topleet.utils

import java.io._
import java.nio.charset.Charset

import com.google.gson.JsonObject

import scala.util.parsing.json.JSONObject

object JSONLDPrinter {
  def create(file: File, charset: Charset, append: Boolean = false) =
    JSONLDPrinter(new OutputStreamWriter(new FileOutputStream(file, append), charset))
}

case class JSONLDPrinter(appendable: Appendable) {

  def flush(): Unit = {
    appendable match {
      case x: Flushable =>
        x.flush()
      case _ =>
    }
  }

  def close(): Unit = {
    appendable match {
      case x: Closeable =>
        x.close()
      case _ =>
    }
  }

  def printRecord(json: JsonObject): Unit =
    appendable.append(json.toString + System.getProperty("line.separator"))

  def printRecord(args: String*): Unit =
    printRecord(args.toList.grouped(2).map { case x :: y :: Nil => x -> y }.toMap)

  def printRecord(map: Map[String, String]): Unit =
    appendable.append(JSONObject(map).toString() + System.getProperty("line.separator"))

}
