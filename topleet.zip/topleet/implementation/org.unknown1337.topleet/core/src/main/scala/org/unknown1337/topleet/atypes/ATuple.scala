package org.unknown1337.topleet.atypes

import org.unknown1337.topleet.Group

object ATuple {

  implicit def aTupleGroup[A <: AType, B <: AType](implicit aAbelian: Group[A], bAbelian: Group[B]): Group[ATuple[A, B]] = new Group[ATuple[A, B]] {

    override def merge(v1: ATuple[A, B], v2: ATuple[A, B]): ATuple[A, B] = ATuple(aAbelian.merge(v1.t1, v2.t1), bAbelian.merge(v1.t2, v2.t2))

    override def inverse(v: ATuple[A, B]): ATuple[A, B] = ATuple(aAbelian.inverse(v.t1), bAbelian.inverse(v.t2))

    override def zero: ATuple[A, B] = ATuple(aAbelian.zero, bAbelian.zero)
  }

}

case class ATuple[T1 <: AType, T2 <: AType](t1: T1, t2: T2) extends AType {

  override def ~=(other: AType): Boolean = {
    if (!other.isInstanceOf[ATuple[T1, T2]]) return false
    val o = other.asInstanceOf[ATuple[T1, T2]]

    (this.t1 ~= o.t1) && (this.t2 ~= o.t2)
  }

  override def isZero: Boolean = t1.isZero && t2.isZero

  override def isApproxZero: Boolean = t1.isApproxZero && t2.isApproxZero

  /**
    * Length of the delta in terms of effort needed to conduct it.
    */
  override def dlength(): Double = t1.dlength() + t2.dlength()
}
