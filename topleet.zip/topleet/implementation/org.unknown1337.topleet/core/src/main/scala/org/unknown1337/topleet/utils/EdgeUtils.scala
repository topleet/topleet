package org.unknown1337.topleet.utils

import java.io.File

import com.google.common.base.Charsets
import com.google.common.io.Files
import org.apache.spark.{HashPartitioner, Partitioner}

import org.apache.spark.rdd.RDD
import org.apache.spark.storage.StorageLevel

import scala.annotation.tailrec
import scala.collection.mutable
import scala.reflect.ClassTag

object EdgeUtils {

  /**
    * Duplicates the graph along the gap.
    * Alternative may be slower: // edges.union(edges.map { case ((v1, v2), e) => ((v1 + offset, v2 + offset), e) }).
    */
  def mirror[E](edges: RDD[((Long, Long), E)], offset: Long)(implicit et: ClassTag[E]): RDD[((Long, Long), E)] =
    edges.flatMap { case ((v1, v2), e) => Seq(((v1, v2), e), ((v1 + offset, v2 + offset), e)) }

  def ccedge[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner)(implicit et: ClassTag[E]): RDD[((Long, Long), (E, Long))] = {
    val connectedComponents = cc(edges.map { case ((v1, v2), _) => (v1, v2) }, partitioner)

    edges.map { case ((v1, v2), e) => v1 -> (v2, e) }
      .join(connectedComponents, partitioner)
      .map { case (v1, ((v2, e), cc)) => ((v1, v2), (e, cc)) }
  }

  def ccList(edges: RDD[List[Long]], partitioner: Partitioner): RDD[(Long, Long)] =
    PConnectedComponents.run(edges.map { list => list }, Int.MaxValue, partitioner)._1


  def cc(edges: RDD[(Long, Long)], partitioner: Partitioner): RDD[(Long, Long)] =
    PConnectedComponents.run(edges.map { case (v1, v2) => List(v1, v2) }, Int.MaxValue, partitioner)._1

  def packAttr[E](edges: RDD[((Long, Long), (E, Boolean))], partitioner: Partitioner)
                 (implicit etag: ClassTag[E]): RDD[((Long, Long), E)] = {
    pack(edges, partitioner) { x => x._2 }.mapValues(_._1)
  }

  /**
    * A function that packs a graph, i.e.,  merges those nodes that are connected by completely idle edges.
    */
  def pack[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner)
             (packer: E => Boolean)
             (implicit etag: ClassTag[E]): RDD[((Long, Long), E)] = {

    // Filters for edges that that only contain idle es where nodes have to be merged and on busy edges that are kept in the graph.
    val idle = edges.mapValues(packer).reduceByKey(partitioner, _ && _).filter(_._2).keys

    triplets(edges, cc(idle, partitioner), partitioner).map { case ((v1, v2), (vv1, e, vv2)) => ((vv1.getOrElse(v1), vv2.getOrElse(v2)), e) }
  }

  /**
    * Creates the triple representation of edges and nodes attributes.
    */
  def triplets[E, V, VV](edges: RDD[((VV, VV), E)], vertices: RDD[(VV, V)], partitioner: Partitioner)
                        (implicit vt: ClassTag[V], et: ClassTag[E], vvt: ClassTag[VV]): RDD[((VV, VV), (Option[V], E, Option[V]))] = {

    edges.map { case ((v1, v2), e) => v1 -> (v2, e) }
      .leftOuterJoin(vertices, partitioner)
      .map { case (v1, ((v2, e), vv1)) => v2 -> (v1, e, vv1) }
      .leftOuterJoin(vertices, partitioner)
      .map { case (v2, ((v1, e, vv1), vv2)) => ((v1, v2), (vv1, e, vv2)) }
  }

  def locality(x: Long, ppow: Int, kpow: Int, i: Int): Int = {
    val partitions: Int = Math.pow(2, ppow).toInt
    //val ishift = (vpow + 1) - ppow + Math.min(ppow, i + 1)
    val ishift = kpow - ppow + Math.min(ppow, i)
    val xii = x >> ishift
    val xiii = (xii % partitions).toInt

    xiii
  }

  // TODO: There is some error here since some partitions are not populated. Possibly the values are not equally distributed.
  def createPartitioner(i: Int, kpow: Int, vpow: Int, ppow: Int) = new Partitioner {
    val partitions: Int = Math.pow(2, ppow).toInt

    override def numPartitions: Int = partitions

    override def getPartition(key: Any): Int = key match {
      case v: Long => locality(v, ppow, kpow, i)
      case (v1: Long, v2: Long) => locality(Math.min(v1, v2), ppow, kpow, i)
    }
  }

  def indegreeTarget[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner)(implicit et: ClassTag[E]): RDD[((Long, Long), (E, Int))] =
    edges.groupBy { case ((_, v2), _) => v2 }
      .flatMap { case (_, group) => group.map { case ((v1, v2), e) => ((v1, v2), (e, group.size)) } }


  def outdegreeSource[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner)(implicit et: ClassTag[E]): RDD[((Long, Long), (E, Int))] =
    edges.groupBy { case ((v1, _), _) => v1 }
      .flatMap { case (_, group) => group.map { case ((v1, v2), e) => ((v1, v2), (e, group.size)) } }

  def indegrees[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner, isDistinct: Boolean = false)(implicit et: ClassTag[E]): RDD[(Long, Int)] =
    (if (isDistinct) edges.keys else edges.keys.distinct()).map { case (_, v2) => (v2, 1) }.reduceByKey(partitioner, _ + _)

  def outdegrees[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner, isDistinct: Boolean = false)(implicit et: ClassTag[E]): RDD[(Long, Int)] =
    (if (isDistinct) edges.keys else edges.keys.distinct()).map { case (v1, _) => (v1, 1) }.reduceByKey(partitioner, _ + _)


  /**
    * Equally distributed the vertex ids on a 2 potency. This mapping preserves sorting.
    */
  def distributeVertex[E](edges: RDD[((Long, Long), E)], partitioner: Partitioner, inverse: Boolean = false)(implicit et: ClassTag[E]): (Int, RDD[((Long, Long), E)]) = {
    val mapping = edges.flatMap { case ((v1, v2), _) => Seq(v1, v2) }.distinct().sortBy(identity).zipWithIndex()
    val kmax = mapping.count()
    val kpow = Math.ceil(Math.log(kmax) / Math.log(2)).toInt

    def scale(x: Long): Long = x * (Math.pow(2, kpow).toLong - 1) / kmax

    println("TODO: Check for vertex collision")

    (kpow, triplets(edges, mapping, partitioner).map { case (_, (Some(v1), e, Some(v2))) => ((scale(v1), scale(v2)), e) })
  }

  /**
    * Split key and process values for a tuple key. Moves from a key locality to a value locality. Inverts the key map relation.
    */
  def splitAndProcess[E](edges: RDD[((Long, Long), E)], partitionPow: Int, keyPow: Int, valuePow: Int, splits: Int)
                        (subroutine: (Int, Partitioner, RDD[((Long, Long), (E, (Long, Long)))]) => RDD[((Long, Long), (E, (Long, Long)))])
                        (implicit et: ClassTag[E]): RDD[((Long, Long), E)] = {

    var current = edges.map { case ((v1, v2), e) => ((v1, v2), (e, (0l, Math.pow(2, valuePow).toLong))) }

    var i = 0
    while (i < valuePow) {

      // Mirror graph according to the split.
      var u = 0
      while (i < valuePow && u < splits) {
        val m = 2l << (keyPow + i - 1)

        current = mirror(current, m)

        // Split the attribute ranges.
        current = current.map {
          case ((v1, v2), (vd, (low, high))) if v1 < m => ((v1, v2), (vd, (low, ((high.toLong + low.toLong) / 2).toInt)))
          case ((v1, v2), (vd, (low, high))) if v1 >= m => ((v1, v2), (vd, ((((high.toLong + low.toLong) / 2) + 1).toInt, high)))
        }

        u = u + 1
        i = i + 1
      }

      // Replace the current partitioning by a new one based on value locality information encoded in the vertices.
      // TODO: This is a try, if this is working extract to interface:
      val partitioner = createPartitioner(i, keyPow, valuePow, partitionPow)
      current = current.partitionBy(partitioner)

      // Call subroutine.
      val next = subroutine(i, partitioner, current).persist(StorageLevel.MEMORY_AND_DISK)
      current.unpersist()
      current = next
    }
    current.mapValues(_._1)
  }

//  def viewer[E, V](ouptut: File, edges: Seq[((V, V), (Map[String, String], Seq[Map[String, String]]))],
//                   vertices: Seq[(V, (Map[String, String], Seq[Map[String, String]]))])
//                  (implicit vt: ClassTag[V], et: ClassTag[E]): Unit = {
//    viewer(ouptut, SparkUtils.sc.parallelize(edges), SparkUtils.sc.parallelize(vertices))(vt)
//  }
//
//
//  def viewer[E, V](ouptut: File, edges: RDD[((V, V), (Map[String, String], Seq[Map[String, String]]))])
//                  (implicit vt: ClassTag[V]): Unit = viewer(ouptut, edges, SparkUtils.sc.parallelize[(V, (Map[String, String], Seq[Map[String, String]]))](Seq()))
//

  def viewerGroup[G, E, V](ouptut: File, edges: RDD[((G, V, V), (Map[String, String], Seq[Map[String, String]]))],
                           vertices: RDD[((G, V), (Map[String, String], Seq[Map[String, String]]))])
                          (implicit vt: ClassTag[V],gt: ClassTag[G]): Unit = {

    val edgesWithId = edges.zipWithIndex()


    val verticesWithId = (edges
      .flatMap { case ((g, v1, v2), _) => Seq((g, v1), (g, v2)) }
      .distinct()
      .subtract(vertices.map(_._1))
      .map(id => id -> (Map("label" -> ""), Seq[Map[String, String]]())) ++
      vertices).zipWithIndex()

    val edgeJson = edgesWithId.map {
      case (((g, v1, v2), (dotAttributes, jsonAttributes)), id) => "\"e" + id + "\":{" + "\"svg\":" +
        "{" + Utils.toJson(dotAttributes) + "}" +
        ", \"hover\":[" + jsonAttributes.map(y => "{" + Utils.toJson(y) + "}").reduceOption(_ + "," + _).getOrElse("") + "]}"
    }

    val vertexJson = verticesWithId.map {
      case (((g, v1), (dotAttributes, jsonAttributes)), id) => "\"n" + id + "\":{" + "\"svg\":" +
        "{" + Utils.toJson(dotAttributes) + "}" +
        ", \"hover\":[" + jsonAttributes.map(y => "{" + Utils.toJson(y) + "}").reduceOption(_ + "," + _).getOrElse("") + "]}"
    }

    val json = "{" + (edgeJson ++ vertexJson).reduce(_ + ",\r\n" + _) + "}"

    def attributes(x: Map[String, String]) =
      "[" + x.map { case (k, v) => k + "=\"" + v + "\"" }.reduceOption(_ + ", " + _).getOrElse("") + "]"

    val edgesDot = edgesWithId.map { case (((g, v1, v2), (dotAttributes, _)), id) => (g, "nd" + v1 + " -> " + "nd" + v2 + attributes(Map("id" -> ("e" + id)) ++ dotAttributes) + ";") }

    val vertexDot = verticesWithId.map { case (((g, v1), (dotAttributes, _)), id) => (g, "nd" + v1 + attributes(Map("id" -> ("n" + id)) ++ dotAttributes) + ";") }

    val groups = edgesDot.cogroup(vertexDot).zipWithIndex().map { case ((g, (edges, vertex)), index) =>
      " subgraph cluster_" + index + " {\r\n label = \"" +g.toString + "\"; \r\n" + edges.reduce(_ + "\r\n" + _) + "\r\n" + vertex.reduce(_ + "\r\n" + _) + "\r\n" + "}"
    }


    val dot = "digraph R {" + "\r\n" + groups.reduce(_ + "\r\n" + _) + "\r\n" + "}"

    val path = ouptut.getAbsolutePath
    val filename = path.split("\\\\").last

    Files.createParentDirs(new File(path + ".json"))
    Files.asCharSink(new File(path + ".json"), Charsets.UTF_8).write(json)
    Files.asCharSink(new File(path + ".dot"), Charsets.UTF_8).write(dot)

    Files.asCharSink(new File(path + ".html"), Charsets.UTF_8).write(Files.asCharSource(new File("core/src/main/resources/viewer/viewer.html"), Charsets.UTF_8).read()
      .replaceAll("\"viewer.json\"", "\"" + filename + ".json\"")
      .replaceAll("\"viewer.dot\"", "\"" + filename + ".dot\""))
  }


  def viewer[E, V](ouptut: File, edges: RDD[((V, V), (Map[String, String], Seq[Map[String, String]]))],
                   vertices: RDD[(V, (Map[String, String], Seq[Map[String, String]]))])
                  (implicit vt: ClassTag[V]): Unit = {

    val edgesWithId = edges.zipWithIndex()


    val verticesWithId = (edges
      .flatMap {
        case ((v1, v2), _) => Seq(v1, v2)
      }
      .distinct()
      .subtract(vertices.map(_._1))
      .map(id => id -> (Map("label" -> ""), Seq[Map[String, String]]())) ++
      vertices).zipWithIndex()

    val edgeJson = edgesWithId.map {
      case (((v1, v2), (dotAttributes, jsonAttributes)), id) => "\"e" + id + "\":{" + "\"svg\":" +
        "{" + Utils.toJson(dotAttributes) + "}" +
        ", \"hover\":[" + jsonAttributes.map(y => "{" + Utils.toJson(y) + "}").reduceOption(_ + "," + _).getOrElse("") + "]}"
    }

    val vertexJson = verticesWithId.map {
      case ((v1, (dotAttributes, jsonAttributes)), id) => "\"n" + id + "\":{" + "\"svg\":" +
        "{" + Utils.toJson(dotAttributes) + "}" +
        ", \"hover\":[" + jsonAttributes.map(y => "{" + Utils.toJson(y) + "}").reduceOption(_ + "," + _).getOrElse("") + "]}"
    }

    val json = "{" + (edgeJson ++ vertexJson).reduce(_ + ",\r\n" + _) + "}"

    def attributes(x: Map[String, String]) =
      "[" + x.map {
        case (k, v) => k + "=\"" + v + "\""
      }.reduceOption(_ + ", " + _).getOrElse("") + "]"

    val edgesDot = edgesWithId
      .map {
        case (((v1, v2), (dotAttributes, _)), id) => "nd" + v1 + " -> " + "nd" + v2 + attributes(Map("id" -> ("e" + id)) ++ dotAttributes) + ";"
      }
      .reduce(_ + "\r\n" + _)

    val vertexDot = verticesWithId
      .map {
        case ((v1, (dotAttributes, _)), id) =>
          "nd" + v1 + attributes(Map("id" -> ("n" + id)) ++ dotAttributes) + ";"
      }
      .reduce(_ + "\r\n" + _)


    val dot = "digraph R {" + "\r\n" + vertexDot + "\r\n" + edgesDot + "\r\n" + "}"

    val path = ouptut.getAbsolutePath
    val filename = path.split("\\\\").last

    Files.createParentDirs(new File(path + ".json"))
    Files.asCharSink(new File(path + ".json"), Charsets.UTF_8).write(json)
    Files.asCharSink(new File(path + ".dot"), Charsets.UTF_8).write(dot)

    Files.asCharSink(new File(path + ".html"), Charsets.UTF_8).write(Files.asCharSource(new File("core/src/main/resources/viewer/viewer.html"), Charsets.UTF_8).read()
      .replaceAll("\"viewer.json\"", "\"" + filename + ".json\"")
      .replaceAll("\"viewer.dot\"", "\"" + filename + ".dot\""))
  }

}
