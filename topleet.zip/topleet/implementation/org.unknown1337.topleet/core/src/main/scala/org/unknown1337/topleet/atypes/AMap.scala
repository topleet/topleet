package org.unknown1337.topleet.atypes

import org.unknown1337.topleet.Group

import scala.collection.mutable

case class AbelianAMap[K, V <: AType](vAbelian: Group[V]) extends Group[AMap[K, V]] {

  override def merge(map1: AMap[K, V], map2: AMap[K, V]): AMap[K, V] = (map1, map2) match {
    case (AMap(smaller), AMap(bigger)) if smaller.size < bigger.size => merge(AMap(bigger), AMap(smaller))
    case (AMap(bigger), AMap(smaller)) => AMap(
      smaller.foldLeft(bigger) {
        case (m, (k, v)) if m.isDefinedAt(k) && vAbelian.merge(m(k), v) != vAbelian.zero =>
          m.updated(k, vAbelian.merge(m(k), v))
        case (m, (k, _)) if m.isDefinedAt(k) => m - k
        case (m, (k, v)) => m.updated(k, v)
      })
  }

  override def inverse(map: AMap[K, V]): AMap[K, V] = AMap(map.value.map { case (k, v) => (k, vAbelian.inverse(v)) })

  override def zero: AMap[K, V] = AMap.zero()
}

object AMap {

  implicit def aMapGroup[K, V <: AType](implicit vAbelian: Group[V]): Group[AMap[K, V]] = AbelianAMap(vAbelian)

  type Abl[T] = AMap[T, AInteger]

  type ABag[T] = AMap[T, AInteger]

  // TODO: Rename to amap

  //def amap[K, V <: AType](x: Iterable[(K, V)]) = AMap(x.filter(!_._2.isZero).toMap)

  def amap[K, V <: AType](x: Map[K, V]) = AMap(x.filter(!_._2.isZero))

  def amap[K, V <: AType](k: K, v: V): AMap[K, V] = if (v.isZero) AMap.zero[K, V]() else AMap(Map(k -> v))

  def abag[T](seq: Seq[T]): ABag[T] = AMap(seq.groupBy(identity).map { case (k, v) => (k, AInteger(v.size)) })

  def abag[T](): ABag[T] = AMap[T, AInteger](Map())

  def abl[T](v: T): Abl[T] = AMap(Map(v -> AInteger(1)))

  // TODO: rename.
  def zero[K, V <: AType]() = AMap(Map[K, V]())

  //  def mapKeys[K1, K2, V <: AType](m: AMap[K1, V])(f: K1 => K2)(implicit abl: Group[V]): AMap[K2, V] =
  //    AMap(m.value.toSeq.groupBy { case (k, _) => f(k) }
  //      .map { case (k, vs) => (k, vs.map(_._2).fold(abl.zero)(abl.merge)) }
  //      .filter(_._2 != abl.zero))

  implicit class ABagsProvide2[T](x: ABag[T]) {
    def count: Int = x.mapValues { case (_, v) => v }.toInt

    def toSeq: Seq[T] = x.value.toSeq.flatMap { case (t, AInteger(count)) => Seq.fill(count)(t) }

  }

  implicit class ABagsWithIntProvide2[T](x: ABag[Int]) {
    def sum: Int = x.value.map { case (x, y) => x * y.toInt }.sum
  }

  implicit class ABagsWithDoubleProvide2[T](x: ABag[Double]) {
    def sum: Double = x.value.map { case (x, y) => x * y.toInt.toDouble }.sum
  }

}

case class AMap[K, V <: AType](var value: Map[K, V]) extends AType {

  //assert(value.forall(!_._2.isZero))

  def mapValues[V2 <: AType](f: (K, V) => V2)(implicit abl: Group[V2]): V2 =
    value.toSeq.map(x => f(x._1, x._2)).reduceOption(abl.merge).getOrElse(abl.zero)

  //  def mapValues[V2<: AType](f: V => V2)(implicit abl: Group[V2]) =
  //    AMap(value.map { case (k, v) => (k, f(v)) }.filter(_._2 != abl.zero))

  def map[K2](f: K => K2)(implicit abl: Group[V]) =
    AMap(value.toSeq.groupBy { case (k, _) => f(k) }.map { case (k, v) => (k, v.map(_._2).reduce(abl.merge)) }.filter(!_._2.isZero))

  def reduceValues(f: ((K, V), (K, V)) => (K, V)): (K, V) = value.toSeq.reduce(f)

  def filter(f: K => Boolean) = AMap(value.filter(x => f(x._1)))

  def filterValues(f: (K, V) => Boolean) = AMap(value.filter(f.tupled))

  def apply(k: K): V = value(k)

  def get(k: K): Option[V] = value.get(k)

  def getOrElse(k: K, default: => V): V = value.getOrElse(k, default)

  def updated(k: K, v: V): AMap[K, V] =
    if (v.isZero) AMap(value - k)
    else AMap(value.updated(k, v))

  def keys(): Set[K] = value.keySet

  override def pretty(): String = {
    value.map { case (k, v) => k.toString +
      " = " + v.toString
    }.reduceOption(_ + System.getProperty("line.separator") + _).getOrElse("") + System.getProperty("line.separator")
  }

  override def ~=(other: AType): Boolean = {
    if (!other.isInstanceOf[AMap[K, V]]) return false
    val o = other.asInstanceOf[AMap[K, V]]

    // TODO: Not sure why this can not be detected.
    if (this == other) return true

    if (this.value.isEmpty && o.value.isEmpty) return true

    // Not zero valued entries.
    val a = this.value.filter { case (_, v) => !v.isApproxZero }
    val b = o.value.filter { case (_, v) => !v.isApproxZero }

    if (a.keySet.size != b.keySet.size) return false

    // Get an unique key alignment.
    val (remaining, alignment) = a.keySet.foldLeft((b.keySet, Map[K, K]())) { case ((bks, ms), ak) =>
      bks.find {
        case bk: AType =>
          ak.asInstanceOf[AType] ~= bk
        case x => x == ak
      } match {
        case Some(bk) => (bks.diff(Set(bk)), ms.updated(ak, bk))
        case None => (bks, ms)
      }
    }

    if (remaining.nonEmpty) return false

    // Compare the existing values by key.
    alignment.map { case (k1, k2) => (a.get(k1), b.get(k2)) }.forall {
      case (Some(l), Some(r)) => l ~= r
      case (None, Some(r)) => false
      case (Some(l), None) => false
    }
  }

  override def isZero: Boolean = AMap.zero() == this

  override def isApproxZero: Boolean = {
    value.forall {
      case (k, v) =>
        val keyIsApproxZero = k.isInstanceOf[AType] && k.asInstanceOf[AType].isApproxZero
        val valueIsApproxZero = v.isApproxZero

        keyIsApproxZero || valueIsApproxZero
    }
  }

  /**
    * Length of the delta in terms of effort needed to conduct it.
    */
  override def dlength(): Double = value.toSeq.map(_._2.dlength()).map(Math.abs).sum
}
