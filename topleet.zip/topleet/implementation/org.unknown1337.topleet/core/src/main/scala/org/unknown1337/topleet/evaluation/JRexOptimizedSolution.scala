package org.unknown1337.topleet.evaluation

import java.io.{File, FileReader}

import com.google.common.base.Charsets
import org.apache.commons.csv.CSVFormat
import org.apache.commons.lang.exception.ExceptionUtils
import org.apache.spark.rdd.RDD
import org.unknown1337.topleet.SparkUtils2
import org.unknown1337.topleet.engines.IncixRDDEngine
import org.unknown1337.topleet.evaluation.lisaparser.{AntlrJavaParser, JavaParser}
import org.unknown1337.topleet.ura.Gitobject
import org.unknown1337.topleet.utils.{Isolator, JSONLDPrinter}
import collection.JavaConverters._

object JRexOptimizedSolution {

  def main(args: Array[String]): Unit = {

    val repositories = CSVFormat.DEFAULT.withFirstRecordAsHeader()
      .parse(new FileReader("data/topleet/topleets_modernes_leben.csv"))
      .asScala
      .map(_.toMap.asScala)

    for ((repository, index) <- repositories.zipWithIndex) {
      val append = index != 0
      val address = repository("address")
      println("----------- " + address + " -----------")

      val timeout = 60 * 60 * 12

      var ncommits = 0
      val out = try {
        ncommits = Gitobject(address).commits().size
        val partitions = Math.max(32, ncommits / 100)
        println("Commits: " + ncommits)
          println("Partitions " + partitions)

        val (time, memory) = Isolator.tmprof( () => run(address, partitions, append), timeout = timeout)
        Map("time[ns]" -> time.toString,
          "memory" -> memory.toString)
      }
      catch {
        case x: Throwable => {
          x.printStackTrace()
          Map("exception" -> ExceptionUtils.getStackTrace(x))
        }
      }

      val printer = JSONLDPrinter.create(new File("data/topleet/j_rex_solution_optimized.json"), Charsets.UTF_8, append)
      printer.printRecord(out ++ repository ++ Map("n2commits" -> ncommits.toString))
      printer.close()
    }
  }

  def run(address: String, partitions: Int, append: Boolean): Unit = {

    val git = Gitobject(address)
    val spark = SparkUtils2.spark()
    val raw = git.commits()
    val index = raw.sortBy(x => git.time(x)).zipWithIndex.map(_.swap).toMap
    val history = index.toSeq.sortBy(_._1).map(_._1)

    val commits = spark.parallelize(history.zip(history.drop(1)), partitions)

    type Commit = Int
    type Resource = String
    type Path = String
    type MCC = Int

    def analysis(blob: Resource): MCC = AntlrJavaParser.computeMCC(new Gitobject(address).openStream(blob))

    def diff(commit1: Int, commit2: Int): Seq[(Commit, Path, Resource)] =
      Gitobject(address).diff(Some(index(commit1)), Some(index(commit2)))
        .collect { case (path, _, Some(blob)) => (commit2, path, blob) }

    // Input in terms of changed blob at paths and commits.
    val fileRevisions: RDD[(Commit, Path, Resource)] = commits
      .flatMap { case (c1, c2) => diff(c1, c2) }

    // History of java files distributed by path.
    val grouped: RDD[(Path, Iterable[(Commit, Path, Resource)])] = fileRevisions
      .filter { case (_, path, _) => path.endsWith(".java") }
      .groupBy { case (_, path, _) => path }

    // History analysis for each path.
    val changeData: RDD[(Commit, Path, MCC)] = grouped
      .flatMap { case (path, iterable) =>
        // Metric computation and sorting along commits.
        val history: Iterable[(Commit, MCC)] = iterable.toSeq
          .map { case (commit, _, blob) => (commit, analysis(blob)) }
          .sortBy { case (commit, _) => commit }

        // Compute the difference between succeeding revisions.
        history.zip(history.drop(1)).map {
          case ((_, mcc1), (commit2, mcc2)) => (commit2, path, mcc2 - mcc1)
        }
      }

    val printer = JSONLDPrinter.create(new File("data/topleet/j_rex_solution_optimized_output.json"), Charsets.UTF_8, append)
    for ((x, path, mcc) <- changeData.collect())
      printer.printRecord(Map("commit" -> index(x), "path" -> path, "change" -> mcc.toString))
    printer.close()

  }
}
