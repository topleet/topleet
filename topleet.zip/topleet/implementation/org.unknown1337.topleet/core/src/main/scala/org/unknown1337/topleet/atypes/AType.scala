package org.unknown1337.topleet.atypes

trait AType {
  def ~=(other: AType): Boolean

  def isZero:Boolean

  def isApproxZero: Boolean

  def pretty(): String = this.toString

  /**
    * Length of the delta in terms of effort needed to conduct it.
    */
  def dlength(): Double
}