package org.unknown1337.topleet.evaluation

import java.io.{File, FileReader}

import com.google.common.base.Charsets
import org.apache.commons.csv.CSVFormat
import org.apache.commons.lang.exception.ExceptionUtils
import org.apache.spark.rdd.RDD
import org.unknown1337.topleet.SparkUtils2
import collection.JavaConverters._
import org.unknown1337.topleet.evaluation.lisaparser.AntlrJavaParser
import org.unknown1337.topleet.ura.Gitobject
import org.unknown1337.topleet.utils.{Isolator, JSONLDPrinter}

import scala.util.Random


object JRexSolution {

  def main(args: Array[String]): Unit = {

    val repositories = CSVFormat.DEFAULT.withFirstRecordAsHeader()
      .parse(new FileReader("data/topleet/topleets_modernes_leben.csv"))
      .asScala
      .map(_.toMap.asScala)

    for ((repository, index) <- repositories.zipWithIndex) {
      val append = index != 0
      val address = repository("address")
      println("----------- " + address + " -----------")

      val timeout = 60 * 60 * 12

      var ncommits = 0
      val out = try {
        ncommits = Gitobject(address).commits().size
        val partitions = Math.max(32, ncommits / 100)
        println("Commits: " + ncommits)
        println("Partitions " + partitions)

        val (time, memory) = Isolator.tmprof(() => run(address, partitions, append), timeout = timeout)
        Map("time[ns]" -> time.toString,
          "memory" -> memory.toString)
      }
      catch {
        case x: Throwable => {
          x.printStackTrace()
          Map("exception" -> ExceptionUtils.getStackTrace(x))
        }
      }

      val printer = JSONLDPrinter.create(new File("data/topleet/j_rex_solution.json"), Charsets.UTF_8, append)
      printer.printRecord(out ++ repository ++ Map("n2commits" -> ncommits.toString))
      printer.close()
    }
  }

  def run(address: String, partitions: Int, append: Boolean): Unit = {
    val spark = SparkUtils2.spark()

    val git = Gitobject(address)

    println("commits " + git.commits().size)

    val raw = git.commits()

    val index = raw.sortBy(x => git.time(x)).zipWithIndex.map(_.swap).toMap
    val history = index.toSeq.sortBy(_._1).map(_._1)

    val commits = spark.parallelize(history, partitions)

    type Commit = Int
    type Resource = String
    type Path = String
    type MCC = Int

    def computeMCC(blob: Resource): MCC = AntlrJavaParser.computeMCC(new Gitobject(address).openStream(blob))

    def tree(commit: Int): Seq[(Commit, Path, Resource)] =
      Gitobject(address).tree(index(commit)).map { case (path, resource) => (commit, path, resource) }.toSeq

    // Input in terms of changed blob at paths and commits.
    val resources: RDD[(Commit, Path, Resource)] = commits
      .flatMap { c => tree(c) }

    // History of java files distributed by path.
    val grouped: RDD[(Path, Iterable[(Commit, Path, Resource)])] = resources
      .filter { case (commit, path, resource) => path.endsWith(".java") }
      .groupBy { case (commit, path, resource) => path }

    // History analysis for each path.
    val changeData: RDD[(Commit, Path, MCC)] = grouped
      .flatMap { case (path, iterable) =>
        // Metric computation and sorting along commits.
        val history: Iterable[(Commit, MCC)] = iterable.toSeq
          .map { case (commit, _, blob) => (commit, computeMCC(blob)) }
          .sortBy { case (commit, metric) => commit }

        // Compute the difference between succeeding revisions.
        history.zip(history.drop(1)).map {
          case ((commit1, mcc1), (commit2, mcc2)) => (commit2, path, mcc2 - mcc1)
        }
      }


    val printer = JSONLDPrinter.create(new File("data/topleet/j_rex_solution_output.json"), Charsets.UTF_8, append)
    for ((x, path, mcc) <- changeData.collect())
      printer.printRecord(Map("commit" -> index(x), "path" -> path, "change" -> mcc.toString))
    printer.close()
  }
}
