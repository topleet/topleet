package org.unknown1337.topleet.ura

import java.io.{File, RandomAccessFile}
import java.nio.channels.OverlappingFileLockException
import java.nio.charset.Charset

import com.google.common.cache._
import org.apache.commons.io.IOUtils
import org.eclipse.jgit.api.{BlameCommand, Git}
import org.eclipse.jgit.diff.DiffEntry.ChangeType
import org.eclipse.jgit.lib._
import org.eclipse.jgit.revwalk.RevWalk
import org.eclipse.jgit.storage.file.FileRepositoryBuilder
import org.eclipse.jgit.treewalk.{CanonicalTreeParser, TreeWalk}
import org.unknown1337.topleet.Configuration

import scala.collection.JavaConverters._
import scala.collection.mutable

object Gitobject {
  val buffer = new ThreadLocal[LoadingCache[String, Repository]]() {
    override def initialValue(): LoadingCache[String, Repository] = CacheBuilder.newBuilder()
      .maximumSize(1)
      .removalListener(new RemovalListener[String, Repository] {
        override def onRemoval(notification: RemovalNotification[String, Repository]): Unit = {
          unmirror(notification.getValue)
        }
      })
      .build(
        new CacheLoader[String, Repository] {
          override def load(key: String): Repository = mirror(key)
        })
  }

  def createGitClone(address: String): Unit = {
    if (!folderForGitClone(address).exists())
      try {
        folderForGitClone(address).mkdirs()
        lockFile(address).createNewFile()

        val file = new RandomAccessFile(lockFile(address), "rw");
        try {
          val lock = file.getChannel.tryLock()
          if (lock != null) {
            val git = Git.cloneRepository
              .setBare(true)
              .setGitDir(bareFolder(address))
              .setURI("https://github.com/" + address + ".git")
              .call

            git.getRepository.close()
            git.close()
            lock.release();
            readyFile(address).createNewFile()
          }
        } catch {
          case _: OverlappingFileLockException =>
        }
        finally {
          file.close()
        }
      }
  }

  def folderForGitClone(address: String) = new File(Configuration.get("temp") + "/gitrepos/" + "/" + address)

  def lockFile(address: String) = new File(folderForGitClone(address), "lock")

  def readyFile(address: String) = new File(folderForGitClone(address), "ready")

  def bareFolder(address: String) = new File(folderForGitClone(address), "bare")

  def waitForClone(address: String): Unit = {
    while (!readyFile(address).exists()) {
      Thread.sleep(1000)
    }
  }

  def mirror(address: String): Repository = {
    createGitClone(address)
    waitForClone(address)
    //val git = Git.init.setBare(true).setGitDir(bareFolder()).call()
    val repositoryBuilder = new FileRepositoryBuilder();
    repositoryBuilder.setMustExist(true)
    repositoryBuilder.setGitDir(bareFolder(address));

    val repository: Repository = repositoryBuilder.build();
    // git.remoteAdd()
    //    val revWalk: RevWalk = new RevWalk(repository)
    //    val objectReader: ObjectReader = repository.newObjectReader()
    //    Some((repository, revWalk, objectReader))
    repository
  }

  def unmirror(t: Repository): Unit = {
    t.close()
  }


  val repositories = Seq(
    "eclipse/eclipse-collections",
    "linkedin/pinot",
    "linkedin/rest.li",
    "eishay/jvm-serializers",
    "nhaarman/ListViewAnimations",
    "tinkerpop/blueprints",
    "tbruyelle/RxPermissions",
    "Netflix/Hystrix",
    "kdn251/Interviews",
    "citerus/dddsample-core",
    "libgdx/libgdx",
    "openhab/openhab",
    "google/physical-web",
    "gwtproject/gwt",
    "google/iosched",
    "nickbutcher/plaid")

  def main(args: Array[String]): Unit = {
    for (r <- repositories; x <- 0 to 2) {
      new Thread() {
        override def run(): Unit = {
          println("r")
          println(Gitobject(r).commits().size)
        }
      }.start()
    }
  }
}

//object Gitobject {
//  def main(args: Array[String]): Unit = {
//
//    val address = "square/keywhiz"
//    val location = new File("temp/" + address)
//
//    if (!location.exists)
//      Git.cloneRepository
//        .setBare(true)
//        .setGitDir(location)
//        .setURI("https://github.com/" + address)
//        .call
//
//    val git = Git.init.setBare(true).setGitDir(location).call()
//    val repository = git.getRepository
//
//    val head = new RevWalk(repository).parseCommit(repository.resolve(Constants.HEAD))
//    val treeWalk = new TreeWalk(repository)
//    treeWalk.addTree(head.getTree)
//    treeWalk.setRecursive(true)
//
//    val contents = mutable.HashSet[(String, ObjectId)]()
//    while (treeWalk.next())
//      contents.add((treeWalk.getPathString, treeWalk.getObjectId(0)))
//
//
//    for ((path, objectId) <- contents) {
//      println("======================================================")
//      println(path)
//      println("======================================================")
//      val content = IOUtils.toString(repository.open(objectId).openStream(), Charset.forName("UTF-8"))
//
//      println(content.take(100) + "...")
//    }
//  }
//}

case class Gitobject(address: String) { //extends BufferThread[String, Repository, Gitobject](address) {

  private def canonicalTreeParser(id: ObjectId): CanonicalTreeParser = {
    val canonicalTreeParser = new CanonicalTreeParser()
    canonicalTreeParser.reset(repository().newObjectReader(), id)
    canonicalTreeParser
  }

  def repository(): Repository = Gitobject.buffer.get().get(address)

  // TODO: This has been wrong a long time. It needs to be created over and over again.
  //  def revWalk(): RevWalk = new RevWalk(repository())
  //
  //  def objectReader(): ObjectReader = apply()._3

  def parents(commit: String) =
    new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getParents.map(x => ObjectId.toString(x))

  def parentsCount(commit: String) =
    new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getParentCount

  def time(commit: String): Int = new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getCommitTime

  def comment(commit: String): String = new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getFullMessage

  def authorMail(commit: String): String = new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getAuthorIdent.getEmailAddress

  def authorName(commit: String): String = new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getAuthorIdent.getName

  def read(objectId: String, charset: Charset = Charset.forName("UTF-8")): String = IOUtils.toString(repository().open(ObjectId.fromString(objectId)).openStream(), charset)

  def lines(objectId: String, charset: Charset = Charset.forName("UTF-8")): Int = IOUtils.readLines(repository().open(ObjectId.fromString(objectId)).openStream(), charset).size

  def openStream(objectId: String): ObjectStream = repository().open(ObjectId.fromString(objectId)).openStream()

  //  /**
  //    * Note that this is now NOT filtered for any diff which is good (e.g., by rw.setTreeFilter(TreeFilter.ANY_DIFF)).
  //    */
  //  def headCommits(): Seq[String] = {
  //    val head = new RevWalk(repository()).parseCommit(repository().resolve(Constants.HEAD))
  //    val rw = new RevWalk(repository())
  //    rw.markStart(head)
  //    rw.iterator().asScala.toSeq.map(x => ObjectId.toString(x.getId))
  //  }

  /** *
    * Branaches are name like: refs/heads/chibicitiberiu-master-orig (for this repository) or refs/remotes/RayanFar/native-utils/master (for remote repositories).
    *
    * @param branches
    * @return
    */
  def commits(branches: Set[String] = Set()): Seq[String] = {
    val head = new RevWalk(repository()).parseCommit(repository().resolve(Constants.HEAD))
    val rw = new RevWalk(repository())
    rw.markStart(head)
    //        rw.sort(RevSort.REVERSE)
    rw.iterator().asScala.toSeq.map(x => ObjectId.toString(x.getId))
    //
    //    //    val remotes = branches.filter(x => x.startsWith("refs/remotes"))
    //    //      .map(_.substring(13))
    //    //      .map(x => x.substring(0, x.indexOf("/", x.indexOf("/") + 1)))
    //    //
    //    //    fetchOrigin()
    //    //    fetchRemotes(remotes)
    //
    //    val rw = new RevWalk(repository())
    //
    //    val refdb = repository().getRefDatabase.getRefs().asScala
    //
    //    for (ref <- refdb if branches.contains(ref.getName) || ref.getName == "HEAD")
    //      rw.markStart(rw.parseCommit(ref.getObjectId))
    //
    //    rw.iterator().asScala.toSeq.map(x => ObjectId.toString(x.getId))
  }

  /**
    * @return Return path objectId tuples.
    */
  def tree(commit: String, suffix: String = ""): Set[(String, String)] = {
    val suffixBytes = suffix.getBytes
    val treeWalk = new TreeWalk(repository())
    treeWalk.addTree(new RevWalk(repository()).parseCommit(ObjectId.fromString(commit)).getTree)
    treeWalk.setRecursive(true)

    val result = mutable.HashSet[(String, String)]()
    while (treeWalk.next()) {
      if (suffix == "" || treeWalk.isPathSuffix(suffixBytes, suffixBytes.length))
        result.add((treeWalk.getPathString, ObjectId.toString(treeWalk.getObjectId(0))))
    }

    result.toSet
  }

  def blame(path: String, objectId: String): Map[(String, String), Int] = {
    val blamer = new BlameCommand(repository)
    blamer.setFilePath(path)
    blamer.setFollowFileRenames(true)

    val blame = blamer.call

    if (blame == null) return Map()

    val lineAuthors = for (i <- 0 until blame.getResultContents.size())
      yield (blame.getSourceCommit(i).getAuthorIdent.getName, blame.getSourceCommit(i).getAuthorIdent.getEmailAddress)

    lineAuthors.map(x => (x, 1)).groupBy(_._1).map { case (author, group) => (author, group.map(_._2).sum) }
  }

  def diff(last: Option[String], current: Option[String]): Seq[(String, Option[String], Option[String])] = {
    (last, current) match {
      case (Some(l), Some(c)) =>
        new Git(repository()).diff().setShowNameAndStatusOnly(true)
          .setOldTree(canonicalTreeParser(new RevWalk(repository()).parseCommit(ObjectId.fromString(l)).getTree.getId))
          .setNewTree(canonicalTreeParser(new RevWalk(repository()).parseCommit(ObjectId.fromString(c)).getTree.getId))
          .call().asScala.map {
          diff =>
            (diff.getChangeType match {
              case ChangeType.DELETE => diff.getOldPath
              case _ => diff.getNewPath
            },
              diff.getChangeType match {
                case ChangeType.ADD => None
                case _ => Some(ObjectId.toString(diff.getOldId.toObjectId))
              },
              diff.getChangeType match {
                case ChangeType.DELETE => None
                case _ => Some(ObjectId.toString(diff.getNewId.toObjectId))
              })
        }
      case (None, Some(c)) => tree(c).map { case (path, objectId) => (path, None, Some(objectId)) }.toSeq
      case (Some(l), None) => tree(l).map { case (path, objectId) => (path, Some(objectId), None) }.toSeq
      case (None, None) => Seq()
    }
  }

  //
  //  def fetchOrigin(): Unit = {
  //    try {
  //      git().fetch().setRemote("origin").call()
  //    } catch {
  //      case _: Throwable => println("Fetch not possible to fetch origin")
  //    }
  //  }
  //
  //  def fetchRemotes(remotes: Set[String]): Unit = {
  //
  //    val availableRemotes = git().remoteList().call().asScala.map(_.getName).toSet
  //
  //    // Add remotes missing.
  //    for (remote <- remotes.diff(availableRemotes))
  //      git().remoteAdd().setName(remote).setUri(new URIish("https://github.com/" + remote)).call()
  //
  //    for (remote <- git().remoteList().call().asScala if remotes.contains(remote.getName)) {
  //      try {
  //        git().fetch().setRemote(remote.getName).setRefSpecs(remote.getFetchRefSpecs).call()
  //      } catch {
  //        case _: Throwable => println("Fetch not possible (" + remote + ")")
  //      }
  //    }
  //  }

}
