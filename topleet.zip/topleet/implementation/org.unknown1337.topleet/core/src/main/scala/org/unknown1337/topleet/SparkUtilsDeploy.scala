package org.unknown1337.topleet

import org.apache.spark.{SparkConf, SparkContext}
import org.eclipse.jgit.lib.ObjectId
import org.unknown1337.topleet.atypes.{ADouble, AInteger, AMap, ATuple}

import org.unknown1337.topleet.libs.{GitResource, SHA}

object SparkUtilsDeploy {

  //  Logger.getLogger("org.apache").setLevel(Level.OFF)
  //  Logger.getLogger("akka").setLevel(Level.OFF)

  def spark(): SparkContext = {
    new SparkContext(new SparkConf()
      .setAppName("Main")
      .setMaster("local[" + 16 + "]")
      .set("spark.local.dir", Configuration.get("temp") + "/spark_tmp")
      .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
      .set("spark.kryo.registrationRequired", "false")
      .registerKryoClasses(Array(
        classOf[ObjectId],
        classOf[AInteger],
        classOf[ADouble],
        classOf[AMap[_, _]],
        classOf[ATuple[_,_]],
        classOf[SHA],
        classOf[GitResource],
        classOf[Tuple2[_,_]],
        classOf[scala.collection.mutable.WrappedArray.ofRef[_]],
        Class.forName("org.apache.spark.sql.execution.datasources.FileFormatWriter$WriteTaskResult"),
        Class.forName("scala.collection.immutable.MapLike$ImmutableDefaultKeySet"),
        Class.forName("org.apache.spark.internal.io.FileCommitProtocol$TaskCommitMessage"),
        Class.forName("scala.collection.immutable.HashMap$EmptyHashMap$"),
        Class.forName("scala.collection.immutable.HashMap$HashMap1"),

        Class.forName("scala.collection.immutable.Set$EmptySet$")
      ))
    )
  }

}
