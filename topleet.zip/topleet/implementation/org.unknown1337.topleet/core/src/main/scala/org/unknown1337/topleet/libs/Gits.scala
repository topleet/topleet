package org.unknown1337.topleet.libs

import java.io.{File, InputStream}

import com.google.common.base.Charsets
import com.google.gson.JsonElement
import org.unknown1337.topleet.atypes.AMap._
import org.unknown1337.topleet.atypes._
import org.unknown1337.topleet.engines.Engine
import org.unknown1337.topleet.ura.Gitobject
import org.unknown1337.topleet.utils.{JSONLDReader, Utils}

import collection.JavaConverters._


case class SHA(address: String, sha: Option[String]) {

  def link() = s"https://github.com/$address/commit/${sha.getOrElse("")}"

  def browse(pressToContinue: Boolean = true): Unit = {
    Runtime.getRuntime.exec("rundll32 url.dll,FileProtocolHandler " + link())
    if (pressToContinue) {
      println("Press any key to continue")
      System.in.read()
    }
  }

}

case class GitResource(address: String, objectId: String) extends Resource {
  override def read(charset: String): String = Gitobject(address).read(objectId, org.apache.commons.io.Charsets.toCharset(charset))

  override def inputStream(): InputStream = Gitobject(address).openStream(objectId)
}

trait Gits extends Resources {

  type Address = String
  type Email = String
  type Name = String

  val engine: Engine

  import engine._


  def gitbatch(addresses: Set[Address]): engine.PairLeet[SHA, SHA, AInteger] = {
    val res = for (address <- addresses) yield {

      val git = Gitobject(address)

      // Data needed all over the analysis.
      val commits = git.commits()

      // Vertex of this project.
      val vertex = Set(None) ++ commits.map(Some(_))

      // Edges of the project.
      val edges = vertex.flatMap {
        case None => Seq[(Option[String], Option[String])]()
        case Some(x) if git.parentsCount(x) == 0 => Seq((None, Some(x)))
        case Some(x) => git.parents(x).map(y => (Some(y), Some(x)))
      }

      (
        vertex.map(x => (SHA(address, x), abl(SHA(address, x)))),
        edges.map { case (n1, n2) => (SHA(address, n1), SHA(address, n2)) })
    }

    val (nodes, edges) = res.reduce[(Set[(SHA, AMap.Abl[SHA])], Set[(SHA, SHA)])]{
      case ((l1, r1), (l2, r2)) => (l1 ++ l2, r1 ++ r2)
    }

    // Create topology with sha.
    engine.createIx(edges, nodes.toMap)
  }


  def git(address: Address, branches: Set[String] = Set()): engine.PairLeet[SHA, SHA, AInteger] = {
    val git = Gitobject(address)

    // Data needed all over the analysis.
    val commits = git.commits(branches)

    // Vertex of this project.
    val vertex = Set(None) ++ commits.map(Some(_))

    // Edges of the project.
    val edges = vertex.flatMap {
      case None => Seq[(Option[String], Option[String])]()
      case Some(x) if git.parentsCount(x) == 0 => Seq((None, Some(x)))
      case Some(x) => git.parents(x).map(y => (Some(y), Some(x)))
    }

    // Create topology with sha.
    engine.createIx(edges.map { case (n1, n2) => (SHA(address, n1), SHA(address, n2)) },
      vertex.map(x => (SHA(address, x), abl(SHA(address, x)))).toMap)
  }

  implicit class GitsProvide(@transient l: engine.PairLeet[SHA, SHA, AInteger]) extends Serializable {
    // TODO: There may be some issue with time smaller that the previous commit.
    def time(): engine.PairLeet[SHA, Int, AInteger] = {
      l.map {
        case SHA(address, Some(sha)) => Gitobject(address).time(sha)
        case SHA(_, None) => -1
      }
    }

    def head(): engine.PairLeet[SHA, Boolean, AInteger] = {
      val heads = engine.nodesIx(l).map(_.address).flatMap(address => Gitobject(address).commits())

      l.map { case SHA(address, sha) => sha.exists(x => heads(x)) }
    }

    def timeline(): Seq[SHA] = {
      val times = l
        .time()
        .values()
        .map { case (n, k, _) => (n, -k) }.toMap

      Utils.tsOrdering(engine.edgesIx(l), engine.nodesIx(l))(Ordering.by(times)).toSeq
    }

    def fstline(): Seq[SHA] = {
      val leafs = engine.leafsIx(l)
      val edges = engine.edgesIx(l)

      l.timeline().scanRight(leafs.head) {
        case x if edges(x) => x._1
        case x if !edges(x) => x._2
      }.distinct
    }

    def authors(): engine.PairLeet[SHA, (Name, Email), AInteger] = {
      l.filter(_.sha.isDefined)
        .map { case SHA(address, Some(sha)) => (Gitobject(address).authorName(sha), Gitobject(address).authorMail(sha)) }
    }

    def messages(): engine.PairLeet[SHA, String, AInteger] = {
      l.filter(_.sha.isDefined)
        .map { case SHA(address, Some(sha)) => Gitobject(address).comment(sha) }
    }

    def resources(): engine.PairLeet[SHA, (Path, Resource), AInteger] = {
      l.tmapHom { shas =>
        def lasts = shas.value.toSeq.flatMap {
          case (sha, AInteger(count)) if count < 0 => Seq.fill(-count)(sha)
          case _ => Seq[SHA]()
        }

        def nexts = shas.value.toSeq.flatMap {
          case (sha, AInteger(count)) if count > 0 => Seq.fill(count)(sha)
          case _ => Seq[SHA]()
        }

        // Pairs that can be diffed.
        val pairs: Seq[(SHA, SHA)] = lasts.zipAll(nexts, SHA("", None), SHA("", None))

        val diffs = pairs.flatMap {
          case (SHA(address, Some(sha1)), SHA(_, Some(sha2))) => Gitobject(address).diff(Some(sha1), Some(sha2)).map(x => (address, x))
          case (SHA(address, Some(sha1)), SHA(_, None)) => Gitobject(address).diff(Some(sha1), None).map(x => (address, x))
          case (SHA(_, None), SHA(address, Some(sha2))) => Gitobject(address).diff(None, Some(sha2)).map(x => (address, x))
          case (SHA(_, None), SHA(_, None)) => Seq()
        }

        val adds = diffs.collect { case (address, (path, _, Some(res))) => (path, GitResource(address, res).asInstanceOf[Resource]) }

        val removes = diffs.collect { case (address, (path, Some(res), _)) => (path, GitResource(address, res).asInstanceOf[Resource]) }

        val abl = AMap.aMapGroup[(Path, Resource), AInteger](AInteger.aIntegerGroup)
        abl.merge(abl.inverse(abag(removes)), abag(adds))
      }
    }
  }

}
