//package org.unknown1337.topleet.utils
//
//import java.io.File
//
//import com.google.common.base.Charsets
//import com.google.common.io.Files
//import org.apache.spark.HashPartitioner
//import org.apache.spark.RangePartitioner
//import org.apache.spark.graphx.PartitionStrategy.EdgePartition2D
//import org.apache.spark.graphx._
//import org.apache.spark.rdd.RDD
//
//import scala.reflect.ClassTag
//
//object GraphUtils {
//
//  def connectedComponents(edges: EdgeRDD[_]): RDD[(Long, Long)] =
//    connectedComponents(edges.map { case edge => (edge.srcId, edge.dstId) })
//
//  def connectedComponents(edges: RDD[(Long, Long)]): RDD[(Long, Long)] = {
//    val (result, didConverge, _) = ConnectedComponents.run(edges.map { case (a, b) => List(a, b) }, Int.MaxValue)
//    assert(didConverge)
//    result
//  }
//
//  def connectedComponents(cliques: RDD[List[Long]], maxIterationCount: Int): (RDD[(Long, Long)], Boolean, Int) =
//    ConnectedComponents.run(cliques, maxIterationCount)
//
//  /**
//    * Duplicates the graph along the gap. Partition is preserved duplication existing ones.
//    */
//  def mirror[VT, ED](graph: Graph[VT, ED], gap: Long)(implicit vtt: ClassTag[VT], edt: ClassTag[ED]): Graph[VT, ED] = {
//    //    val vertices = graph.vertices
//    //      .flatMap { case (id, vt) => Seq((id, vt), (gap + id, vt)) }
//    //    val edges = graph.edges
//    //      .flatMap { case edge => Seq(Edge(edge.srcId, edge.dstId, edge.attr), Edge(gap + edge.srcId, gap + edge.dstId, edge.attr)) }
//
//    val vertices = graph.vertices.union(graph.vertices.map { case (id, vt) => (gap + id, vt) })
//    val edges = graph.edges.union(graph.edges.map { case edge => Edge(gap + edge.srcId, gap + edge.dstId, edge.attr) })
//
//    Graph(vertices, edges, null.asInstanceOf[VT])
//  }
//
//  /**
//    * Replaces the node content by new content passed as a vertex rdd.
//    */
//  def replace[T, E, S](graph: Graph[S, E], x: VertexRDD[T], default: T)(implicit t: ClassTag[T], e: ClassTag[E], s: ClassTag[S]): Graph[T, E] =
//    graph.outerJoinVertices(x) { case v => v._3.getOrElse(default) }
//
//
//  def attachConnectedComponents[VT, ED](graph: Graph[VT, ED])(implicit t: ClassTag[VT], e: ClassTag[ED]): Graph[(VT, Long), ED] = {
//    graph.outerJoinVertices(connectedComponents(graph.edges)) {
//      case (_, vt, Some(cc)) => (vt, cc)
//      case (id, vt, None) => (vt, id)
//    }
//  }
//
//  /**
//    * Removes idle edges and merges the nodes that are connected only by such. Assumes that the edges are located in the
//    * same partition. The returned edges are not necessarily in the same partition.
//    */
//  def removeIdleEdges[VT, ED](graph: Graph[VT, (ED, Boolean)])(implicit t: ClassTag[VT], e: ClassTag[ED]): Graph[VT, ED] = {
//    val partitionedGraph = graph
//    //.partitionBy(EdgePartition2D)
//
//    val idleGraph = partitionedGraph.mapEdges(x => x.attr._2).groupEdges(_ && _).subgraph(epred = x => x.attr)
//
//    val notIdleGraph = partitionedGraph.subgraph(epred = x => !x.attr._2)
//
//    val vertex = connectedComponents(
//      notIdleGraph.edges.flatMap(e => Seq(List(e.dstId), List(e.srcId))) ++
//        idleGraph.edges.map(e => List(e.dstId, e.srcId)), Int.MaxValue)._1
//
//    val reducedEdges = notIdleGraph.outerJoinVertices(vertex) { case (_, vt, Some(component)) => (vt, component) }
//      .triplets.map(t => Edge(t.srcAttr._2, t.dstAttr._2, t.attr))
//
//    val out = Graph(partitionedGraph.vertices, reducedEdges, null.asInstanceOf[VT]).mapEdges(_.attr._1)
//
//    val mask = replace(out, out.degrees, 0).subgraph(vpred = {
//      case x => x._2 != 0
//    })
//
//    out.mask(mask)
//  }
//
////  def partitionIdRanges[VD, ED](graph: Graph[VD, ED], partitions: Int, i: Int)(implicit t: ClassTag[ED], e: ClassTag[VD]) = {
////    // TODO: This is promising
////    def cut(n:Long) = {
////      n >> i
////    }
////
////    val vertices = graph.vertices.map(v => cut(v._1) -> v)
////      .partitionBy(new HashPartitioner(partitions))
////      .map(_._2)
////
////    val edges = graph.edges.map(e => cut(Math.min(e.srcId, e.dstId)) -> e)
////      .partitionBy(new HashPartitioner(partitions))
////      .map(_._2)
////
////    Graph(vertices, edges)
////  }
//
//  /**
//    * Recursive splits the topology by the Int attribute of the edge. It returns multiple condensed topology with only
//  * the edge types of the group. Assumes that the edges are in the same partition.
//    */
//  def narrowOnAttribute[ED, VD](graph: Graph[VD, (ED, Int)], powpartitions: Int)(implicit t: ClassTag[ED], e: ClassTag[VD]): Graph[VD, ED] = {
//    val partitions = Math.pow(2,powpartitions).toInt
//    var current = graph.mapVertices { case (_, vd) => (vd, (Int.MinValue, Int.MaxValue)) }
//
//    // TODO: Needs to consolidate indices. Taking count induces sever errors.
//    val size = current.vertices.map(_._1).max() + 1
//    var gap = size
//
//    println("gap,iteration,e-partition,v-partition,time,vertexMean,edgeMean,nodes,edges,ccs")
//    for (i <- 0 to 31) {
//      val timeStart = System.currentTimeMillis()
//      // Mirror graph.
//
//      //      println("s = " + current.edges.count())
//      current = mirror(current, gap)
//      //     println("s = " + current.edges.count())
//
//      // Repartition graph according to vertex index.
//      def address(assignment: Int, location : Long) = {
//
//        val assignmentComponent = (assignment >>> (32 - Math.min(i, powpartitions))) << Math.max(powpartitions - i,0)
//
//        val locationComponent = ((location % size)* partitions / size).toInt >> i
//
//        val result = assignmentComponent + locationComponent
//
//        result
//      }
//
//      val vertices = current.vertices.map(v => address(v._2._2._1 + 1,v._1) -> v)
//        .partitionBy(new HashPartitioner(partitions))
//        .map(_._2)
//
//      val edges = current.edges.map(e => address(e.attr._2 ,Math.min(e.srcId, e.dstId)) -> e)
//        .partitionBy(new HashPartitioner(partitions))
//        .map(_._2)
//
//      current = Graph(vertices, edges)
//
//
//      println("eges in same: " + GraphUtils.edgesInSamePartition(current))
//
//
//
//      // Divide the range depending on the mirror side.
//      val xii = current.mapVertices {
//        case (id, (vd, (low, high))) if id < gap => (vd, (low, ((high.toLong + low.toLong) / 2).toInt))
//        case (id, (vd, (low, high))) if id >= gap => (vd, ((((high.toLong + low.toLong) / 2) + 1).toInt, high))
//      }
////      println("xii = " + xii.edges.count())
////      println("xii = " + xii.vertices.values.map(_._2).distinct().collect().toSeq)
//
//      // Run connected components removing idle edges depending on edge range.
//      val xiii = xii.mapTriplets { x =>
//        val (low, high) = x.srcAttr._2
//        val t = x.attr._2
//
//        (x.attr, !(low <= t && t <= high))
//      }
//
////      println("xiii = " + xiii.edges.count())
////      println("xiii(true) = " + xiii.edges.filter(_.attr._2).count())
//
//      val next = removeIdleEdges(xiii).persist()
//
////      val missing = current.edges.map(x => x.attr).distinct().subtract(next.edges.map(x => x.attr).distinct()).collect().toSeq
////      for(m <- missing){
////        println(m)
////      }
//
//
////      println("next = " + next.edges.count())
//
//
//      current.unpersist()
//      current = next
//      gap = gap * 2
//
//      // Diagnosis.
//      val timeEnd = System.currentTimeMillis()
//      val (vertexMean, edgeMean) = connectedComponentsDistribution(current)
//      val ccs = attachConnectedComponents(current)
//
//
//      println(gap + ","
//        + i + ","
//        + current.edges.partitions.length + ","
//        + current.vertices.partitions.length + ","
//        + ((timeEnd - timeStart) / 1000).toString + ","
//        + vertexMean + "," +
//        edgeMean + "," +
//        current.vertices.count() + "," +
//        current.edges.count() + "," +
//        ccs.vertices.map(_._2._2).distinct().count())
//    }
//
//    current.mapVertices { case v => v._2._1 }.mapEdges(e => e.attr._1)
//  }
//
//  /**
//    * Checks if all edges of the graph are in the same partition.
//    */
//  def edgesInSamePartition[VD, ED](graph: Graph[VD, ED])(implicit t: ClassTag[ED], e: ClassTag[VD]): Boolean = {
//    graph.edges.mapPartitionsWithIndex { case (pid, iterator) => iterator.map(e => (e.srcId, e.dstId) -> Set(pid)) }
//      .reduceByKey(_ ++ _).map { case (k, v) => v.size == 1 }.reduce(_ & _)
//  }
//
//  /**
//    * Returns the distribution of connected graph components over partitions in terms of edges and vertex.
//    */
//  def connectedComponentsDistribution[VD, ED](graph: Graph[VD, ED])(implicit t: ClassTag[ED], e: ClassTag[VD]): (Double, Double) = {
//    val cc = attachConnectedComponents(graph)
//    val vertexMean = cc.vertices.mapPartitionsWithIndex { case (partition, iterator) => iterator.map(v => v._2._2 -> Set(partition)) }.reduceByKey(_ ++ _).map(_._2.size).mean()
//
//    //val edgeMean = cc.triplets.mapPartitionsWithIndex { case (partition, iterator) => iterator.map(e => e.srcAttr._2 -> Set(partition)) }.reduceByKey(_ ++ _).map(_._2.size).mean()
//
//    val edgeMean = cc.edges.mapPartitionsWithIndex { case (partition, iterator) => iterator.map(e => e.srcId -> partition)}.join(cc.vertices.mapValues(_._2))
//      .map{case (_,(partition,cc)) => cc -> Set(partition)}.reduceByKey(_ ++ _).map(_._2.size).mean()
//
//
//    (vertexMean, edgeMean)
//  }
//
//  //
//  //  /**
//  //    *
//  //    * Compile this graph to svg using: 'dot -Tsvg graph.dot > graph.svg'
//  //    */
//  //  def groupedDot[G](graph: Graph[(Map[String, String], G), Map[String, String]])(implicit tg: ClassTag[G]) = {
//  //    def attributes(x: Map[String, String]) =
//  //      "[" + x.map { case (k, v) => k + "=\"" + v + "\"" }.reduceOption(_ + ", " + _).getOrElse("") + "]"
//  //
//  //
//  //    val nodes = graph.vertices.map { case (id, (as, group)) => (group, "nd" + id + attributes(as) + ";") }
//  //      .reduceByKey(_ + "\r\n" + _)
//  //      .map { case (group, nodes) => "subgraph cluster_" + group.toString + " {\n\t\tnode [style=filled];\n\t\tlabel = \" " + group.toString + "\";\n\t\tcolor=blue;\n\t\t " + nodes + " \n\t}" }
//  //      .reduce(_ + "\r\n" + _)
//  //
//  //    val edges = graph.edges.map { edge => "nd" + edge.srcId + " -> " + "nd" + edge.dstId + attributes(edge.attr) + ";" }
//  //      .reduce(_ + "\r\n" + _)
//  //
//  //    "digraph R {" + "\r\n" + nodes + "\r\n" + edges + "\r\n" + "}"
//  //  }
//
//  // TODO: Fill rest of functionality.
//  def createViewer[G](path: String, graph: Graph[(Seq[Map[String, String]], G), Seq[Map[String, String]]])(implicit tg: ClassTag[G]) = {
//
//    def merge(a: Map[String, String], b: Map[String, String]): Map[String, String] =
//      a.toSet.intersect(b.toSet).toMap
//
//
//    def toJson(x: Map[String, String]) = x
//      .map { case (x, y) => "\"" + x + "\"" + ":" + "\"" + y + "\"" }
//      .reduceOption(_ + " ," + _)
//      .getOrElse("")
//
//    val edgesWithId = graph.edges.zipWithIndex()
//
//    val nodesWithId = graph.vertices.map { case (id, v) => (v._1, id) }
//
//    val json = "{" + (edgesWithId.map {
//      case (edge, edgeid) => "\"e" + edgeid + "\":" + "[" +
//        edge.attr.map(y => "{" + toJson(y) + "}").reduceOption(_ + "," + _).getOrElse("") +
//        "]"
//    } ++ nodesWithId.map {
//      case (node, nodeid) => "\"n" + nodeid + "\":" + "[" +
//        node.map(y => "{" + toJson(y) + "}").reduceOption(_ + "," + _).getOrElse("") + "]"
//    }).reduce(_ + ",\r\n" + _) + "}"
//
//    def attributes(x: Map[String, String]) =
//      "[" + x.map { case (k, v) => k + "=\"" + v + "\"" }.reduceOption(_ + ", " + _).getOrElse("") + "]"
//
//    val nodes = graph
//      .vertices
//      .map { case (id, (as, group)) => (group, "nd" + id + attributes(Map("label" -> "", "id" -> ("n" + id)) ++ as.reduceOption(merge).getOrElse(Map())) + ";") }
//      .reduceByKey(_ + "\r\n" + _)
//      .map { case (group, nodes) => "subgraph cluster_" + group.toString + " {\n\t\tnode [style=filled];\n\t\tlabel = \" " + group.toString + "\";\n\t\tcolor=blue;\n\t\t " + nodes + " \n\t}" }
//      .reduce(_ + "\r\n" + _)
//
//    val edges = edgesWithId
//      .map { case (edge, edgeid) => "nd" + edge.srcId + " -> " + "nd" + edge.dstId + attributes(Map("id" -> ("e" + edgeid)) ++ edge.attr.reduceOption(merge).getOrElse(Map())) + ";" }
//      .reduce(_ + "\r\n" + _)
//
//    val dot = "digraph R {" + "\r\n" + nodes + "\r\n" + edges + "\r\n" + "}"
//
//    val filename = path.split("/").last
//
//    Files.createParentDirs(new File(path + ".json"))
//    Files.asCharSink(new File(path + ".json"), Charsets.UTF_8).write(json)
//    Files.asCharSink(new File(path + ".dot"), Charsets.UTF_8).write(dot)
//
//    Files.asCharSink(new File(path + ".html"), Charsets.UTF_8).write(Files.asCharSource(new File("core/src/main/resources/viewer/viewer.html"), Charsets.UTF_8).read()
//      .replaceAll("\"viewer.json\"", "\"" + filename + ".json\"")
//      .replaceAll("\"viewer.dot\"", "\"" + filename + ".dot\""))
//  }
//
//}
