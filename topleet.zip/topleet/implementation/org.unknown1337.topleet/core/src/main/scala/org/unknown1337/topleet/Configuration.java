package org.unknown1337.topleet;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class Configuration {

    private static Properties CONFIGURATION = new Properties();

    static {
        try {
            CONFIGURATION.load(new FileInputStream("config.properties"));
        } catch (IOException e) {
            System.out.println("WARNING - There is no 'config.properties' file in the projects root folder");
        }
    }

    public static String get(String key) {
        String result = CONFIGURATION.getProperty(key);
        if (result != null)
            return result;
        return key;
        //throw new RuntimeException("Missing get key: " + key);
    }

}
