//package org.unknown1337.topleet.engines
//
//import org.apache.spark.{HashPartitioner, Partitioner, SparkContext}
//import org.apache.spark.graphx._
//import org.unknown1337.topleet.applications.{AggregatingPackages, Delta, Parsing, TracingEntities}
//import org.unknown1337.topleet.{Group, SparkUtils2}
//import org.unknown1337.topleet.atypes.{ADouble, AMap, ATuple, AType}
//import org.unknown1337.topleet.libs._
//import org.unknown1337.topleet.utils.Utils
//
//import scala.collection.mutable
//import scala.reflect.{ClassTag => CT}
//
//// TODO: Dont use graph x :-(
//object IncGraphXEngine {
//  def main(args: Array[String]): Unit = {
//
//    //IncGraphXEngineApplication(DelegateCheckEngine(IncGraphXEngine(SparkUtils2.spark()), IncEngine())).execute()
//    //IncGraphXEngineApplication(IncEngine()).execute()
//    //IncGraphXEngineApplication(IncGraphXEngine(SparkUtils2.spark())).execute()
//
//    val application = new TracingEntities {
//      @transient
//      override val engine: Engine = IncGraphXEngine(SparkUtils2.spark()) //LogEngine()
//    }
//
//    val sha = application.git("jwtk/jjwt")
//    val out = application.application(sha)
//    println(application.engine.values(out))
//
//  }
//}
//
//case class IncGraphXEngineApplication(@transient engine: Engine) extends Base with Gits with GitViewers with Javas {
//
//  val charset: String = "UTF-8"
//
//  def execute(): Unit = {
//    val l = git("adamheinrich/native-utils")
//      .resources()
//      .filter { case (path, _) => path.endsWith(".java") }
//      .map(x => x._2)
//      .javaMethodLOC(charset)
//      .group()
//      .acDelta()
//      .sum()
//      //.flatten()
//    //      .map(_._2)
//    //      .sum()
//    //      .force()
//
//    l.runGraph(contract = false)
//  }
//
//}
//
//case class GXGraphPartitioner(partitioner: GXPartitoner) extends PartitionStrategy {
//  override def getPartition(src: VertexId, dst: VertexId, numParts: PartitionID): PartitionID = {
//    partitioner.getPartition(dst)
//  }
//}
//
//case class GXPartitoner(partitions: Int, size: Int) extends Partitioner {
//
//  override def numPartitions: Int = partitions
//
//  override def getPartition(key: Any): Int = key match {
//    case l: Long => ((l.toFloat / size.toFloat) * partitions.toFloat).toInt
//    case (_: Long, l2: Long) => ((l2.toFloat / size.toFloat) * partitions.toFloat).toInt
//    case (l: Long, _) => ((l.toFloat / size.toFloat) * partitions.toFloat).toInt
//  }
//}
//
//case class IncGraphXEngine(@transient spark: SparkContext) extends BaseEngine {
//  // TODO: This is to low and modulo conflicts with partitioning.
//  val partitions = 32
//
//  type Leet[N, V <: AType] = IncGraphXLeet[N, V]
//
//  val local: IncEngine = IncEngine(threshold = 24)
//
//  case class IncGraphXLeet[N, V <: AType](graph: Graph[(N, Option[V]), V], abelian: Group[V], nodes: Set[N], edges: Set[(N, N)])
//
//  def thin[N, V <: AType : CT](g: Graph[(N, V), Void], abl: Group[V], size: Int): Graph[(N, Option[V]), V] = {
//    g.mapTriplets(t => abl.diff(t.srcAttr._2, t.dstAttr._2))
//      .mapVertices {
//        case (id, (n, v)) if id % math.max(size / partitions, 1) == 0 => (n, Some(v))
//        case (id, (n, _)) if id % math.max(size / partitions, 1) != 0 => (n, None)
//      }
//  }
//
//  override def create[N: CT, V <: AType : CT](edges: Set[(N, N)], nodes: Map[N, V])(implicit vAbelian: Group[V]): IncGraphXLeet[N, V] = {
//    val partitioner = GXPartitoner(partitions, nodes.size)
//    val index = Utils.ts(edges, nodes.keySet).zipWithIndex.toMap
//    val rddVertex = spark.parallelize(nodes.toSeq, partitions).map { case (n, v) => (index(n).toLong, (n, v)) }
//      .partitionBy(partitioner)
//
//    val rddEdges = spark.parallelize(edges.toSeq, partitions).map { case (n1, n2) => ((index(n1).toLong, index(n2).toLong), null.asInstanceOf[Void]) }
//      //.partitionBy(partitioner)
//      .map { case ((n1, n2), v) => Edge(n1, n2, v) }
//
//    val graph = thin(Graph(rddVertex, rddEdges), vAbelian, nodes.size)
//    //.partitionBy(GXGraphPartitioner(partitioner))
//
//    // Graph first creating delta and the thinning out values stored absolute.
//    IncGraphXLeet(graph, vAbelian, nodes.keySet, edges)
//  }
//
//
//  def thick[N, V <: AType : CT](g: Graph[(N, Option[V]), V], abl: Group[V], size: Int): Graph[(N, V), Void] = {
//    // TODO: Just produce new nodes as edges stay the same.
//    def localThick(g: Graph[(N, Option[V]), V]) = {
//      val partitioner = GXPartitoner(partitions, size)
//
//      val vertices = g.vertices.partitionBy(partitioner)
//      val edges = g.edges.map(e => ((e.srcId, e.dstId), e.attr)).partitionBy(partitioner)
//      val newVertex = vertices.zipPartitions(edges, true) { case (vertexIterator, edgeIterator) =>
//        val vertexArray = vertexIterator.toArray
//        val edgeArray = edgeIterator.toArray
//        val checkpoints = vertexArray.collect { case (id, (_, Some(v))) => (id, v) }.toMap
//        //val edges = edgeArray.map(x => (x.srcId, x.dstId)).toSet
//        val delta = Utils.groupByKey(edgeArray.map { case ((src, dst), attr) => (src, (dst, attr)) }.toSeq ++ edgeArray.map { case ((src, dst), attr) => (dst, (src, abl.inverse(attr))) }.toSeq)
//        val paths = delta.map { case (k, v) => (k, v.map(_._1).toSet) }
//
//        val hops = Utils.dijkstra(paths, checkpoints.keySet)
//        val cache = mutable.Map[Long, Option[V]]()
//
//        // Assert
//        assert(edgeArray.map(_._1._2).toSet.diff(vertexArray.map(_._1).toSet).isEmpty)
//
//        // Recursive computation of the distance along the hops.
//        def compute(x: Long): Option[V] = x match {
//          case to if checkpoints.isDefinedAt(to) => Some(checkpoints(to))
//          case to if !hops.isDefinedAt(to) => None
//          case to => cache.getOrElseUpdate(to, {
//
//            // Find neighbour with lowest hop count.
//            delta(to).filter(x => hops.isDefinedAt(x._1)).sortBy(x => hops(x._1)).headOption match {
//              case Some((vid, d)) => Some(abl.merge(compute(vid).get, d))
//              case None => None
//            }
//          })
//        }
//
//        val out = vertexArray.toSeq.sortBy(x => hops.getOrElse(x._1, -1))
//          .map { case (vid, (n, _)) => (vid, (n, compute(vid))) }
//
//        out.toIterator
//      }
//
//      Graph(newVertex, g.edges, null)
//    }
//
//    // TODO First run a local pregel.
//
//    localThick(g).pregel(None.asInstanceOf[Option[V]], activeDirection = EdgeDirection.Either)(
//      { // Vertex Program
//        case (_, (n, v), None) => (n, v)
//        case (_, (n, None), Some(v)) =>
//          (n, Some(v))
//      },
//      // Send messages.
//      triplet => {
//        (triplet.srcId, triplet.srcAttr, triplet.dstId, triplet.dstAttr) match {
//          case (id, (_, None), _, (_, Some(v))) => Iterator((id, Some(abl.merge(v, abl.inverse(triplet.attr)))))
//          case (_, (_, Some(v)), id, (_, None)) => Iterator((id, Some(abl.merge(v, triplet.attr))))
//          case (_, (_, None), _, (_, None)) => Iterator.empty
//          case (_, (_, Some(_)), _, (_, Some(_))) => Iterator.empty
//        }
//      },
//      // Merge Message
//      { case (a, _) => a }
//    ).mapVertices { case (_, (n, Some(v))) => (n, v) }.mapEdges(_ => null)
//  }
//
//  override def tmapIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncGraphXLeet[N, AMap[K, V1]])(f: (K, V1) => V2)(implicit v2Abelian: Group[V2]): IncGraphXLeet[N, V2] = {
//    // TODO: A problem here is that the index can not efficiently be share.
//    // TODO: Solution can be first split and contract and that again local solution.
//    localIx(l)(x => local.tmapIx(x)(f))
//  }
//
//  override def acDeltaIx[N: CT, K: CT, V <: AType : CT](l: IncGraphXLeet[N, AMap[K, V]]): IncGraphXLeet[N, AMap[K, V]] = {
//    // TODO: I think contraction is the only good solution for acdelta.
//    implicit val abl = l.abelian
//    // Split edges and checkpoints into by k into the present ammount of partitions.
//    // Optionally do this recursively to on by mirror to prevent huge data.
//    // Apply the local IncEngine solutions on the partition.
//    localIx(l)(x => local.acDeltaIx(x))
//  }
//
//  override def collectDeltas[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): IncGraphXLeet[N, AMap[N, V]] = {
//    val partitioner = GXPartitoner(partitions, size(l))
//    val ablMap = AMap.aMapGroup[N, V](l.abelian)
//
//    val deltas = l.graph
//      .mapTriplets(x => (x.srcAttr._1, x.attr))
//      .collectEdges(EdgeDirection.In).map { case (vid, delta) =>
//      (vid, AMap(delta.map(x => x.attr).filter(!_._2.isZero).toMap))
//    }
//
//    val newNodes = l.graph.vertices.leftOuterJoin(deltas).map { case (vid, ((n, _), v)) => (vid, (n, v.getOrElse(ablMap.zero))) }
//      .partitionBy(partitioner)
//    val newEdges = l.graph.edges.map { e => Edge(e.srcId, e.dstId, null.asInstanceOf[Void]) }
//    val graph = Graph(newNodes, newEdges, null)
//    //.partitionBy(GXGraphPartitioner(partitioner))
//
//    IncGraphXLeet(thin(graph, ablMap, size(l)), ablMap, l.nodes, l.edges)
//  }
//
//  override def authorshipIx[N: CT, K: CT](l: IncGraphXLeet[N, AMap[K, ADouble]]): IncGraphXLeet[N, AMap[(N, K), ADouble]] =
//    localIx(l)(x => local.authorshipIx(x))
//
//  def localIx[N: CT, K: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncGraphXLeet[N, AMap[K, V1]])(f: local.Leet[N, AMap[K, V1]] => local.Leet[N, V2])(implicit v2Abelian: Group[V2]): IncGraphXLeet[N, V2] = {
//    val abl = l.abelian
//    val vertex = l.graph.vertices.flatMap {
//      case (vid, (n, Some(v))) =>
//        val present = v.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
//          .map { case (hash, vv) => (hash, (vid, (n, Some(AMap(vv))))) }
//        (0 until partitions).map(p => (p, present.getOrElse(p, (vid, (n, Some(abl.zero))))))
//      case (vid, (n, None)) =>
//        (0 until partitions).map(p => (p, (vid, (n, None))))
//    }.partitionBy(new HashPartitioner(partitions))
//
//
//    val edges = l.graph.edges.flatMap { e =>
//      val present = e.attr.value.groupBy { case (k, _) => Math.abs(k.hashCode()) % partitions }
//        .map { case (hash, vv) => (hash, ((e.srcId, e.dstId), AMap(vv))) }
//
//      (0 until partitions).map(p => (p, present.getOrElse(p, ((e.srcId, e.dstId), abl.zero))))
//    }.partitionBy(new HashPartitioner(partitions))
//
//
//    val results = vertex.zipPartitions(edges) { case (vertexIterator, edgeIterator) =>
//      val mvertexIterator = vertexIterator.toArray
//      val medgeIterator = edgeIterator.toArray
//      val vertex = mvertexIterator.map(_._2).toMap
//      val edges = medgeIterator.map(_._2).toMap
//
//      val nodes = vertex.map { case (_, (n, _)) => n }.toSet
//      val checkpoints = vertex.collect { case (_, (n, Some(v))) => (n, v) }
//      val delta = edges.map { case ((vid1, vid2), v) => ((vertex(vid1)._1, vertex(vid2)._1), v) }
//
//      val result = f(local.createIncEngineLeet(delta, nodes, checkpoints, abl))
//
//      // Map shit back.
//      val inv = vertex.map { case (vid, (n, _)) => (n, vid) }
//      val newVertex = result.nodes.map { n => (inv(n), (n, result.checkpoints.get(n))) }
//      val newEdges = result.delta.map { case ((n1, n2), v) => ((inv(n1), inv(n2)), v) }
//
//      newEdges.toIterator ++ newVertex.toIterator
//    }
//
//    // Bring back and sum by abelian.
//    val partitioner = GXPartitoner(partitions, size(l))
//
//    val newVertex = results.collect { case (vid: Long, (n: N, v: Option[V2])) => ((vid, n), v) }
//      //      .reduceByKey{
//      //        case (Some(v1:V2), Some(v2:V2)) => Some(v2Abelian.merge(v1, v2))
//      //        case (None, None) => None
//      //      }.map { case ((vid, n), v) => (vid, (n, v)) }
//      .reduceByKey(partitioner, func = {
//      case (Some(v1: V2), Some(v2: V2)) => Some(v2Abelian.merge(v1, v2))
//      case (None, None) => None
//    }).map { case ((vid, n), v) => (vid, (n, v)) }
//      .partitionBy(partitioner)
//
//
//    val newEdges = results.collect { case ((vid1: Long, vid2: Long), v: V2) => ((vid1, vid2), v) }
//      .reduceByKey(partitioner, func = {
//        case (a: V2, b: V2) => v2Abelian.merge(a, b)
//      })
//      .partitionBy(partitioner)
//      .map { case ((vid1, vid2), v) => Edge(vid1, vid2, v) }
//
//    val graph = Graph(newVertex, newEdges) //.partitionBy(GXGraphPartitioner(partitioner))
//
//    IncGraphXLeet(graph, v2Abelian, l.nodes, l.edges)
//  }
//
//  def toLocal[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): local.IncEngineLeet[N, V] = {
//    val delta = l.graph.triplets.map(x => ((x.srcAttr._1, x.dstAttr._1), x.attr)).collect().toMap
//    val checkpoints = l.graph.vertices.collect { case (_, (n, Some(v))) => (n, v) }.collect().toMap
//    local.createIncEngineLeet(delta, l.nodes, checkpoints, l.abelian)
//  }
//
//  override def values[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V], on: Set[N]): Iterator[(N, V)] =
//  //local.values(toLocal(l))
//
//    thick(l.graph, l.abelian,size(l)).vertices.values.toLocalIterator
//
//  override def tmap[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncGraphXLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncGraphXLeet[N, V2] = {
//    val mapped = thick(l.graph, l.abelian,size(l)).mapVertices { case (_, (n, v)) => (n, f(v)) }
//    IncGraphXLeet(thin(mapped, v2Abelian, size(l)), v2Abelian, l.nodes, l.edges)
//  }
//
//
//  override def tmapHom[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncGraphXLeet[N, V1])(f: V1 => V2)(implicit v2Abelian: Group[V2]): IncGraphXLeet[N, V2] = {
//    val graph = l.graph
//      .mapEdges(x => f(x.attr))
//      .mapVertices {
//        case (_, (n, Some(v1))) => (n, Some(f(v1)))
//        case (_, (n, None)) => (n, None)
//      }
//
//    IncGraphXLeet(graph, v2Abelian, l.nodes, l.edges)
//  }
//
//  // Works.
//  override def subgraph[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V], edges: Set[(N, N)], nodes: Set[N]): IncGraphXLeet[N, V] = ???
//
//  //l.graph.subgraph(e => true, {case (_,(n,v)) => nodes(n) })
//
//  override def nodes[N: CT, T <: AType : CT](l: IncGraphXLeet[N, T]): Set[N] =
//    l.nodes
//
//  override def reverse[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): IncGraphXLeet[N, V] =
//    IncGraphXLeet(l.graph.reverse, l.abelian, l.nodes, l.edges.map(_.swap))
//
//  override def append[N: CT, V <: AType : CT](l1: IncGraphXLeet[N, V], l2: IncGraphXLeet[N, V]): IncGraphXLeet[N, V] = ???
//
//
//  def nativeContract[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V], mapping: Map[Long, Long]): IncGraphXLeet[N, V] = {
//    ???
//  }
//
//
//  override def contract[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V], mapping: Map[N, N]): IncGraphXLeet[N, V] = {
//    // I guess this is easy if not fully optimal; it needs efficient access on zero edges for the base alg.
//    ???
//  }
//
//  override def merge[N: CT, V <: AType : CT](l1: IncGraphXLeet[N, V], l2: IncGraphXLeet[N, V]): IncGraphXLeet[N, V] = {
//    val partitioner = GXPartitoner(partitions, size(l1))
//    val abl = l1.abelian
//    val newVertex = l1.graph.vertices.join(l2.graph.vertices, partitioner).map {
//      case (vid, ((n1, Some(v1)), (n2, Some(v2)))) if n1 == n2 => (vid, (n1, Some(abl.merge(v1, v2))))
//      case (vid, ((n1, None), (n2, None))) if n1 == n2 => (vid, (n1, None))
//    }
//
//    val el = l1.graph.edges.map(e => ((e.srcId, e.dstId), e.attr))
//    val er = l2.graph.edges.map(e => ((e.srcId, e.dstId), e.attr))
//    val newEdges = el.join(er, partitioner).map { case ((n1, n2), (v1, v2)) => Edge(n1, n2, abl.merge(v1, v2)) }
//
//    val graph = Graph(newVertex, newEdges, null)
//    //  .partitionBy(GXGraphPartitioner(partitioner))
//
//    IncGraphXLeet(graph, abl, l1.nodes, l1.edges)
//
//    //    // TODO: Be conservative about node ids and just merge both by vertex id.
//    //    // TODO: Use join? or zip partitions.
//    //    val abl = l1.abelian
//    //    val newVertex = l1.graph.vertices.union(l2.graph.vertices).reduceByKey {
//    //      case ((n1, Some(v1)), (n2, Some(v2))) if n1 == n2 => (n1, Some(abl.merge(v1, v2)))
//    //      case ((n1, None), (n2, None)) if n1 == n2 => (n1, None)
//    //    }
//    //
//    //    val newEdges = l1.graph.edges.union(l2.graph.edges).map { e => ((e.srcId, e.dstId), e.attr) }
//    //      .reduceByKey { case (v1, v2) => abl.merge(v1, v2) }
//    //      .map { case ((n1, n2), v) => Edge(n1, n2, v) }
//    //
//    //    IncGraphXLeet(Graph(newVertex, newEdges, null), abl, l1.nodes, l1.edges)
//  }
//
//  override def zero[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): IncGraphXLeet[N, V] = ???
//
//  override def product[N: CT, V1 <: AType : CT, V2 <: AType : CT](l1: IncGraphXLeet[N, V1], l2: IncGraphXLeet[N, V2]): IncGraphXLeet[N, ATuple[V1, V2]] = {
//    val partitioner = GXPartitoner(partitions, size(l1))
//    val abl = ATuple.aTupleGroup(l1.abelian, l2.abelian)
//    val newVertex = l1.graph.vertices.join(l2.graph.vertices, partitioner).map {
//      case (vid, ((n1, Some(v1)), (n2, Some(v2)))) if n1 == n2 => (vid, (n1, Some(ATuple(v1, v2))))
//      case (vid, ((n1, None), (n2, None))) if n1 == n2 => (vid, (n1, None))
//    }
//    val el = l1.graph.edges.map(e => ((e.srcId, e.dstId), e.attr))
//    val er = l2.graph.edges.map(e => ((e.srcId, e.dstId), e.attr))
//    val newEdges = el.join(er, partitioner).map { case ((n1, n2), (v1, v2)) => Edge(n1, n2, ATuple(v1, v2)) }
//
//    val graph = Graph(newVertex, newEdges, null)
//    //.partitionBy(GXGraphPartitioner(partitioner))
//
//    IncGraphXLeet(graph, abl, l1.nodes, l1.edges)
//  }
//
//  override def edges[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): Set[(N, N)] =
//    l.edges
//
//  override def zeroEdges[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): Set[(N, N)] = {
//    val abl = l.abelian
//    l.graph.triplets.filter(_.attr == abl.zero).map(x => (x.srcAttr._1, x.dstAttr._1)).collect().toSet
//  }
//
//  override def relativeValues[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): Iterator[((N, N), V)] =
//  //local.relativeValues(toLocal(l))
//
//    l.graph.triplets.map(x => ((x.srcAttr._1, x.dstAttr._1), x.attr)).toLocalIterator
//
//  override def nmap[N1: CT, N2: CT, V <: AType : CT](l: IncGraphXLeet[N1, V])(f: N1 => N2): IncGraphXLeet[N2, V] = ???
//
//  override def uncontract[N: CT, V1 <: AType : CT, V2 <: AType : CT](l: IncGraphXLeet[N, V1], to: IncGraphXLeet[N, V2], mapping: Map[N, N]): IncGraphXLeet[N, V1] = ???
//
//  override def reduce[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V])(f: (V, V) => V): V =
//    local.reduce(toLocal(l))(f)
//
//  //thick(l.graph, l.abelian).vertices.map(_._2._2).reduce(f)
//
//  override def keys[N: CT, K: CT, V <: AType : CT](l: IncGraphXLeet[N, AMap[K, V]]): Set[K] = {
//    l.graph.edges.map(_.attr.keys()).reduce(_ ++ _) ++ l.graph.vertices.collect { case (_, (n, Some(v))) => v.keys() }.reduce(_ ++ _)
//  }
//
//  override def force[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): IncGraphXLeet[N, V] =
//    IncGraphXLeet(l.graph.cache(), l.abelian, l.nodes, l.edges)
//
//
//  override def abelian[N: CT, V <: AType : CT](l: IncGraphXLeet[N, V]): Group[V] = l.abelian
//}
