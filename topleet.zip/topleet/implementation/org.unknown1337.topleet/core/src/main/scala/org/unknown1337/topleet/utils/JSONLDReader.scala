package org.unknown1337.topleet.utils

import java.io._
import java.nio.charset.Charset
import collection.JavaConverters._
import com.google.gson.{JsonElement, JsonObject, JsonParser}
import java.io.BufferedReader


object JSONLDReader {

  def toMap(x: JsonObject): Map[String, JsonElement] =
    x.getAsJsonObject()
      .entrySet()
      .asScala
      .map(x => x.getKey -> x.getValue).toMap

  def create(file: File, charset: Charset) =
    JSONLDReader(new FileInputStream(file), charset)
}

case class JSONLDReader(inputStream: InputStream, charset: Charset) {

  private val reader = new BufferedReader(new InputStreamReader(inputStream))
  private val parser = new JsonParser()

  def read(): Option[JsonElement] = {
    val out = reader.readLine()
    if (out != null) Some(parser.parse(out))
    else None
  }

  def readAll(): Iterator[JsonElement] =
    Iterator.continually {
      read()
    }.takeWhile(x => x.isDefined).flatten
}
