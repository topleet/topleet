package org.unknown1337.topleet.evaluation.lisaparser

import java.io.{FileInputStream, InputStream}

import org.antlr.runtime.{ANTLRInputStream, ANTLRStringStream}
import org.antlr.v4.runtime.tree.{ParseTree, ParseTreeVisitor, RuleNode}
import org.antlr.v4.runtime.{CharStreams, CommonTokenStream, ConsoleErrorListener, ParserRuleContext}
import collection.JavaConverters._

case class AST(id: String, tpe: String)

object AntlrJavaParser {

  def main(args: Array[String]): Unit = {
    edges(new FileInputStream("temp/ClassA.java"),"root").foreach(println)

  }

  def parse(in: InputStream): JavaParser.CompilationUnitContext = {
    val lexer = new JavaLexer(CharStreams.fromStream(in))
    lexer.removeErrorListeners()
    val p = new JavaParser(new CommonTokenStream(lexer))
    p.removeErrorListeners()
    p.compilationUnit()
  }

  def edges(in: InputStream, root: String): Set[(AST, AST)] = {

    val ast = AntlrJavaParser.parse(in)

    def extract(pt: ParseTree, parentId: String, parentTpe: String): Set[(AST, AST)] = {
      (for (ix <- 0 until pt.getChildCount) yield {
        val child = pt.getChild(ix)
        val childId = parentId + "/" + ix
        val childTpe = child.getClass.getSimpleName
        Set((AST(parentId, parentTpe), AST(childId, childTpe))) ++ extract(child, childId, childTpe)
      }).flatten.toSet
    }

    extract(ast, root + ":", ast.getClass.getSimpleName)
  }

  def computeMCC(in: InputStream): Int = {
    val visitor = new JavaBaseVisitor[Int] {

      override def defaultResult(): Int = 0

      override def aggregateResult(aggregate: Int, nextResult: Int): Int = aggregate + nextResult

      override def visitIfStatement(ctx: JavaParser.IfStatementContext): Int = super.visitIfStatement(ctx) + 1

      override def visitWhileStatement(ctx: JavaParser.WhileStatementContext): Int = super.visitWhileStatement(ctx) + 1

      override def visitDoStatement(ctx: JavaParser.DoStatementContext): Int = super.visitDoStatement(ctx) + 1

      override def visitForStatement(ctx: JavaParser.ForStatementContext): Int = super.visitForStatement(ctx) + 1

      override def visitTryStatement(ctx: JavaParser.TryStatementContext): Int = super.visitTryStatement(ctx) + 1

      override def visitCatchClause(ctx: JavaParser.CatchClauseContext): Int = super.visitCatchClause(ctx) + 1

      override def visitSwitchLabel(ctx: JavaParser.SwitchLabelContext): Int = super.visitSwitchLabel(ctx) + 1

      override def visitConditionalExpression(ctx: JavaParser.ConditionalExpressionContext): Int = super.visitConditionalExpression(ctx) + 1
    }

    val ast = AntlrJavaParser.parse(in)
    ast.accept(visitor)
  }

  def methodCount(in: InputStream): Int = {

    val visitor = new JavaBaseVisitor[Int] {

      override def defaultResult(): Int = 0

      override def aggregateResult(aggregate: Int, nextResult: Int): Int = aggregate + nextResult

      override def visitMethodDeclaration(ctx: JavaParser.MethodDeclarationContext): Int = {
        super.visitMethodDeclaration(ctx) + 1
      }

      override def visitGenericMethodDeclaration(ctx: JavaParser.GenericMethodDeclarationContext): Int = {
        super.visitGenericMethodDeclaration(ctx) + 1
      }

      override def visitConstantDeclarator(ctx: JavaParser.ConstantDeclaratorContext): Int = {
        super.visitConstantDeclarator(ctx) + 1
      }

      override def visitInterfaceMethodDeclaration(ctx: JavaParser.InterfaceMethodDeclarationContext): Int = {
        super.visitInterfaceMethodDeclaration(ctx)
      } + 1

      override def visitGenericInterfaceMethodDeclaration(ctx: JavaParser.GenericInterfaceMethodDeclarationContext): Int = {
        super.visitGenericInterfaceMethodDeclaration(ctx) + 1
      }
    }

    val ast = AntlrJavaParser.parse(in)
    ast.accept(visitor)
  }
}

