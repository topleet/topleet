package org.unknown1337.topleet.atypes

import org.unknown1337.topleet.Group

object AInteger {

  implicit def toAInterger(x: Int): AInteger = AInteger(x)

  def min(x: AInteger, y: AInteger): AInteger = (x, y) match {
    case (AInteger(xx), AInteger(yy)) => AInteger(Math.min(xx, yy))
  }

  def max(x: AInteger, y: AInteger): AInteger = (x, y) match {
    case (AInteger(xx), AInteger(yy)) => AInteger(Math.max(xx, yy))
  }

  implicit def aIntegerGroup[T]: Group[AInteger] = new Group[AInteger] {

    override def merge(v1: AInteger, v2: AInteger): AInteger = AInteger(v1.value + v2.value)

    override def inverse(v: AInteger): AInteger = AInteger(-v.value)

    override def zero: AInteger = AInteger.zero
  }

  def zero = AInteger(0)
}

case class AInteger(value: Int) extends AType {
  override def ~=(other: AType): Boolean = {
    if (!other.isInstanceOf[AInteger]) return false
    val o = other.asInstanceOf[AInteger]
    this.value == o.value
  }

  override def isZero: Boolean = AInteger.zero == this

  override def isApproxZero: Boolean = isZero

  override def pretty(): String = value.toString


  def toInt: Int = value

  /**
    * Length of the delta in terms of effort needed to conduct it.
    */
  override def dlength(): Double = Math.abs(value).toDouble
}

