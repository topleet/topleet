//package org.unknown1337.topleet.utils
//
//import com.google.common.base.Charsets
//import org.apache.log4j.{Level, Logger}
//import org.apache.spark.{Partitioner, SparkConf}
//import org.apache.spark.rdd.RDD
//import org.apache.spark.sql.SparkSession
//import org.eclipse.jgit.lib.ObjectId
//
//import collection.JavaConverters._
//import org.unknown1337.topleet.utils.CSVSink.SinkType
//
//import scala.reflect.ClassTag
//
//object SparkUtils {
//
//  var cores = 16
//
////  Logger.getLogger("org.apache").setLevel(Level.OFF)
////  Logger.getLogger("akka").setLevel(Level.OFF)
//
//  lazy val config = new SparkConf()
//    .setAppName("Main")
//    .setMaster("local[" + cores + "]")
//    .set("spark.local.dir", "C:/Data/JUtil-temp/spark_tmp")
//    .set("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
//    .set("spark.graphx.pregel.checkpointInterval", "100")
//    //.set("spark.kryo.registrationRequired", "true")
//    .registerKryoClasses(Array(
//    classOf[ObjectId],
//    classOf[scala.collection.mutable.WrappedArray.ofRef[_]],
//    Class.forName("org.apache.spark.sql.execution.datasources.FileFormatWriter$WriteTaskResult"),
//    Class.forName("org.apache.spark.internal.io.FileCommitProtocol$TaskCommitMessage"),
//    Class.forName("scala.collection.immutable.Set$EmptySet$")
//  )
//
//  )
//
//  lazy val spark = SparkSession
//    .builder()
//    .config(config)
//    .appName("EAM")
//    .getOrCreate()
//
//  lazy val sc = {
//    val x = spark.sparkContext
//    x.setCheckpointDir("C:/Data/JUtil-temp/spark_tmp")
//    x
//  }
//
//  def bypass[A, C](rdd: RDD[(A, C)])(implicit atag: ClassTag[A], ctag: ClassTag[C]): (RDD[(A, Long)], RDD[(Long, C)]) = {
//    val x = rdd.zipWithIndex()
//    val as = x.map { case ((a, _), idx) => (a, idx) }
//    val cs = x.map { case ((_, c), idx) => (idx, c) }
//
//    (as, cs)
//  }
//
//  def zipBypass[A, C](as: RDD[(A, Long)], cs: RDD[(Long, C)])(implicit atag: ClassTag[A], ctag: ClassTag[C]): RDD[(A, C)] =
//    as.map(_.swap).join(cs).values
//
//  def toCsv(location: String, record: RDD[Map[String,String]]):Unit = {
//    val keys = record.map(_.keySet).reduce(_ ++ _).toSeq
//    val csv = new CSVSink(location,Charsets.UTF_8,SinkType.STATIC,keys:_*)
//    for (qs <- record.collect()) csv.write(qs.asJava)
//    csv.close()
//  }
//
//  def cumsum[T](rdd: RDD[T])(value: T => Long): RDD[(T, Long)] = {
//
//    val partials = rdd.map(x => x -> value(x)).mapPartitionsWithIndex((i, iter) => {
//      val (keys, values) = iter.toSeq.unzip
//      val sums = values.scanLeft(0l)(_ + _)
//      Iterator((keys.zip(sums.tail), sums.last))
//    })
//
//    // Collect partials sums
//
//    val partialSums = partials.values.collect
//
//    // Compute cumulative sum over partitions and broadcast it:
//
//    val sumMap = sc.broadcast(
//      rdd.partitions.indices
//        .zip(partialSums.scanLeft(0l)(_ + _))
//        .toMap
//    )
//
//    // Compute final results:
//
//    partials.keys.mapPartitionsWithIndex((i, iter) => {
//      val offset = sumMap.value(i)
//      if (iter.isEmpty) Iterator()
//      else iter.next.map { case (k, v) => (k, v + offset) }.toIterator
//    })
//  }
//
//  //
//  //  def createPartitioner(i: Int, vpow: Int, apow: Int, ppow: Int) = new Partitioner {
//  //    val partitions: Int = Math.pow(2, ppow).toInt
//  //
//  //    def assign(x: Long): Int = {
//  //      //val mask = (2l << (vpow + ppow +1)) - 1
//  //      val ishift = (vpow + 1) - ppow + Math.min(ppow, i)
//  //      val xii = x >> ishift
//  //      val xiii = (xii % partitions).toInt
//  //
//  //      xiii
//  //    }
//
//  /**
//    * Returns the restriction of an attribute an one partition.
//    */
//  def attributeInPartition[A](rdd: RDD[A])(implicit et: ClassTag[A]) =
//    rdd.mapPartitionsWithIndex { case (partition, iterator) => iterator.map(x => x -> Set(partition)) }
//      .reduceByKey(_ ++ _).map(_._2.size).mean()
//
//
//  //  /**
//  //    * Split key and process values for a tuple key. Moves from a key locality to a value locality. Inverts the key map relation.
//  //    */
//  //  def splitAndProcess[K, V](edges: RDD[((Long, K), (Long, V))], partitionPow: Int, keyPow: Int, valuePow: Int, splits: Int)
//  //                           (subroutine: RDD[((Long, K), ((Long, V), (Long, Long)))] => RDD[((Long, K), ((Long, V), (Long, Long)))])
//  //                           (implicit ktag: ClassTag[K], vtag: ClassTag[V]): RDD[((Long, V), (Long, K))] = {
//  //
//  //    var current = edges.map { case ((v1, v2), e) => ((v1, v2), (e, (0l, Math.pow(2, valuePow).toLong))) }
//  //
//  //    // TODO: Check if this must be i < apow
//  //    var i = 0
//  //    while (i <= valuePow) {
//  //
//  //      // Mirror graph according to the split.
//  //      var u = 0
//  //      while (i <= valuePow && u < splits) {
//  //        val m = 2l << (keyPow + i)
//  //        current = mirror(current, m)
//  //
//  //        // Split the attribute ranges.
//  //        current = current.map {
//  //          case ((v1, v2), (vd, (low, high))) if v1 < m => ((v1, v2), (vd, (low, ((high.toLong + low.toLong) / 2).toInt)))
//  //          case ((v1, v2), (vd, (low, high))) if v1 >= m => ((v1, v2), (vd, ((((high.toLong + low.toLong) / 2) + 1).toInt, high)))
//  //        }
//  //
//  //        u = u + 1
//  //        i = i + 1
//  //      }
//  //
//  //      // Replace the current partitioning by a new one based on value locality information encoded in the vertices.
//  //      current = current.partitionBy(createPartitioner(i + 1, keyPow, valuePow, partitionPow))
//  //
//  //      // Call subroutine.
//  //      current = subroutine(current)
//  //
//  //    }
//  //    current.mapValues(_._1)
//  //  }
//}
